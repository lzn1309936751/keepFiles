package com;

public class ChiCaoDongWu extends DongWu {
	
	

	/**
	 * 封装:隐藏细节,让使用者用起来很爽
	 * 隐藏细节针对的是使用者
	 * 但是作为实现者来说,是没有隐藏细节的.
	 * 给自己带来麻烦,给别人方便
	 * 
	 * 封装从小到大的层面可以这样理解
	 * 1.方法是一个封装
	 * 2.类也是封装
	 * 3.包也是一个封装
	 */
	private int age;
	
	public void setAge(int age) {
		if(age>0 && age<120) {
			this.age = age;
		}else {
			this.age = 1;
		}
	}
	
	public int getAge() {
		return this.age;
	}
	public int add(int x ,int y) {
		return x + y;
	
	}
	
	public float add(float x ,float y) {
		return x + y +100;
	
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("吃草");
	}
	
	
}
