package com.templateMethod;

public class Girl extends Student {

	@Override
	protected void zaoShang() {
		// TODO Auto-generated method stub
		System.out.println("化妆");
	}

	@Override
	protected void zhongWu() {
		// TODO Auto-generated method stub
		System.out.println("补妆");
	}

	@Override
	protected void xiaWu() {
		// TODO Auto-generated method stub
		System.out.println("卸妆");
	}

	

}
