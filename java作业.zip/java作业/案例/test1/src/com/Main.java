package com;

import com.templateMethod.Boy;
import com.templateMethod.Girl;
import com.templateMethod.Student;
import com.templateMethod2.Student2;
import com.templateMethod2.Xueba;
import com.templateMethod3.DoSth;
import com.templateMethod3.GirlZhongWu;
import com.templateMethod3.Student3;

public class Main {

	/**
	 * 静态的东西只执行一次,执行顺序是
	 * 1.静态全局变量
	 * 2.静态代码块,有多个静态代码块时,以出现的顺序来执行
	 * 
	 * 实例的东西会执行多次
	 * 1.全局的实例变量
	 * 2.实例代码块
	 * 3.构造函数
	 * @param args
	 */
	public static void main(String[] args) {
		//下面的代码,简化来说,干了2个事情
		//1.类的处理,2.对象的创建处理
		//类的处理干了如下事情:
		//1. 加载类到jvm,
		//2 对类进行初始化操作,主要就是针对静态成员进行赋值
		//对象的创建:1.对类中的全局变量进行初始化,2.调用构造函数
		
		//类的处理只会处理一次
		
		
		// 类的静态全局变量会初始化一次,
		// 类的全局实例变量在每次实例化的时候都会被初始化
		
		/*
		 * ClassInit init = new ClassInit(); ClassInit init2 = new ClassInit();
		 * System.out.println(init); System.out.println(init2);
		 */
		
		
		ChiCaoDongWu dongwu = new ChiCaoDongWu();
		dongwu.setAge(3);
		System.out.println(dongwu.getAge());
		//多态:水有多种形态,气体,液体,固体
		// 同一个东西(h2o),但是因为温度的不一样,表现形态不一样
		
		//下面的这种通过重载实现的多态称之为编译时多态
		//因为add方法在编译的时候就已经确定了是调用哪一个具体的方法
		
		//重载:1.方法名相同,2.方法的参数个数不一样或者类型不一样
		
		float result = dongwu.add(5.5f, 5.5f);
		System.out.println(result);
		
		int result2 = dongwu.add(5, 5);
		System.out.println(result2);
		
		DongWu d1 = new ChiCaoDongWu();
		DongWu d2 = new ChiRouDongWu();
		//运行时多态
		//d1.eat();
		
		
		//模板方法设计模式;
		
		/*
		 * Student xuewei = new Boy(); xuewei.life();
		 * 
		 * Student xixi = new Girl(); xixi.life();
		 */
		
		Student2 s2 = new Xueba();
		s2.life();
		
		Student3 s3 = new Student3();
		DoSth girl = new GirlZhongWu();
		s3.life(girl);
	}
	
}
