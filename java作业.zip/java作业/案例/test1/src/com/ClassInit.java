package com;

public class ClassInit {
	private static String sf = null;
	private static String sf2 = "aaa";
	
	
	private String if1 = null;
	private String if2 = "bbb";
	//静态代码块
	static {
		System.out.println("静态代码块");
	}
	//静态代码块2
	static {
		System.out.println("静态代码块2");
	}
	//实例代码块
	{
		System.out.println("实例代码块");
		
	}
	//实例代码块2
	{
		System.out.println("实例代码块2");
		
	}
	public ClassInit() {
		System.out.println("默认构造函数");
	}
}
