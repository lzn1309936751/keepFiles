package com;

public abstract class DongWu {
	private String name;
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	//抽象:代表你有这个能力,但是还不确定怎么实现这个能力
	public abstract void eat();
		
}
