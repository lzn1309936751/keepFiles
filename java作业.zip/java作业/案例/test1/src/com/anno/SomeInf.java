package com.anno;

/**
 * 此接口用来演示匿名内部类使用
 * 一般这种接口,其内部的方法个数只有一个
 * @author cj
 *
 */
public interface SomeInf {
	void add(int x,int y);
	
}
