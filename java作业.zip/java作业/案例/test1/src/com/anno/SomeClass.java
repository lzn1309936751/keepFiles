package com.anno;

public class SomeClass {
	public void calc(SomeInf inf) {
		inf.add(5, 6);
	}
	
	public static void main(String[] args) {
		SomeClass sc = new SomeClass();
		sc.calc(new SomeInf() {
			
			@Override
			public void add(int x, int y) {
				// TODO Auto-generated method stub
				System.out.println(x+y);
			}
		});
	}
}
