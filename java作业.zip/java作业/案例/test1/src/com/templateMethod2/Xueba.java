package com.templateMethod2;

public class Xueba extends Student2{

	@Override
	protected void shangwu() {
		// TODO Auto-generated method stub
		System.out.print("学习");
	}


	
	@Override
	protected void xiawu() {
		// TODO Auto-generated method stub
		
	}
	 
}
