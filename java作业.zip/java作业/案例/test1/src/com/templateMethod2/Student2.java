package com.templateMethod2;

public abstract class Student2 {

	protected abstract void shangwu();
	protected  void zhongwu() {
		System.out.println("中午");
	}
	protected abstract void xiawu();
	
	public void life() {
		shangwu();
		zhongwu();
		xiawu();
	}
}
