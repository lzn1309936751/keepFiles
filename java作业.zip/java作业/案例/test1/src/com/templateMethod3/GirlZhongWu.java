package com.templateMethod3;

public class GirlZhongWu implements DoSth {

	@Override
	public void zhongWu() {
		// TODO Auto-generated method stub
		System.out.println("补妆");
	}

}
