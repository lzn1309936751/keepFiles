package com.templateMethod3;

public interface DoSth {
	void zhongWu();
}
