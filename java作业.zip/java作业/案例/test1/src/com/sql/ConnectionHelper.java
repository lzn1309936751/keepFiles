package com.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * 
 * 此类是用来得到数据库连接用的
 * 
 * 此类还有2个地方是可以改进的
 * 1. 异常的处理,此类都是不规范的
 * 2. 连接字符串,账号密码这种东西一般放在外部的properties文件中
 * 此类就没有这样做
 * 
 * @author cj
 *
 */
public class ConnectionHelper {
	/**
	 * 数据库的连接Url
	 */
	private static final String URL = "jdbc:mysql://localhost:3306/demo";
	/**
	 * 数据库的连接用户名
	 */
	private static final String USERNAME="root";
	/**
	 * 数据库的连接密码
	 */
	private static final String PASSWORD="root";
	
	/**
	 * 静态代码块,用来加载jdbc的驱动
	 * 驱动类只需要加载一次,所以放在静态代码块是很合适的
	 */
	static {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() {
		
		Connection conn = null;
		try {
			 conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
}
