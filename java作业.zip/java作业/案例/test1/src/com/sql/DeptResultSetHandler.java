package com.sql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DeptResultSetHandler implements ResultSetHandler	 {

	@Override
	public List<Object> handle(ResultSet rs) throws SQLException {
		List<Object> list = new ArrayList<Object>();
		while(rs.next()) {
			Dept d = new Dept();
			d.setId(rs.getInt("id"));
			d.setDeptname(rs.getString("deptname"));
			list.add(d);
		}
		return list;
	}

}
