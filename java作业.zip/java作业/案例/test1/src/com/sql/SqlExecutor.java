package com.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class SqlExecutor {

	/**
	 * 增删改操作(CUD) crud:create(增加) retrieve(查询) update(更新) delete(删除)
	 * 
	 * String insert = "insert into dept(deptname) values(100)"
	 * String update = "update dept set detpname=? where id =?";
	 * String delete = "delete from dept where id = ? "
	 * 返回都是影响的行数
	 * @return
	 */
	public boolean modify(String sql, Object... paramValues) throws SQLException {
		// insert into dept(deptname) values(?);
		Connection conn = ConnectionHelper.getConnection();
		PreparedStatement ps  = conn.prepareStatement(sql);
		for (int i = 0; i < paramValues.length; i++) {
			ps.setObject(i + 1, paramValues[i]);
		}
		// 返回的影响的行数
		int affectedRows = ps.executeUpdate();

		return affectedRows > 0 ? true : false;
	}
	
	/**
	 * 可变长度的参数必须作为方法的最后一个参数
	 * add(int a,int... b,int c);
	 * add(1,2,3,4);
	 * 
	 * String sql = "select id,deptname from dept ";
	 * String sql = "select id,deptname from where deptname=?"
	 * @param sql
	 * @param objects
	 * @return
	 * @throws SQLException
	 */
	public List<Object> query(String sql,ResultSetHandler handler,Object...objects) throws SQLException{
		List<Object> result = null;
		Connection conn = ConnectionHelper.getConnection();
		PreparedStatement ps  = conn.prepareStatement(sql);
		for (int i = 0; i < objects.length; i++) {
			ps.setObject(i + 1, objects[i]);
		}
		
		ResultSet rs = ps.executeQuery();
		result = handler.handle(rs);	
		close(rs,ps,conn);
		return result;
	}
	private void close(ResultSet rs,PreparedStatement ps,Connection conn) throws SQLException {
		if(rs!=null) {
			rs.close();
		}
		if(ps!=null) {
			ps.close();
		}
		if(conn!=null) {
			conn.close();
		}
	}
}
