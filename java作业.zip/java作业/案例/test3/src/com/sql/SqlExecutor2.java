package com.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class SqlExecutor2 {

	/**
	 * 澧炲垹鏀规搷浣�(CUD) crud:create(澧炲姞) retrieve(鏌ヨ) update(鏇存柊) delete(鍒犻櫎)
	 * 
	 * String insert = "insert into dept(deptname) values(100)"
	 * String update = "update dept set detpname=? where id =?";
	 * String delete = "delete from dept where id = ? "
	 * 杩斿洖閮芥槸褰卞搷鐨勮鏁�
	 * @return
	 */
	public boolean modify(String sql, Object... paramValues) throws SQLException {
		// insert into dept(deptname) values(?);
		Connection conn = ConnectionHelper.getConnection();
		PreparedStatement ps  = conn.prepareStatement(sql);
		for (int i = 0; i < paramValues.length; i++) {
			ps.setObject(i + 1, paramValues[i]);
		}
		// 杩斿洖鐨勫奖鍝嶇殑琛屾暟
		int affectedRows = ps.executeUpdate();

		return affectedRows > 0 ? true : false;
	}
	
	/**
	 * 鍙彉闀垮害鐨勫弬鏁板繀椤讳綔涓烘柟娉曠殑鏈�鍚庝竴涓弬鏁�
	 * add(int a,int... b,int c);
	 * add(1,2,3,4);
	 * 
	 * String sql = "select id,deptname from dept ";
	 * String sql = "select id,deptname from where deptname=?"
	 * @param sql
	 * @param objects
	 * @return
	 * @throws SQLException
	 */
	public <T> List<T>  query(String sql,ResultSetHandler2 handler,Object...objects) throws SQLException{
		List<T> result = null;
		Connection conn = null;
		PreparedStatement ps  =null;
		ResultSet rs=null;
		try{
			conn=ConnectionHelper.getConnection();
			ps= conn.prepareStatement(sql);
			for (int i = 0; i < objects.length; i++) {
				ps.setObject(i + 1, objects[i]);
			}
			rs = ps.executeQuery();
			result = handler.handle(rs);	
		}finally {
				close(rs,ps,conn);
		}
		//涓�瀹氳璁板緱杩涜璧勬簮鍏抽棴澶勭悊
		
		return result;
	}
	/**
	 * 
	 * 杩涜璧勬簮鍏抽棴鎿嶄綔
	 * @param rs
	 * @param ps
	 * @param conn
	 * @throws SQLException
	 */
	private void close(ResultSet rs,PreparedStatement ps,Connection conn) throws SQLException {
		if(rs!=null) {
			rs.close();
		}
		if(ps!=null) {
			ps.close();
		}
		if(conn!=null) {
			conn.close();
		}
	}
}
