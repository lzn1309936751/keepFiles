package com.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class SqlExecutor {

	/**
	 * 增删改操作(CUD) crud:create(增加) retrieve(查询) update(更新) delete(删除)
	 * 
	 * String insert = "insert into dept(deptname) values(100)" String update =
	 * "update dept set detpname=? where id =?"; String delete = "delete from dept
	 * where id = ? " 返回都是影响的行数
	 * 
	 * @return
	 */
	public boolean modify(String sql, Object... paramValues) throws SQLException {
		// insert into dept(deptname) values(?);
		Connection conn = ConnectionHelper.getConnection();
		PreparedStatement ps = conn.prepareStatement(sql);
		// 给参数赋值,也就是sql中的?的值进行赋值处理.
		for (int i = 0; i < paramValues.length; i++) {
			ps.setObject(i + 1, paramValues[i]);
		}
		// 返回的影响的行数
		int affectedRows = ps.executeUpdate();

		return affectedRows > 0 ? true : false;
	}
	
	public boolean modify2(String sql, Object... paramValues) throws SQLException {		
		Connection conn = ConnectionHelper.getConnection();
		int affectedRows = 0;
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			for (int i = 0; i < paramValues.length; i++) {
				ps.setObject(i + 1, paramValues[i]);
			}
			affectedRows = ps.executeUpdate();
		} finally {
			close(ps, conn);
		}
		return affectedRows > 0 ? true : false;
	}

	/**
	 * 可变长度的参数必须作为方法的最后一个参数. 因为如果不这样做,下面的add方法调用时,到底是2,3 传递给b, 还是2,3,4 传递给b是不清晰的.
	 * add(int a,int... b,int c); add(1,2,3,4);
	 * 
	 * String sql = "select id,deptname from dept "; String sql = "select
	 * id,deptname from where deptname=?"
	 * 
	 * @param sql
	 * @param objects
	 * @return
	 * @throws SQLException
	 */
	public List<Object> query(String sql, ResultSetHandler handler, Object... objects) throws SQLException {
		List<Object> result = null;
		Connection conn = ConnectionHelper.getConnection();
		PreparedStatement ps = conn.prepareStatement(sql);
		for (int i = 0; i < objects.length; i++) {
			ps.setObject(i + 1, objects[i]);
		}

		ResultSet rs = ps.executeQuery();
		// 把对ResultSet的处理交给其它的类型处理
		// 因为这个方法是一个通用的方法,是不可能写死对某一个具体表进行处理的
		result = handler.handle(rs);
		// TODO: ***这里这样写有隐含的bug,因为上面的方法如果执行过程中出现异常,
		// 这个close方法是不会被调用的.资源并没有得到清理
		close(rs, ps, conn);
		return result;
	}

	/**
	 * 下面的这个方法解决了上面方法资源关闭的问题.
	 * @param sql
	 * @param handler
	 * @param objects
	 * @return
	 * @throws SQLException
	 */
	public List<Object> query2(String sql, ResultSetHandler handler, Object... objects) throws SQLException {
		List<Object> result = null;
		Connection conn = ConnectionHelper.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			for (int i = 0; i < objects.length; i++) {
				ps.setObject(i + 1, objects[i]);
			}
			rs = ps.executeQuery();
			result = handler.handle(rs);

		} finally {
			close(rs, ps, conn);
		}
		return result;
	}
	
	private void close( PreparedStatement ps, Connection conn) throws SQLException {
	
		if (ps != null) {
			ps.close();
		}
		if (conn != null) {
			conn.close();
		}
	}
	
	private void close(ResultSet rs, PreparedStatement ps, Connection conn) throws SQLException {
		if (rs != null) {
			rs.close();
		}
		if (ps != null) {
			ps.close();
		}
		if (conn != null) {
			conn.close();
		}
	}
}
