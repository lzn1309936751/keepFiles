package com;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sql.ConnectionHelper;
import com.sql.Dept;
import com.sql.DeptResultSetHandler;
import com.sql.Product;
import com.sql.ResultSetHandler;
import com.sql.ResultSetHandler2;
import com.sql.SqlExecutor;
import com.sql.SqlExecutor2;
import com.templateMethod2.Student2;
import com.templateMethod2.Xueba;
import com.templateMethod3.DoSth;
import com.templateMethod3.GirlZhongWu;
import com.templateMethod3.Student3;

public class Main {

	/**
	 * 静态的东西只执行一次,执行顺序是 1.静态全局变量 2.静态代码块,有多个静态代码块时,以出现的顺序来执行
	 * 
	 * 实例的东西会执行多次 1.全局的实例变量 2.实例代码块 3.构造函数
	 * 
	 * @param args
	 * @throws SQLException
	 */
	public static void main(String[] args) throws SQLException {
		// testModify();

		// testDeptQuery();
		// testProductQuery();
		testProductQueryGeneric();
	}

	protected static void testProductQueryGeneric() throws SQLException {
		SqlExecutor2 executor = new SqlExecutor2();

		String sql = "select pid,pname from product";

		List<Product> result = executor.query(sql, new ResultSetHandler2() {

			@Override
			public List<Product> handle(ResultSet rs) throws SQLException {
				List<Product> list = new ArrayList<Product>();
				while (rs.next()) {
					Product d = new Product();
					d.setPid(rs.getInt("pid"));
					d.setPname(rs.getString("pname"));
					list.add(d);
				}
				return list;
			}
		});

		for (Product o : result) {
			System.out.println( o.getPid());
			System.out.println( o.getPname());
		}
	}

	protected static void testProductQuery() throws SQLException {
		SqlExecutor executor = new SqlExecutor();

		String sql = "select pid,pname from product";

		List<Object> result = executor.query(sql, new ResultSetHandler() {

			@Override
			public List<Object> handle(ResultSet rs) throws SQLException {
				List<Object> list = new ArrayList<Object>();
				while (rs.next()) {
					Product d = new Product();
					d.setPid(rs.getInt("pid"));
					d.setPname(rs.getString("pname"));
					list.add(d);
				}
				return list;
			}
		});

		for (Object o : result) {
			System.out.println(((Product) o).getPid());
			System.out.println(((Product) o).getPname());
		}
	}

	protected static void testDeptQuery() throws SQLException {
		SqlExecutor executor = new SqlExecutor();

		String sql = "select id,deptname from dept where id>?";
		ResultSetHandler handler = new DeptResultSetHandler();
		List<Object> result = executor.query(sql, handler, 2);

		for (Object o : result) {
			System.out.println(((Dept) o).getId());
			System.out.println(((Dept) o).getDeptname());
		}
	}

	protected static void testModify() throws SQLException {
		SqlExecutor executor = new SqlExecutor();

		String sql = "insert into dept(deptname) values(?)";

		boolean result = executor.modify(sql, "abc");
		System.out.println(result);
	}

}
