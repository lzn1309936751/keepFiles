package com.templateMethod4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class SqlExecutor {

	/*
	 * public List<Object> query(String sql,ResultSetHandler handler) { Connection
	 * conn = null; String sql = ""; PreparedStatement ps =
	 * conn.prepareStatement(sql); ResultSet rs = ps.executeQuery(); List<Object> o
	 * = handler.handler(); //省略关闭 return o; }
	 */
}
