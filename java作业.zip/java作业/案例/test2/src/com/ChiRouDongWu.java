package com;

public class ChiRouDongWu extends DongWu {

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("吃肉");
	}

}
