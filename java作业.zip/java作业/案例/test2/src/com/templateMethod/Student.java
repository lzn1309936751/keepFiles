package com.templateMethod;

public abstract class Student {
	// protected修饰符只能被同包下的类以及子类访问
	protected abstract void zaoShang();

	protected abstract void zhongWu();

	protected abstract void xiaWu();

	/**
	 * 这个方法是个模板 此方法规定了一个流程, 但流程中每一步是可以交给子类去完成的 流程中的每一步不需要都是抽象的,可以是非抽象的
	 * 
	 */
	public void life() {
		zaoShang();
		zhongWu();
		xiaWu();
	}
}
