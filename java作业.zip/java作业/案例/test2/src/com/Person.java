package com;

public class Person {

	private static Person instance = null;

	private Person() {

	}

	public static Person instance() {
		if (instance == null) {
			// instance = new Person();
			// return instance = new Person();
			// return new Person();
			instance = new Person();
		}

		return instance;
	}

}
