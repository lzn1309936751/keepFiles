package com.templateMethod3;

public class Student3 {
	public void shangWu() {
		System.out.println("shangwu");
	};

	public void life(DoSth sth) {
		shangWu();

		sth.zhongWu();
	}
}
