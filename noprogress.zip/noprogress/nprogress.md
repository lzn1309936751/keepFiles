# nprogress

## 1、安装

- https://unpkg.com/nprogress@0.2.0/nprogress.js
- https://unpkg.com/nprogress@0.2.0/nprogress.css

## 2、基本用法

只需要调用start() 和 done()来控制进度条。

```Java
NProgress.start();

NProgress.done();
```



## 3、高级用法

**百分比**：通过设置progress的百分比，调用 .set(n)来控制进度，其中n的取值范围为0-1。

```java
NProgress.set(0.0);     // Sorta same as .start()

NProgress.set(0.4);

NProgress.set(1.0);     // Sorta same as .done()
```

**递增**：要让进度条增加，只要调用 .inc()。这会产生一个随机增量，但不会让进度条达到100%。此函数适用于图片加载或其他类似的文件加载。

```java
NProgress.inc();
```

**强制完成**：通过传递 true 参数给done()，使进度条满格，即使它没有被显示。

```java
NProgress.done(true);
```

**获取状态值：**要获取状态值，请使用`.status`



## 4、组态

**minimum**：更改启动时使用的最小百分比。（默认值：`0.08`）

```java
NProgress.configure({minimum:0.1});
```

**template**：改变进度条的HTML结构。为保证进度条能正常工作，需要元素拥有role=’bar’属性。

```java
NProgress.configure({

  template:"<div class='....'>...</div>"

});
```

**easing 和 speed:**使用*缓动*（CSS缓动字符串）和*速度*（以毫秒为单位）调整动画设置。（默认：`ease`和`200`）

```java
NProgress.configure({ease:'ease',speed:500});
```

**trickle:**通过将此设置为关闭自动递增行为`false`。（默认值：`true`）

```java
NProgress.configure（{trickle ： false }）;
```

**trickleSpeed:**调整涓流/增量的频率，以毫秒为单位。

```java
NProgress.configure（{trickleSpeed ： 200 }）;
```

**showSpinner:**通过将其设置为false来关闭加载微调器。（默认值：`true`）

```java
NProgress.configure（{showSpinner ： false }）;
```

**parent:**指定此项以更改父容器。（默认值：`body`）

```java
NProgress.configure（{parent ： '＃content ' }）;
```



## 5、改变颜色

如果要修改进度条的颜色颜色，你写入如下css， ！important是设置最高级权限，可以覆盖本来的颜色

```Java
#nprogress .bar {

background:$color-main !important; //自定义颜色

}
```



## 案例一

```java
	<div id="app">
        <button class="btn btn-info" id="btn-loading">start()</button>
        <button class="btn btn-info" id="btn-loading2">set(0.4)</button>
        <button class="btn btn-info" id="btn-loading3">inc()</button>
        <button class="btn btn-info" id="btn-loading4">done()</button>

    </div>

    <script>

        $('#btn-loading').on('click',function () {
            NProgress.configure({easing:'ease',speed :3000 })//限制进度条的速度
            NProgress.start();//开始

        })

        $('#btn-loading2').on('click',function () {
            NProgress.configure({easing:'ease',speed :2000 })
            NProgress.set(0.4);//通过设置progress的百分比，调用 .set(n)来控制进度
        })

        $('#btn-loading3').on('click',function () {
            NProgress.configure({easing:'ease',speed :1000 })
            NProgress.inc();//要让进度条增加，只要调用 .inc()
        })

        $('#btn-loading4').on('click',function () {
            NProgress.configure({easing:'ease',speed :300 })
            NProgress.done();//完成
        })
    </script>
```

### 效果

![深度录屏_选择区域_20190918201750](/home/lzn/Desktop/noprogress/nprogress.assets/深度录屏_选择区域_20190918201750.gif)

## 案例二

```java
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../nprogress/nprogress.css" rel="stylesheet">
    <script type="text/javascript" src="/jquery-3.3.1.min.js"></script>
    <script src="../nprogress/nprogress.js"></script>
    <title>Title</title>
    <style>
        #app {
            width: 350px;
            border: 1px solid gray;
            padding: 5px;
        }
    </style>
</head>
<body>
    <div id="app">
        <button class="btn btn-info" id="btn-loading">load</button>

        <div style="margin-top: 5px">
            invoke inc times:<span id="inc_counter"></span>
            <br />noprogress status:<span id="status_counter"></span>
        </div>
    </div>

    <script>
        NProgress.configure({
            parent:'#app'
        })
        $('#btn-loading').on('click',function () {
            NProgress.start();
            var i=0;
            var timer=setInterval(() => {
                if(NProgress.status){
                    $('#inc_counter').text(i++)
                    $('#status_counter').text(NProgress.status)
                    NProgress.inc()
                }else{
                    clearInterval(timer)
                }
            }, 500);
            setTimeout(() => {
                NProgress.done()
            }, 3000);
        })
    </script>
</body>
</html>
```

### 效果

![](/home/lzn/Desktop/noprogress/nprogress.assets/1adbg-dej9t.gif)

