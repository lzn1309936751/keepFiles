﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 兔子数量
{
    class Program
    {
        static void Main(string[] args)
        {
            //0 1 1 2 3 5 8 13 21 34 55
            int now = 1,last=0;
            Console.Write("请输入月份：");
            int month=int.Parse(Console.ReadLine());
            for(int i=2;i<=month;i++)
            {
                int n = now;
                now += last;
                last = n;
            }
            Console.WriteLine("第{0}个月的兔子有{1}对。",month,now);
            Console.ReadKey();
        }
    }
}
