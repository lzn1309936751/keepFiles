﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Happy
{
    class Program
    {
        static void Main(string[] args)
        {
            while(true)
            {
                string word;
                Console.Write("请输入‘高兴’的英文单词：");
                word = Console.ReadLine();

                if(word!="happy")
                {
                    Console.WriteLine("输入错误，请重新输入！");
                }
                else
                {
                    Console.WriteLine("恭喜你，输入正确！");
                }
            }
        }
    }
}
