﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form2 : Form
    {
        int s=1;
        public Form2()
        {
            InitializeComponent();
        }
        int j = 0;
        private void timer1_Tick(object sender, EventArgs e)//时间
        {
            Random r = new Random();
            int a = r.Next(97, 123);
            Random n = new Random();
            int b = n.Next(1, 3);
            if (b == 1)
                lab1.Text = Convert.ToString(Convert.ToChar(a));
            else
                lab1.Text = Convert.ToString(Convert.ToChar(a - 35));
            j++;
            if (j == 10)
            {
                timer1.Enabled = false;
                j = 0;
            }
            s = 0;
        }
        int a = 0;
        private void but1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            lab2.Text = "";
            a = 0;
        }
        private void but1_KeyPress(object sender, KeyPressEventArgs e)
        {
            but1.Text = e.KeyChar.ToString();
            if (but1.Text == lab1.Text)
            {
                if (s==0)
                {
                    a++;
                    s = 1;
                }
                lab2.Text = "正确" + a + "";
            }
            
        }
    }
}
