﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace demo1
{
    class Program
    {
        static void Main(string[] args)
        {
            //demo1();
            #region 质因数递归
            /*
            do
            {
                Console.Write("请输入要分解的数字：");
                int num = int.Parse(Console.ReadLine());
                string s = Test(num, 2);
                Console.WriteLine(s.Substring(0,s.Length-1));
            } while (true);*/
            #endregion

            demo14();
            Console.ReadKey();
        }

        static void BookTypeDemo()
        {
            BookType[] types = {
                new BookType(1,"地理"),
                new BookType(2,"历史"),
                new BookType(3,"教育"),
                new BookType(4,"哲学"),
                new BookType(5,"法律"),
                new BookType(6,"小说"),
                new BookType(7, "美洲",1),//1，代表的是科幻的ID
                new BookType(23, "亚洲",1),
                new BookType(24, "欧洲",1),
                new BookType(25, "其它",1),
                new BookType(9, "亚洲",2),
                new BookType(10, "北美洲",2),
                new BookType(11, "欧洲",2),
                new BookType(12, "幼儿教育",3),
                new BookType(13, "义务教育",3),
                new BookType(14, "职业教育",3),
                new BookType(15, "中国",4),
                new BookType(16, "欧洲",4),
                new BookType(17, "古代",5),
                new BookType(18, "现代",5),
                new BookType(19, "科幻",6),
                new BookType(20, "玄幻",6),
                new BookType(21, "言情",6),
                new BookType(22, "恐怖",6),
                new BookType(26, "美国",7),
                new BookType(27, "加拿大",7),
                new BookType(28, "中国",23),
                new BookType(29, "日本",23),
                new BookType(30, "东北",28),
                new BookType(31, "华南",28),
                new BookType(32, "西北",28),
                new BookType(33, "新疆",32),
                new BookType(34, "甘肃",32),
                new BookType(35, "疆北",33),
                new BookType(36, "疆南",33)
            };
            ShowBookType(types, 0);
        }

        static void ShowBookType(BookType[] types,int pid,int level=0)
        {
            foreach (BookType item in types)
            {
                if (item.ParentId == pid)
                {
                    for (int i = 0; i < level; i++)
                    {
                        Console.Write("  ");
                    }
                    Console.WriteLine("{0}_{1}",item.TypeId,item.TypeName);
                    ShowBookType(types, item.TypeId,level+1);
                }
            }
        }

        static void demo1()
        {
            Console.Write("请输入要分解的数字：");
            int num = int.Parse(Console.ReadLine());
            int n = num;
            //90=2*3*3*5
            string s = "";
            string l = "";
            for (int i = 2; num != 1; i++)
            {
                if (num % i == 0)
                {
                    s += l + i;
                    num /= i;
                    i--;
                    l = "*";
                }
            }
            Console.WriteLine("{0}={1}", n, s);
            Console.Write("是否继续？y/n:");
            string op = Console.ReadLine();
            if(op=="Y" || op=="y")
                demo1();
        }

        static void demo2()
        {
            /*
                *
               ***
              *****
             *******
              *****
               ***
                *
             */
            int len = 5;
            for (int i = 1; i <= len; i++)
            {
                for (int j = 1; j <= len - i; j++)
                    Console.Write(" ");
                for (int j = 1; j <= 2 * i - 1; j++)
                    Console.Write("*");
                Console.WriteLine();
            }
            for (int i = 1; i < len; i++)
            {
                for (int j = 0; j < i; j++)
                    Console.Write(" ");
                for (int j = 1; j <= (len - i) * 2 - 1; j++)
                    Console.Write("*");
                Console.WriteLine();
            }

        }

        //鸡兔
        static void demo12()
        {
            //1、脚总量不能为奇
            //2、脚数量不能少于总数*2
            //3、脚数量不能多于总数*4

            int count = 35;
            int sum = 96;
            int num = sum - count * 2;
            int rabbit = num / 2;
            int chicken = count - rabbit;
            Console.WriteLine("鸡的数量{0},兔子的数量{1}",
                chicken, rabbit);
        }

        //拉灯
        static void demo14()
        {
            bool[] light = new bool[100];
            for (int i = 1; i <= 100; i++)
            {
                for (int j = i-1; j < light.Length; j+=i)
                {
                    light[j] = !light[j];
                }
            }
            Console.WriteLine("-------拉完后，灯亮的是：");
            for (int i = 0; i < 100; i++)
            {
                if(light[i])
                    Console.WriteLine(i+1);      
            }
        }

        //冒泡排序
        static void demo15()
        {
            int[] arr = { 25, 65, 47, 15, 3, 49, 72, 104, 11, 65 };
            for (int i = 0; i < arr.Length - 1; i++)
            {
                for (int j = 0; j < arr.Length - i - 1; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        int temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
                }
            }

            Console.WriteLine("排序后的结果");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + "  ");
            }

        }

        //递归

        static string Test(int num,int i)
        {
            string s = "";
            if (num != 1)
            {
                if (num % i == 0)
                {
                    s += i+"*";
                    num /= i;
                }
                else
                    i++;
                s+=Test(num, i);
            }
            return s;            
        }
    }
}
