﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _100元换币
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 100;
            double result =100;
            double sum1,sum2,sum3;
            //Console.WriteLine("请输入你想要的五元钞票的张数：");
            //int a = int.Parse(Console.ReadLine());
            //Console.WriteLine("请输入你想要的一元钞票的张数：");
            //int b= int.Parse(Console.ReadLine());
            int a,b,c = 0;           
            //分别代表五元、一元、五角的张数
            if (c % 2 == 0)
            {
                sum = a + b + c;
                c = sum - a - b;
                sum1 = 5 * a;
                sum2 = b;
                sum3 = 0.5 * c;
                result = sum1 + sum2 + sum3;
            }
            Console.WriteLine("五元有{0}张,一元有{1}张,五角有{2}张",a,b,c);
            Console.ReadKey();
        }
    }
}
