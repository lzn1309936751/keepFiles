﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 三角形
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i=1;i<=4;i++)
            {
                for (int j=3;j>=i;j--)
                {
                    Console.Write(" ");
                }
                for(int k=1;k<=2*i-1;k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
                Console.ReadLine();
        }
    }
}
