function $(id){
	return document.getElementById(id);
}
window.onload=function(){
	var oldX=0;
	var oldY=0;
	var flag=false;
	$("divMove").onmousedown=function(){
		flag=true;
		oldX=event.clientX;
		oldY=event.clientY;
	};
	$("divMove").onmousemove=function(){
		if(flag){
			var x=event.clientX;
			var y=event.clientY;
			this.style.top=(this.offsetTop+y-oldY)+"px";
			this.style.left=(this.offsetLeft+x-oldX)+"px";
			oldX=x;
			oldY=y;
		}
	};
	$("divMove").onmouseup=function(){
		flag=false;
	};
}