function Student(name,sex){
	this.stuName=name;
	this.stuSex=sex;
	this.study=function(){
		if(arguments.length>0){
			alert("正在学习"+arguments);
		}else{
			alert("普通学习");
		}
	};
	this.sleep=function(time){
		alert(time);
	};
	this.test=fntest;
	function fntest(){
		
	}
}