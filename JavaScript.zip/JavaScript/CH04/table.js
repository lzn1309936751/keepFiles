function $(id){
	return document.getElementById(id);
}
var orderNumber=5;
var oldTr=null;
var tableValue=[{name:"张三",age:"20",sex:"男"},
				{name:"张三",age:"21",sex:"男"},
				{name:"张三",age:"22",sex:"男"},
				{name:"张三",age:"23",sex:"男"}
		];
window.onload=function(){
	$("btnAdd").onclick=function(){
		var sname=$("txtName").value;
		var sAge=$("txtAge").value;
		var sSex=$("txtSex").value;
		
		var tr=document.createElement("tr");
		tr.onclick=function(){
			if(oldTr)
				oldTr.className="";
			tr.className="select";
			var sname=tr.childNodes[1].innerText;
			$("txtName").value=sname;
			var sAge=tr.childNodes[2].innerText;
			$("txtAge").value=sAge;
			var sSex=tr.childNodes[3].innerText;
			$("txtSex").value=sSex;
			oldTr=this;
		};
		var td=document.createElement("td");
		td.innerText=orderNumber++;
		tr.appendChild(td);//第一列
		var td=document.createElement("td");
		td.innerText=sName;
		tr.appendChild(td);//2
		var td=document.createElement("td");
		td.innerText=sAge;
		tr.appendChild(td);//3
		var td=document.createElement("td");
		td.innerText=sSex;
		tr.appendChild(td);//4
		
		//将行添加到表格的最后面
		$("t").appendChild("tr");
	}
}
function addRow(){
	
}
