function $(id){
			return document.getElementById(id);
		}
function Tree(data,divName){
	self=this;
	this.arr=data;
	this.isExpand=true;
	this.showcheckbox=true;
	this.init=function(){
			//innerHTML
		var tree = document.getElementById(divName);
		tree.innerHTML = this.createNode(arr,true);
		//为每个树节点中的checkbox绑定点击事件
		var cbks = tree.getElementsByTagName("input");
		for(var i=0;i<cbks.length;i++){
			if(cbks[i].getAttribute("type")=="checkbox"){
				cbks[i].onclick=function(){
					//将所有子节点的checkbox设为选中
					//td->tr->tbody->table->弟弟节点ul
					var childUl = this.parentNode.parentNode.parentNode.
						parentNode.nextElementSibling;
					if(childUl){//如果有子节点
						var c = childUl.getElementsByTagName("input");							
						for(var j=0;j<c.length;j++){
							if(c[j].getAttribute("type")=="checkbox"){
								c[j].checked=this.checked;
							}
						}
					}
					if(!this.checked){
						//如果为假，将父类的勾选去掉。
						self.removeCheck(this);
					}
				};
			}
		}
	};
	
	this.removeCheck=function(cbk){
		//td->tr->tbody->table->li->ul->哥哥table
		var parentCbk = cbk.parentNode.parentNode.parentNode
					.parentNode.parentNode.parentNode.
					previousElementSibling.getElementsByTagName("input");
		if(parentCbk && parentCbk[0].getAttribute("type")=="checkbox"){
			parentCbk[0].checked=false;
			this.removeCheck(parentCbk[0]);
		}
	};
	
	this.createMenu2=function(arr,root){
		var html="<ul class='root'>";
		var img="1.gif";
		if(!this.isExpand){
			img = "2.gif";					
			if(!root)
				html="<ul style='display:none;'>";
		}
		for(var i=0;i<arr.length;i++){
			var node=arr[i];
			html+="<li>";
			html+="<table>";
			html+="<tr>";
			html+="<td style='width:20px;'>";
			if(node.childs && node.childs.length>0)
				html+="<img src='"+img+"' onclick='self.expand(event);'/>";
			else
				html+="&nbsp;";
			html+="</td>";
			if(this.showcheckbox)
				html+="<td><input type='checkbox' /></td>"
			html+="<td>"+node.name+"</td>";
			html+="</tr>";
			html+="</table>";
			if(node.childs && node.childs.length>0){
				html+=this.createMenu2(node.childs,false);
			}
			html+="</li>";
		}
		html+="</ul>";
		return html;
	}
						
	this.expand=function(event){
		var o = event.srcElement;
		var ul =o.parentNode.parentNode.parentNode.parentNode.nextElementSibling;
		
		if(o.getAttribute("src")=="1.gif"){
			o.src="2.gif";
			ul.style.display="none";
		}
		else{
			o.src="1.gif";
			ul.style.display="block";				
		}
	}						
}