function fn_color(){
	document.body.style.background="lightblue";
}