function $(id){
	return document.getElementById(id);
}
window.onload=function(){
	var boo=true;
	$("btnSubmit").onclick=function(){
		
		var name=$("txtName").value;
		if(name==""){
			alert("姓名不能为空！");
			boo=false;
		}
		else{
			var testExp1=/^\d*$/;
			if(testExp1.exec(name)){
				alert("输入的姓名包含数字");
			}
			boo=false;
		}
			
		var age=$("txtAge").value;
		if(age!=""){
			if(isNaN(age)){
				alert("输入的年龄不是数字");
			}
			boo=false;
		}
		else{
			alert("年龄不能为空！");
			boo=false;
		}
				
		var email=$("txtEmail").value;
		if(email==""){
			alert("电子邮箱不能为空！");
			boo=false;
		}
		else{
			var testExp3=/^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/;
			if(testExp3.test(email))
				alert("电子邮箱格式正确");
			else
				alert("电子邮箱格式错误");
			boo=false;
		}
		if(boo)
			alert("提交成功");
		else
			alert("提交失败");
	}
}
