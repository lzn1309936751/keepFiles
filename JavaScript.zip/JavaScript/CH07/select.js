function $(id){
	return document.getElementById(id);
}

var address=[
	{
		name:"广东",id:1,city:[
			{name:"珠海",id:55,
			xian:[
					{name:"唐家湾区",id:53},
					{name:"斗门区",id:47,
						town:[
							{name:"白蕉镇",id:53},
							{name:"井岸镇",id:47}
							]
					},
					{name:"金湾区",id:38},
					{name:"香洲区",id:29},
					]
				},
			{name:"广州",id:44,
				xian:[
					{name:"白云",id:53},
					{name:"海珠",id:47},
					{name:"番禺",id:38},
					{name:"天河",id:29},
					]
			},
			{name:"佛山",id:33},
			{name:"中山",id:22},
			{name:"清远",id:11},
			{name:"揭阳",id:90,xian:[
					{name:"普宁",id:50},
					{name:"榕城",id:70},
					{name:"蓝城",id:68},
					{name:"东山",id:79},
					]
				
			}			
			]
	},
	{
		name:"广西",id:2,city:[
			{name:"柳州",id:65,
				xian:[
					{name:"寻乌2",id:10,
						town:[
							{name:"澄江",id:53},
							{name:"留车",id:47},
							{name:"南桥",id:38},
							{name:"长宁",id:29}
							]
					},
					{name:"会昌",id:19},
					{name:"于都",id:37},
					{name:"瑞金",id:28}
					]
			},
			{name:"南宁",id:45},
			{name:"桂林",id:35},
			{name:"防城港",id:15},
			{name:"来宾",id:12},		
			]
	},
	{
		name:"江西",id:3,city:[
			{name:"南昌",id:41,
				xian:[
					{name:"寻乌2",id:10,
						town:[
							{name:"澄江",id:53},
							{name:"留车",id:47},
							{name:"南桥",id:38},
							{name:"长宁",id:29}
							]
					},
					{name:"会昌",id:19},
					{name:"于都",id:37},
					{name:"瑞金",id:28}
					]
			},		
			{name:"赣州",id:11,
				xian:[
					{name:"寻乌",id:10,
						town:[
							{name:"澄江",id:53},
							{name:"留车",id:47},
							{name:"南桥",id:38},
							{name:"长宁",id:29}
							]
					},
					{name:"会昌",id:19},
					{name:"于都",id:37},
					{name:"瑞金",id:28}
					]
			}
			// {name:"南昌",id:41}		
			]
	}
];

window.onload=function(){
	createProvince();
	var a;
	var b;
	var c;
	$("cboProvince").onchange=function(){
		$("cboCity").options.length=0;
		$("cboXian").options.length=0;
		$("cboTown").options.length=0;
		for(var p of address){
			if(p.id==this.options[this.selectedIndex].value){
				for(var c of p.city){
					var op=new Option(c.name,c.id);
					$("cboCity").appendChild(op);
				}
				a=p.city;
				break;
			}
		}
	};
	$("cboCity").onchange=function(){
		$("cboXian").options.length=0;
		$("cboTown").options.length=0;
		for(var n of a){
			if(n.id==this.options[this.selectedIndex].value){
				for(var d of n.xian){
					var op=new Option(d.name,d.id);
					$("cboXian").appendChild(op);
				}	
				b=n.xian;
				break;
			}
			
		}
	};
	$("cboXian").onchange=function(){
		$("cboTown").options.length=0;
		for(var o of b){
			if(o.id==this.options[this.selectedIndex].value){
				for(var f of o.town){
					var op=new Option(f.name,f.id);
					$("cboTown").appendChild(op);
				}
				c=o.town;
				break;
			}
		}
	};
	$("setSelect").onclick=function(){
		$("cboProvince").selectedIndex=9;
	};
	$("btnDelete").onclick=function(){
		
		var index=$("cboProvince").selectedIndex;
		//删除某项1
		// $("cboProvince").options[index]=null;
		//print($("cboProvince").options.length);
		//删除某项2
		var op=$("cboProvince").options[index];
		$("cboProvince").removeChild(op);
		//清空
		// $("cboProvince").length=0;
	};
	$("btnAdd").onclick=function(){
// 		var op=new Option("黑龙江","55");
// 		$("cboProvince").appendChild(op);
		var op=document.createElement("option");
		op.setAttribute("value","33");
		op.text="吉林";
		$("cboProvince").appendChild(op);
	}
}

function createProvince(){
	print(address[2].city[1].name);
	for(var p of address){
		var op=new Option(p.name,p.id);
		$("cboProvince").appendChild(op);
	}
	for(var c of address[0].city){
		var op=new Option(c.name,c.id);
		$("cboCity").appendChild(op);
	}
	for(var d of address[0].city[0].xian){
		var op=new Option(d.name,d.id);
		$("cboXian").appendChild(op);
	}
	for(var f of address[0].city[0].xian[1].town){
		var op=new Option(f.name,f.id);
		$("cboTown").appendChild(op);
	}
}

function print(html){
	$("show").innerHTML+=html+"<br/>";
}