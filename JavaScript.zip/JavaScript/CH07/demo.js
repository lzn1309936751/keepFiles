window.onload=function(){
	// var form=document.forms[1];
	var form=document.forms["f1"];
	print(form.action);
	print(form.elements.length);
	
	$("btnSubmit").onclick=function(){
		var form=document.forms("f1");
		var html+="";
		for(var control of form.elements){
			if(control.type!="submit"&&control.type!="reset")
			html+=control.value+",";
		}
		print(html);
		return false;
	}
	$("btnSubmit2").onclick=function(){
		var form=document.forms("f1");
		var html+="";
		for(var control of form.elements){
			if(control.type!="submit"&&control.type!="reset")
			html+=control.value+",";
		}
		print(html);
		form.submit();
	}
	$("txtName").onclick=function(){
		
	}
	$("isEnable").onclick=function(){
			$("txtName").disabled=!this.checked();
		print($("txtName").value);
	}
	$("isRead").onclick=function(){
		$("txtNC").readonly=this.checked();
	}
	$("isDisplay").onclick=function(){
		if(this.checked)
			$("txtNC").style.disabled="none";
		else
			$("txtNC").style.disabled="inline-block";
	}
}
function print(html){
	$("show").innerHTML+=html+"<br />";
}
function $(id){
	return document.getElementById(id);
}