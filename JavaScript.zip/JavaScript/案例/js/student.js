var i=0;
var count=0;
window.onload=function(){
	var contain = document.getElementById("contain");
	for(var s of students){
		html="<span>"+s+"</span>";
		contain.innerHTML+=html;
	}
	
	var btn = document.getElementById("btnRand");
	btn.onclick=function(){
		var max=students.length;
		var min=0;
		var index = Math.floor(Math.random()*(max-min));
		var spans = contain.getElementsByTagName("span");
		if(i>0){
			spans[i-1].className="";
		}
		//i=0;
		count=0;
		var time = window.setInterval(function(){
			if(i>0)
				spans[i-1].className="";
			else if(i==0)
				spans[max-1].className="";
			spans[i].className="select";
//			window.opener.document.
//				getElementById("studentName")
//				.innerText=spans[i].innerText;
			window.opener.setStudent(spans[i].innerText);
			i++;
			count++;
			if(i==spans.length){
				i=0;	
			}
			if(count>index){
				window.clearInterval(time);
				
			}
		},100);
	};
	
	document.getElementById("btnSet").onclick=function(){
		alert(window.opener.document.getElementById("studentName"));
	};
};
