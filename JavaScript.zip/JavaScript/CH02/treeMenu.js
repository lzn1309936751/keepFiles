function treeMenu(json){
	this.json=json;
	
	this.loadMenu2=function(objson){
		var obj=document.getElementById(objson);
		if(obj){
			obj.innerHTML=this.createMenu2(this.json);
		}else{
			alert("没有此对象");
		}
	}
	this.createMenu2=function(createjson){
		var html="";
		if(createjson.length>0){
			html+="<ul>";
			for(var i=0;i<createjson.length;i++){
				html+="<li>";
				html+="<a>"+createjson[i].text+"</a>";
				html+=this.createMenu2(createjson[i].child);
				html+="</li>";
			}
			html+="</ul>";
		}
		return html;
	}
}