function Menu(json){
	this.json=json;

	this.loadMenu=function(objId) {
		//先获取DIV或其他容器对象
		var obj = document.getElementById(objId);
		if(obj){
			obj.innerHTML=this.createMenu(this.json);
		}else{
			alert("没有这个对象！");
		}
	}
//递归方法
	this.createMenu=function(jsonObj){
		var html="";
		if(jsonObj.length>0){
			html+="<ul>";
			for(var i=0;i<jsonObj.length;i++){
				html+="<li>";
				html+="<a href='"+jsonObj[i].link+"'>"+jsonObj[i].text+"</a>";
				html+=this.createMenu(jsonObj[i].child);
				html+="</li>";
			}
			html+="</ul>";
		}
		return html;
	}
}
