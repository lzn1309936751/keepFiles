function $(id){
	return document.getElementById(id);
}
function txt(text){
	var p=document.createElement("div");
	p.appendChild(copy());
	p.setAttribute("class","text");
	if(text!=null){
		p.appendChild(document.createTextNode(text));
	}
	p.onclick=function(){
		p.setAttribute("class","reddiv");
	}
	p.appendChild(del());
	return p;
}
function copy(){
	var copy=document.createElement("span");
	copy.setAttribute("class","btnCopy");
	copy.appendChild(document.createTextNode("复制"));
	copy.onclick=function(){
		var copys=this.parentNode.cloneNode(true);
		$("phone").appendChild(copys);
		copydivs(btnCopys);
	}
	return copy;
}
var btndel=document.getElementsByClassName("btndel");
var btnCopys=document.getElementsByClassName("btnCopy");
function copydivs(btnCopys){
	for (var i=0;i<btnCopys.length;i++) {
		btnCopys[i].onclick=function(){
			var newCopys=this.parentNode.cloneNode(true);
			$("phone").appendChild(newCopys);
			btnCopys=document.getElementsByClassName("btnCopy");
			copydivs(btnCopys);
			deldivs(btndel);
		}
	}
}
function del(){
	var del=document.createElement("span");
	del.setAttribute("class","btndel");
	del.appendChild(document.createTextNode("X"));
	del.onclick=function(){
		$("phone").removeChild(this.parentNode);
	}
	return del;
}
function deldivs(btndel){
	for (var i=0;i<btndel.length;i++) {
		btndel[i].onclick=function(){
			var newCopys=this.parentNode;
			$("phone").removeChild(newCopys);
			btndel=document.getElementsByClassName("btndel");
			deldivs(btndel);
		}
	}
}
window.onload=function(){
	$("box1").onclick=function(){
		$("phone").appendChild(txt("在右侧编辑文本"));
	};
	$("box2").onclick=function(){
		
		$("phone").appendChild(txt("在右侧编辑标题"));
	};
	$("box3").onclick=function(){
		var a=document.createElement("div");
		a.appendChild(copy());
		a.setAttribute("class","image");
		a.onclick=function(){
			a.setAttribute("class","redimg");
		}
		a.appendChild(del());
		$("phone").appendChild(a);
	};
}
