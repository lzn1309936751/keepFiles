$(function(){
	$("#id").keypress(function(){
		if(event.keyCode<48||event.keyCode>57)
			event.returnValue=false;
	});
	$("#btnAdd").click(function(){
		var pname=$("#name").val();
		if(pname==""){
			alert("商品不能为空");
			$("#name").focus();
			return;
		}	
		var price=$("$price").val();
		if(isNaN(price)){
			alert("数字格式不正确，请检查");
			return;
		}
	});
	$("#price").keypress(function(){
		if((event.keyCode<48&&event.keyCode!=46)||event.keyCode>57)
			event.returnValue=false;
	})
})