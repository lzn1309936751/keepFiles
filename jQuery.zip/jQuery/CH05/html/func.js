$("div").CSS("background-color","red");
function myFunc(){
	$("p").CSS("text-decoration","underline");
}