1.不加controller注解出现什么问题？

​           没反应，不报错，无法获得路径。

2.controller注解换为Component注解是什么情况

​          没反应，不报错，无法获得路径。

3.RequestMapping注解写为@RequestMapping("") 和@RequestMapping("/")各是什么情况

​          @RequestMapping("")：客户端和控制台都有输出，获得路径为（）。

​          @RequestMapping("/")：客户端和控制台都有输出，获得路径为（/）。

4.InternalResourceViewResolver删掉，直接在控制器类的方法里面写死地址，比如return "WEB-INF/jsp/hello.jsp出现什么情况

​          客户端和控制台都有输出，获得路径为（/index）。

5.InternalResourceViewResolver去掉前缀与后缀的配置或者只配前缀或只配后缀情况怎么样？？

​          去掉前缀与后缀：控制台都有输出，无法获得路径。

​          去掉前缀：控制台都有输出，无法获得路径。

​          去掉后缀：控制台都有输出，获得路径为（/hello.jsp）。

6.控制器类的方法名字可以任意吗？

​			可以。

7.控制器类的方法可以是静态的吗？

​			可以。

8.控制器类的方法可以返回任意类型吗？比如返回你自己写的一个类

​			可以返回任意类型，但是，路径名必须要和jsp的名字相同。			

9.在jsp页面里面遍历输出请求作用域所有的attribute，看看里面有什么？



10.ModelAndView类的数据放到哪里了？为什么jsp里写el表达式可以取出来？



11.既然创建出了一个spring容器，如何获取这个容器呢？

​			@Autowired

​			ApplicationContext context;

12.如果能获取到这个spring容器，容器里面都有多少管理的bean？输出这些bean的名字

​			7个，

​			helloController
​			org.springframework.context.annotation.internalConfigurationAnnotationProcessor
​			org.springframework.context.annotation.internalAutowiredAnnotationProcessor
​			org.springframework.context.annotation.internalCommonAnnotationProcessor
​			org.springframework.context.event.internalEventListenerProcessor
​			org.springframework.context.event.internalEventListenerFactory
​			org.springframework.web.servlet.view.InternalResourceViewResolver