

# Spring

## Spring-Context
### Spring-Context概述

spring-context相当于一个容器，用于放置一些类，在需要时取出使用。但需要注意的是，它只能存放一些可实例化的类，如接口、抽象类等spring-context对其是失效的。

注：**在JAVA显目中，一般是dao，service，部分工具类可以被spring管理，servlet一定是不能被spring管理的。实体类从技术角度来说，是可以被管理的，但一般不会这么做。**
###spring-context的使用



1、添加spring-context的依赖：

```java
<dependencies>
            <dependency>
                <groupId>org.springframework</groupId>
                <artifactId>spring-context</artifactId>
                <version>5.2.0.RELEASE</version>
            </dependency>
</dependencies>
```

2、创建一个spring的xml配置文件（元数据）：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
       http://www.springframework.org/schema/beans/spring-beans.xsd">
        
</beans>
```

3、使用bean元素管理类,例如先配置一个EmployeeDao类：

```xml
<!--class:类全称 scope:作用域-->
<bean id="first" class="hello.EmployeeDao"></bean>
```

4、获得bean配置的类的实例

```java
ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
//EmployeeDao dao = (EmployeeDao)context.getBean("first");
EmployeeDao dao = context.getBean("first",EmployeeDao.class);
```

#### 容器的启动与关闭
容器启动指的是利用ApplicationContext接口根据元数据的类路径创建其实例，此时代表容器已经启动。
容器关闭则需要将ApplicationContext强制转换为ConfigurableApplicationContext类型，然后调用close方法，即表示关闭了容器。

### Spring的作用域
即bean够被spring有效管理的范围

#### prototype

```xml
<bean id="first" class="hello.EmployeeDao" scope="prototype"></bean>
```

原型，表示在每次调用getBean方法时都反复会创建新对象



#### singleton

```xml
<bean id="first" class="hello.EmployeeDao" scope="prototype"></bean>
```

单例，表示在容器启动(即创建ApplicationContext实例对象时)创建一个对象，之后不再创建。(在容器启动时，元数据中所有作用域为singleton的bean管理的类都会创建出来)



#### request
请求，在一次完整的请求周期中有效被spring管理。
#### session
会话，在一个session中有效，不同的session之间互不干扰。
注：**request和session作用域都是在web环境下才有效**

### Spring的生命周期
指每个bean管理的类的初始化与销毁方法的执行情况

#### 1.初始化与实例化

```test
其过程：静态字段--静态代码块--实例代码块--构造函数
```

初始化一般是指在实例化完成后，再干一些必要的事情，例如写一个init方法并在构造函数调用。

#### 2.初始化方法与销毁方法
初始化方法一般在被管理对象初始化时调用，销毁方法则是在容器关闭时调用。一般命名为init和destroy。

1、在beans元素中加入default-init-method或default-init-method表示全局的方法设置

2、在某个bean元素中添加init-method或destroy-method即为具体的方法设置

3、若两者同时存在，具体的设置将会覆盖全局设置



#### 3.prototype中的生命周期

容器启动时，相当于在容器中添加了一个键值对，key是bean元素的id，value是bean元素所管理的类的信息或者说描述。当调用getBean方法时，会根据value创建被管理对象的实例，但容器关闭时，该管理对象中的destroy方法将被java中的垃圾回收器回收，所以prototype作用域的destroy方法是无法生效的。



#### 4.singleton中的生命周期

与prototype不同的是，因为是单例，所以容器中键值对的value所保存的是被管理对象的实例。就是或容器启动时，被管理对象就已经被创建了。destroy方法则是在容器关闭时执行。



#### 5.lazy-init

bean元素中的一个属性，设置为true时，对被管理对象有延迟初始化的作用。

### 实例化Bean

#### 工厂实例化Bean

```java
public class AFactory{
    private static A anstance = new A();
    public static A createA(){
        return anstance;
    }
    public A createB(){
        return anstance;
    }
}
```



工厂类静态方法实例化Bean：

```xml
<bean id="factory" class="lifecycle.AFactory" factory-method="createA"/>
```

根据给定的类的方法得到对象，但前提是该方法必须是静态方法。

工厂类实例方法创建：

```xml
<bean id = "factory" class="lifecycle.AFactory"></bean>
<bean id="factory2" factory-bean="factory" factory-method="createB"/>
```

#### 接口FactoryBean<T>实例化Bean

个人理解：实现该接口的工厂类必须实现三个方法，有一个getObject方法此方法的返回类型是根据FactoryBean接口的泛型来决定的。在元数据中配置此工厂类的吧bean以后在实例化这个Bean的时候，相当于是调用了工厂类的getObject方法，所以ApplicationContext的getBean方法就会返回A的实例，而不是

java代码：

```java
public class MyFactoryBean implements FactoryBean<A> {
	/**
     * 这个方法用来创建一个对象
     * @return
     * @throws Exception
     */
    public A getObject() throws Exception {
        return new A();
    }

     /**
     * 这个方法是用来表明此工厂Bean创建出来的对象的class
     * @return
     */
    public Class<?> getObjectType() {
        return A.class;
    }

    /**
     * 这个方法表明此工厂Bean创建出来的对象,在spinrg管理下的作用域
     * true表示是singleton
     * @return
     */
    public boolean isSingleton() {
        return true;
    }
}
    
```

元数据配置：

```xml
<bean id="factory" class="MyFactoryBean"></bean>
```





## IOC控制反转（inverse of control）

****IOC = DI (dependency injection) 依赖注入****

假设有两个类 UserService,UserDao

###### 不反转的情况：

```java
service = new UserService();
service.setDao(new UserDao);
```

因为上面的UserService类需要userDao,给其添加userDao实例的过程是由自己写代码控制,就是一切都在自己的掌握中.这种情况就叫做不反转。

###### 反转的情况：

```java
context.getBean("Uservice", UserService.class);
```

上面的代码执行完毕后,userService已经帮其设置了userDao



### 依赖注入

  所有被spring管理的bean，当它依赖一个其它被spring管理的bean的时候，spring负责把其注入进来。

#### 1.spring 管理的依赖注入的形式有三种：

​	1 . 构造函数的注入

​    2 . 属性注入（setter)

​	3 . 接口注入（不推荐使用）

#### 2.构造函数注入：

模糊性解决办法有三个：1、name，2、index，3、type

```java
//创建一个实体类
public class DbConfig{
    private String url;
    private String username;
    private String password;
    private String driverClassname;
    
    public DbConfig(String url, String username, String password) {
        this.url = url;
        this.username = username;
        this.password = password;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDriverClassname() {
        return driverClassname;
    }

    public void setDriverClassname(String driverClassname) {

        this.driverClassname = driverClassname;
    }

    @Override
    public String toString() {
        return "DbConfig{" +
                "url='" + url + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", driverClassname='" + driverClassname + '\'' +
                '}';
    }
}

```

```xml
<!-- 下面的配置顺序与你创建的实体类的构造函数是一一对应,所以不再需要额外的设置-->
    <bean id="dbConfig" class="DbConfig">
        <constructor-arg value="url.."/>
        <constructor-arg value="root"/>
        <constructor-arg value="pwd"/>

        <property name="driverClassname" value="driver"/>
    </bean>


<!--
   当下面的构造设置顺序与想复制的类的构造函数顺序不一致时
   不能仅仅只是设置一个value,还需要额外的信息告诉
   spring,谁赋值给谁  -->

    <bean id="dbConfig" class="DbConfig">
        <!--本来这个root应该是赋值给url,但因为加了name=username
        所以就把root 赋值给了构造函数的第二个参数
        -->
        <constructor-arg value="root" name="username"/>
        <constructor-arg value="pwd" name="password"/>
        <constructor-arg value="url.." name="url"/>

        <property name="driverClassname" value="driver"/>
    </bean>

<!-- 上面这种配置还有个弊端，那就是一般我们实例构造函数的时候他的参数值名一般都是arg0,arg1这种命名方式来，所以使用上面这种的话，你通过name属性声明的值就与其不对应，从而会报错。 -->


<!-- 下面这个是跟据构造函数里的位置来通过index属性让其一一对应 -->
	<bean id="dbConfig" class="DbConfig">

        <constructor-arg value="root" index="1" />
        <constructor-arg value="pwd" index="2"/>
        <constructor-arg value="url.." index="0"/>

        <property name="driverClassname" value="driver"/>
    </bean>

```





#### 3.基本类型注入(UserInfo)：

1. 普通属性(name)
2. 对象属性 (Address)
3. List属性
4. Map
5. Set
6. Properties:  配置的时候，值只能是String类型

```java
//创建一个UserInfo实体类
public class UserInfo {
    private Address address;
    String name;

    private List<Address> addressList;

    private List<String> hobbyList;

    private Set<String> xueLi;

    private Map<String,Integer> xueFen;

    private Properties properties;

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getHobbyList() {
        return hobbyList;
    }

    public void setHobbyList(List<String> hobbyList) {
        this.hobbyList = hobbyList;
    }

    public Set<String> getXueLi() {
        return xueLi;
    }

    public void setXueLi(Set<String> xueLi) {
        this.xueLi = xueLi;
    }

    public Map<String, Integer> getXueFen() {
        return xueFen;
    }

    public void setXueFen(Map<String, Integer> xueFen) {
        this.xueFen = xueFen;
    }

    public Properties getProperties() {
        return properties;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    public List<Address> getAddressList() {
        return addressList;
    }

    public void setAddressList(List<Address> addressList) {
        this.addressList = addressList;
    }

    @Override
    public String toString() {
        return "UserInfo{" +
                "address=" + address +
                ", name='" + name + '\'' +
                ", addressList=" + addressList +
                ", hobbyList=" + hobbyList +
                ", xueLi=" + xueLi +
                ", xueFen=" + xueFen +
                ", properties=" + properties +
                '}';
    }
}
```

​		配置时，一般是java类型对应同样名字的配置元素，比如Lsit集合，就用list来配置，Set集合就用set 元素来配置。集合类型与配置元素类型都会其起作用：意思是Set集合类型的元素里面是不能重复的，如果你用List元素配置了重复的内容，但Set集合仍然不会有重复，如果你是List集合，但用set元素来配置，就可以让此List集合内部没有重复。     同样还可以内部bean 的配置。**注意点：类型跟元素一般是一样，两者都其效果**

```xml
<bean id="addr" class="inject.basic.Address">
        <property name="province" value="gd"></property>
        <property name="city" value="zhuhai"/>
    </bean>
    <bean id="userInfo" class="inject.basic.UserInfo">
        <property name="name" value="aaaa"/>
       <!-- <property name="address" ref="addr"/>-->
        <!--下面的配置方式叫做inner bean(内部bean)
            只是给address属性使用,无法通过getBean方式得到这个对象
        -->
        <property name="address" >
            <bean class="inject.basic.Address"/>
        </property>
        
        <property name="hobbyList" >
            <list>
                <value>football</value>
                <value>basketball</value>
                <value>basketball</value>
            </list>
        </property>
        
        <property name="xueLi">
            <set>
                <value>chu zhong</value>
                <value>gao zhong</value>
                <value>gao zhong</value>
            </set>
        </property>
        
        <property name="xueFen">
            <map>
                <entry key="yuwen" value="95"/>
                <entry key="shuxue" value="100"/>
            </map>
        </property>
        
        <!--如果用props配置,值只能是字符串类型-->
        <property name="properties">
            <props>
               <prop key="javaT">111</prop>
               <prop key="netT">yongguang</prop>
            </props>
        </property>

        <property name="addressList">
            <list>
                <ref bean="addr"/>
                <bean class="inject.basic.Address">
                    <property name="city" value="ganzhou"/>
                    <property name="province" value="jiangxi"/>
                </bean>
            </list>
        </property>
    </bean>
```

#### 4. 命名空间

##### 1. p命名空间 :

​	p是property的缩写

##### 2. c命名空间

​	c是constructor-arg的缩写

```java
//先创建一个实体类
public class MyDataSource {

    private String url;

    public MyDataSource(String url) {
        this.url = url;
    }

    private String username;
    private String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "MyDataSource{" +
                "url='" + url + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
```

```xml
<bean id"dataSource" class="MyDataSource" >
    <property name="username" value="sa"/>
    <property name="password" value="sa"/>
</bean>

<!-- 使用p命名空间、c命名空间 -->
<bean id"dataSource" class="MyDataSource" p:username="sa" c:url="url--">
</bean>

<!-- 使用p名空间、c命名空间的同时还要在这个xml文件<beans>标签中加条属性 -->
 xmlns:p="http://www.springframework.org/schema/p"
 xmlns:c="http://www.springframework.org/schema/c"
```

如果你忘了上面配置p命名空间、c命名空间里面的路径的话，你可以参考下面这个配置的路经“http://www.springframework.org/schema/” 斜杆后加你要使用的东西标签

```xml
xsi:schemaLocation="http://www.springframework.org/schema/beans“
```



####  5. 父子bean定义

```xml
<!--在子bean里面设置了parent属性,只是表明在xml配置中会有继承配置的关系
并不要求实际的java类有继承关系

当一个bean设置abstract为true的时候,意思就是告诉spring不要实例化这个bean出来
跟实际的java类是否是抽象无关

一般情况如果一个bean的主要的作用是给子bean继承用,其class可以不设置
-->

<bean id="myParent" abstract="true">
	<property name="p1" value="p1"/>
    <property name="p2" value="p2"/>
</bean>
<bean id="childOne" class="ChildOne" parent="myParent">
    <property name="childOne" value="childOne"/>
</bean>
```



#### 6. null值处理

```xml
 <bean id="dataSource"
        class="inject.namespace.MyDataSource"  p:username="sa" c:url="url--" >
      <property name="password" >
          <null></null>
      </property>
    <!-- <constructor-arg>
  <null></null>
     </constructor-arg>   -->
  </bean>
```

​	null值处理简单的来说就是给一个参数赋空值，而在property这个标签中没有任何属性是可以给值赋空，value属性也不能，所以只能按上述的案例来实现空值赋予。同样constructor-arg标签也是一样。



 #### 7.复合(compound)属性设置

什么是复合属性

一个类嵌套了另一个类，另一个类又嵌套了另一个类...

而此时第一个类之外其他类的属性，对于第一个类来说，都是复合属性。

案例：

```java
   public class Type{
    	private Integer typeid;
    	private String typename;
    }
    public class Product{
        public Product(){
            this.type = new Type();
        }
    	private Type type;
    }
```

```xml
   <bean id="type" class="Type"></bean>
    <bean id="product" class="Product">
    	<property name="type.typeid" value="饮料"/>
    </bean>
```

 通过上面的案例可以看出，在为typeid属性注入值时，必须保证Product的type属性不为空，否则就会报错(NullValueInNestedPathException)。因为，typeid是Type类的属性，而若是Product类中类型为Type的属性未赋值，访问它的属性当然会出问题。  

### 自动装配(autowire)

##### 自动装配的理解：

 1. 启动spring容器

 2. 扫描xml文件

 3. spring就知道所有被它管理的bean

 4. 每个bean，spring通过反射是不是都知道其类型，以及构造函数，以及所有的属性(property)

 5. 因为bean的作用域是singleton，所以spring要创建出对象，创建对象包含实例化和初始化

    5. 1 实例化就是调用构造函数，如果构造函数有依赖，spring就会尝试解决这个依赖是什么东西

    5. 2 初始化：所有的属性，spring都尝试帮你注入值进来

6. spring尝试给某个bean所有依赖的东西，帮你注入进来

7. 如果你配置了自动装配，那么spring就帮你找一个合适的

8. 如何找呢？需要依据自动装配类型的设置，autowire的值

       8. 1 byType：因为你的Service类依赖的类型是UserDao，spring又知道所有被它管理的UserDao  bean配置只有一个所以就自动帮你注入这一个，如果找到多个：报错

   8. 2 byName：找到service类里面有一个属性名叫dao，找所有被管理bean的名字为dao的，就帮你注入，如果找到的bean id值为dao的类型不符合要求，也会报错



```xml

<bean id="userDao" class="autowire.UserDaoImpl" ></bean>
<bean id="userService" class="autowire.UserServiceImpl"  autowire="byType"/>

<bean id="dao" class="autowire.UserDaoImpl" ></bean>
<bean id="userDao2" class="autowire.UserDaoImpl2"  ></bean>
<bean id="userService"
      class="autowire.UserServiceImpl"  autowire="byName">

</bean>


<!--如果有多个bean符合自动装配
可以通过在所有符合条件的被装配bean上进行设置来解决
1.在想被注入的bean上设置primary=true,就表示用这个
2. 在不想被注入的bean上设置autowire-candidate=false

还可以在beans这个根元素上,配置default-autowire-type来设定
一个全局的自动装配类型,这样就不需要在每一个bean上进行设置了

beans上的default-autowire-candidates =设置作为候选baen的名字模式
多个之间用逗号分隔,比如*dao这个名字,意思就是以dao结尾的bean 的名字
    -->

default-autowire-candidates="*dao" default-autowire="byType"
<!--将其配置到beans标签里，就能实现多个bean符合自动装配，同时也不用在每个bean上进行设置-->
```



自动装配的四种属性：1. byType , 2 . byName , 3 . constructor , 4 . no;





### 研究 singleton、prototype 所有方法的执行顺序

```java
public class A implements InitializingBean, FactoryBean {
    private B b;

    public A(B b) {
        System.out.println("构造函数：b = " + b);
        this.b = b;
    }



    public void setB(B b) {
        System.out.println("set:B =" + b);
        this.b = b;
    }


    @Override
    public Object getObject() throws Exception {
        System.out.println("getObject:b = " + b);
        return new B();
    }

    @Override
    public Class getObjectType() {
        System.out.println("getObjectType:b = " + b);
        return b.getClass();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        System.out.println("afterPropertiesSet:b = " + b);
    }
}

class B {}
class C {}


public class Main {
    public static void main(String[] args) {
        ApplicationContext context = new 	ClassPathXmlApplicationContext("applicationContext_mybatis.xml");
        B b = context.getBean("a",B.class);
        B bq = context.getBean("a",B.class);
        System.out.println("b = " + b);
        System.out.println("b = " + bq);
    }
}

```

```xml
<bean id="b" class="com.homework.B" />
<bean id="a" class="com.homework.A">
    <constructor-arg ref="b"/>
    <property name="b" ref="b"></property>
</bean>


```

（单例）启动容器时：getObject()方法不会被调用，而其他方法的先后顺序执行是：构造函数——set()方法——afterPropertiesSet()方法——getObjectType()方法。

（原型）启动容器时：则什么都不执行

（单例）使用getBean()输出时：方法的执行先后顺序是：构造函数——set()方法——afterPropertiesSet()方法——getObjectType()方法——getObject()方法。并且使用单例，在new一个对象时，会将其储存起来，下次在调用的话，就会使用储存的那个对象而不会重新new一个新对象。

（原型）使用getBean()输出时：getObjectType()方法不会被调用，方法的执行先后顺序是：构造函数——set()方法——afterPropertiesSet()方法——getObject()方法。并且使用原型，在new一个对象时，则不会会将其储存起来，下次在调用的话，会重新new一个新对象。





首先实例化：构造函数会先执行

2. 进行装配（wire)：帮我们注入（如果有设定显示的注入或者自动注入）
3. 执行afterPropertiesSet
4. 执行你指定的init方法：因为init方法按照spring的要求是午餐无返回值的，那么afterPropertieSet也是无参无返回值的，所以如果你设定的自定义init方法就是afterPropertiesSet，那么此方法不会执行两次。

详细流程如下：

	1. instantiate 
 	2. populate properties
 	3. BeanNameAware.setBeanName()
 	4. BeanFactoryAware.setBeanFactory()
 	5. BeanPostProcessor.postProcessBeforeInitialization()
 	6. InitializingBean.afterPropertiesSet()
 	7. 调用指定的init-method
 	8. BeanPostProcessor.postProcessAfterInitiallization()
 	9. Bean 可以用了
 	10. Spring容器销毁（close方法）
 	11. DisposableBean.destroy()
 	12. 结束



### mybatis-spring整合

	#### 使用applicationContext.xml

在使用applicationContext时，如果是在一个servlet中调用，那么只需要下面代码这么写

```java
ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
```

如果是多个servlet的话，那么我们就用使用ServletContextListener监听器来使用它，使用监听器的好处是我们不需要每一个servlet中new一个applicationContext对象，这样能使我们节省性能，空间等。

```java
public class ApplicationContextInstantiateListener implements ServletContextListener {
    public static final String SPRING_CONTAINER_KEY = "SPRING_CONTAINER";
    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        ServletContext servletContext = servletContextEvent.getServletContext();
        servletContext.setAttribute(SPRING_CONTAINER_KEY,context);

    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {

    }
}
```

使用监听器时要注意还要在其web项目中的WEB-INF里的web.xml文件中部署配置

```xml
   <listener>
        <listener-class>com.spring.ApplicationContextInstantiateListener</listener-class>
    </listener>
```

最后在创建一个工具类来获取上下文路径找到的context对象

```java
  public static ApplicationContext getApplicationContext(HttpServletRequest req ){
        ServletContext servletContext = req.getServletContext();
        ApplicationContext context = (ApplicationContext) servletContext.getAttribute(ApplicationContextInstantiateListener.SPRING_CONTAINER_KEY);
        return context;
    }
```

当然以上案例也不是很简便，我们还可以通过ApplicationContextAware接口来自动获取。

```java
/** 此监听器用来创建spring容器对象
 *
 * 因为这个监听器是servletContext监听器,在容器启动时会被调用
 * 并且只会调用一次
 */
public class ApplicationContextInstantiateListener implements ServletContextListener {
    public static final String SPRING_CONTAINER_KEY = "SPRING_CONTAINER";
    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        ServletContext servletContext = servletContextEvent.getServletContext();
        String configFille = servletContext.getInitParameter("configFile");
        ApplicationContext context = new ClassPathXmlApplicationContext(configFille);

        servletContext.setAttribute(SPRING_CONTAINER_KEY,context);

    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {

    }
}

public class ApplicationContextHolder implements ApplicationContextAware {

    private static ApplicationContext context;
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        context = applicationContext;
    }

    public static ApplicationContext getApplicationContext(){
        return context;
    }

    public static <T> T getBean(String name,Class<T> clz){
        return context.getBean(name,clz);
    }
}

```

同样也要在web项目中部署其监听器

```xml
    <context-param>
        <param-name>configFile</param-name>
        <param-value>applicationContext.xml</param-value>
    </context-param>
    <listener>
        <listener-class>com.spring.ApplicationContextInstantiateListener</listener-class>
    </listener>




<!--同样还必须在applicationContext.xml中部署
配置此bean是因为此bean实现了ApplicationContextAware
被spring管理后会自动往此bean里面注入spring容器对象
-->
    <bean class="com.spring.ApplicationContextHolder"/>
```

最后还有一种是使用插件来快速获取context对象

```xml
  <dependency>
                <groupId>org.springframework</groupId>
                <artifactId>spring-web</artifactId>
                <version>5.2.0.RELEASE</version>
            </dependency>
```

通过上面这个插件，我们使用该插件中的工具类

```java
 ApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(req.getServletContext());
```



### 使用spring读取外部properties文件

```xml
<!--下面配置相当于让spring读取外部的properties文件
	placeholder：占位符的意思

spring会读取很多地方的一些属性，比如当天操作系统的环境变量，jdk设置的属性值等

所以某些环境可能导致properties文件的内容会被其他覆盖，所以建议设置一个local-override=true

-->    

	<context:property-placeholder location="classpath:db.properties" local-override="true"/>
    <bean id="dataSource" class="com.alibaba.druid.pool.DruidDataSource">
        <property name="username" value="${jdbc.username}"/>

        <property name="password" value="${jdbc.password}"/>
        <property name="url" value="${jdbc.url}"/>
    </bean>	    
```

### ant地址格式

```xml
<bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
        <property name="dataSource" ref="dataSource"></property>
        <!--
	前缀classpath是spring拥有的一种查找资源的方式，意思就是在当前项目的类路径下面查找文件   classpath* 这个前缀是在当前项目的类路径以及他所依赖的其他jar文件里面找

	configLocation就是引入mybatis的配置文件，其不支持classpath*前缀，也不支持ant风格的文件路径格式
			
	分析spring源代码可以知道，当bean的属性类型是Resource类型时，用ResourceEditor来把字符串转化为Resource类型，当bean的类型是Resource[]类型时，用ResourceArrayPropertyEditor来把字符串转换为Resource[]类型

	ResourceEditor用到的是ResourceLoader,其就不支持classpath*前缀，并且也不支持ant风格的路径格式

	而ResourceArrayPropertyEditor用的是ResourcePatternResolver(ResourceLoader子类型)，它支持classpath*前缀，也支持ant风格的路径


ant地址格式：classpath*:a/**/*mapper.xml:满足此ant地址格式的文件名有如下几个：
1: a/b/amapper.xml
2: a/b/bmapper.xml
3: a/b/abcmapper.xml
4: a/b/c/abcmapper.xml
**: 多段的意思
classpath*: com/dao/**/*mapper.xml			
		-->
         <property name="configLocation" value="classpath:mybatis-config.xml"/>
    </bean>

```

### import导入配置文件

​	概述：import就是用来导入其他的配置文件，作用类似于复制粘贴，最终的效果其实就可以相当于只有一个配置文件

​	案例：

```xml
<!--spring-mybatis.xml:-->
<bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
        <property name="dataSource" ref="dataSource"/>
        <!--指定mapper文件-->
        <property name="mapperLocations" value="classpath*:com/dao/**/*Mapper.xml"/>
        <!--mybatis-config文件解析之后mybatis是用Configuration类型来代表(入口对象)-->
        <property name="configuration">
            <bean class="org.apache.ibatis.session.Configuration">
                <!--配置显示sql的日志-->
                <property name="logImpl" value="org.apache.ibatis.logging.stdout.StdOutImpl"/>
            </bean>
        </property>
        <property name="plugins">
            <list>
                <bean class="com.github.pagehelper.PageInterceptor">
                    <property name="properties">
                        <!--   <props>
                               <prop key="supportMethodsArguments">true</prop>
                               <prop key="reasonable">true</prop>
                           </props>
   -->
                        <value>
                            supportMethodsArguments=true
                            resonable=true
                        </value>
                    </property>
                </bean>
            </list>
        </property>
    </bean>

    <mybatis:scan base-package="com.dao"/>


<!--一个要导入其上方要使用其配置的配置文件-->

<import resource="classpath*:spring-mybatis.xml"/>
    <bean id="dataSource" class="com.alibaba.druid.pool.DruidDataSource">
        <property name="url" value="jdbc:mysql://localhost:3306/demo"/>
        <property name="password" value="root"/>
        <property name="username" value="root"/>
    </bean>
```



### spring与mybatis整合的两种方式

​	两种方式：一种是有mybatis-config.xml这个配置文件的，一种是没有用mybatis-config.xml配置文件的。

```xml
<!--第一种：使用mybatis-config.xml-->

  <context:property-placeholder location="classpath:db.properties" local-override="true"/>
        <bean id="dataSource" class="com.alibaba.druid.pool.DruidDataSource">
            <property name="username" value="${jdbc.username}"/>

            <property name="password" value="${jdbc.password}"/>
            <property name="url" value="${jdbc.url}"/>
        </bean>

    <bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
        <property name="dataSource" ref="dataSource"></property>
        <property name="configLocation" value="classpath:mybatis-config.xml"/>
    </bean>


<!--第二种：不使用mybatis-config.xml-->
 <bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
        <property name="dataSource" ref="dataSource"/>
        <!--指定mapper文件-->
        <property name="mapperLocations" value="classpath*:com/dao/**/*Mapper.xml"/>
       
        </property>
    </bean>
```

如果你没有使用mybatis-config.xml配置文件，用想要让其输出格式为日志输出的话，那么下面案例就可以当作参考

```xml
 <bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
        <property name="dataSource" ref="dataSource"/>
        <!--指定mapper文件-->
        <property name="mapperLocations" value="classpath*:com/dao/**/*Mapper.xml"/>
        <!--mybatis-config文件解析之后mybatis是用Configuration类型来代表(入口对象)-->
        <property name="configuration">
            <bean class="org.apache.ibatis.session.Configuration">
                <!--配置显示sql的日志-->
                <property name="logImpl" value="org.apache.ibatis.logging.stdout.StdOutImpl"/>
            </bean>
        </property>
        <property name="plugins">
            <list>
                <bean class="com.github.pagehelper.PageInterceptor">
                    <property name="properties">
                        <!--   <props>
                               <prop key="supportMethodsArguments">true</prop>
                               <prop key="reasonable">true</prop>
                           </props>
   -->
                        <value>
                            supportMethodsArguments=true
                            resonable=true
                        </value>
                    </property>
                </bean>
            </list>
        </property>
    </bean>

```





## spring-aop(Aspect Oriented Programming

### 概述：

​	首先spring的目的就是简化应用开发，就是减少重复代码，少写代码达到相同的目的。面向切面编程（AOP,Aspect Oriented Programming）就是一种减重复代码方式。

##### aop的几个术语：

| 名称                 | 解释                                                         |
| -------------------- | ------------------------------------------------------------ |
| 切面（aspect）       | 案例中指的就是LogImpl这个类                                  |
| 切点（pointcut）     | 它也称为切点表达式，目的是描述符合条件的方法                 |
| 目标（target）       | 就是案例中的EmployeeServiceImpl对象                          |
| 连接点（join point） | 就是目标对象中的insert,update方法                            |
| 通知（advice）       | 就是切面类中的before这个方法                                 |
| aop代理（aopProxy）  | spring aop的实现就是靠代理来做到的，默认利用jdk代理和cglib代理来实现 |
| 织入（weaving）      | 是个动词，表示把切面类的通知与目标对象连接点糅合在一起的过程就叫织入 |

```xml
 <aop:config proxy-target-class="true">
        <!--
        Aspect:切面
        pointcut:切点

		proxy-target-class 的作用：
			默认情况，spring生成动态代理，会考虑被代理对象是否实现有接口，如果有，就利用jdk的动态代理技术来做，生成的代理类，不是目标类型的子类，如果目标没有实现接口，就只能用cglib创建动态代理，是一种建立子类的方式来实现，所以你可以通过设定proxy-target-class（代理目标类）为true，就是让spring不管你有没有实现接口，都统一用cglib子类的形式来创建动态代理类。
		简单来说：
			proxy-target-class属性值决定是基于接口的还是基于类的代理被创建。首先说明一下proxy-target-class="true"和proxy-target-class="false"的区别，为true则是基于类的代理将起作用（需要cglib库），为false或者省略这个属性，则标准的JDK基于接口的代理将起作用。
			proxy-target-class在spring事务、aop、缓存这几块都有设置，其作用都是一样的。
        -->

        <!--这是切面类的配置-->
        <aop:aspect id="logAspect" ref="log">
            <!--这是切点表达式的配置-->
            <aop:pointcut id="myPointcut" expression="execution(* com.service.*.*())"/>
            <!--before的通知,主要用来确定当前这个切面类的什么方法在什么时候切入到
            切点表达式指向的方法里面.
            -->
            <aop:before method="before"
                        pointcut-ref="myPointcut"></aop:before>
        </aop:aspect>
    </aop:config>
```

### 通知：

####  五大通知类型

1. before: 前置通知，在连接点方法之前执行，而且不能控制连接点是否执行。

案例：

```java
public void before() {
    System.out.println("before*********");
}
```

```XML
<aop:config>
    <aop:pointcut id="myPointcut1" expression="execution(* com.service.EmployeeServiceImpl.*(..))"/>
    <aop:aspect ref="logImpl">
        <aop:before method="before"  pointcut-ref="myPointcut1"/>
    </aop:aspect>
</aop:config>
```

2. after:后置通知也叫最终通知，意思就是连接点方法只要执行（不管是否有错误），它都会得到执行。

案例：

```java
public void after(){
   System.out.println("after*********");
}
```

```XML
<aop:config>
    <aop:pointcut id="myPointcut1" expression="execution(* com.service.EmployeeServiceImpl.*(..))"/>
    <aop:aspect ref="logImpl">
        <aop:after method="after"  pointcut-ref="myPointcut1"/>
    </aop:aspect>
</aop:config>
```

3. after-return:返回通知，连接点正常执行（不报错）时才会执行这个通知。

案例：

```java
 public void afterReturn(){
     System.out.println("after return*********");
 }
```

```xml
<aop:config>
    <aop:pointcut id="myPointcut1" expression="execution(* com.service.EmployeeServiceImpl.*(..))"/>
    <aop:aspect ref="logImpl">
        <aop:after-return method="afterReturn"  pointcut-ref="myPointcut1"/>
    </aop:aspect>
</aop:config>
```

4. throwing:异常通知：连接点抛出异常时才会得到执行，这个通知不能处理异常，只能得到异常信息，异常通知如果想把目标抛出的异常传递给通知方法，只需要在异常通知的throwing属性设置的值等于通知方法的参数名就可以。  当异常通知方法没有异常类型作为参数时，潜台词就是目标方法抛出任何异常，通知都会得到执行，当异常通知方法“有”异常类型作为参数时，潜台词是只有目标方法抛出的异常是参数指定类型的异常或是子类型时，此通知方法才会得到执行。

案例：

```java
public void throwAdvice( RuntimeException re){
    System.out.println("-----debug: re = " + re);
    System.out.println("throwAdvice*********");
}
```

```xml
<aop:config>
    <aop:pointcut id="myPointcut1" expression="execution(* com.service.EmployeeServiceImpl.*(..))"/>
    <aop:aspect ref="logImpl">
        <aop:after-throwing method="throwAdvice"  pointcut-ref="myPointcut1"/>
    </aop:aspect>
</aop:config>
```

5. around通知：环绕通知，环绕通知是最强的通知类型，它可以完全取代上面的4种，也可以进行异常的捕获处理，也可以组织目标方法执行。

案例：

```java
/**
* 环绕通知的参数类型是ProceedingJointPoint类型
* 它是JoinPoint的子类型
* 但环绕通知的参数不能写为JoinPoint类型
*/

public Object aroundAdvice(ProceedingJoinPoint joinpoint){
    Object result = null;
    System.out.println("aroundAdvice before*********");
    try {
        //这个代码是让目标方法执行,不调用会导致目标方法不执行
        result = joinpoint.proceed();
        // System.out.println("aroundAdvice return********");
    } catch (Throwable throwable) {
        System.out.println("aroundAdvice throw *********");
    }

    System.out.println("aroundAdvice after*********");
    return result;
}

```

```xml
<aop:config>
    <aop:pointcut id="myPointcut1" expression="execution(* com.service.EmployeeServiceImpl.*(..))"/>
    <aop:aspect ref="logImpl">
        <aop:around method="aroundAdvice"  pointcut-ref="myPointcut1"/>
    </aop:aspect>
</aop:config>
```

#### 参数

1. 切点表达式中的args与execution都叫切点指示器（ProinCut Designer）
2. args是用来表示查找有多少个参数，args（x）,表示找到只有一个参数
3. args里面的名字相当于一个变量名，在调用目标方法时，依据调用目标方法传递的数据，给这个变量名赋值。
4. 通知执行的时候，需要参数，那么这些参数的值就通过从变量里面找，默认就是同名的，所以在不设置arg-names的时候，就会找args()表达式里面与通知方法同名的数据。
5. 但是4点的做法会导致切点表达式与通知方法的形参名耦合一起，所以spring提供了一个灵活的机制就是在配置通知时，利用arg-names指定“别名”
6. args-names指定了别名后就以别名为准，那么就会导致args表达式里面就需要与args-names对应起来。

总而言之：想让通知方法获取到传递给目标方法的参数需要这么做：

1. args表达式里面的名字与通知方法的名字与个数匹配即可，此时不需要配置通知的arg-names，配置代码如下：

```xml
<aop:pointcut id="myPoincut1" expression="execution(* com.service.EmployeeServiceImpl.*(..)) and args(m,n)"/>
<aop:before method="before2" pointcut-ref="myPointcut1" />
```

2. args表达式里面的名字任意，此时就需要在通知方法的arg-names配置得与args表达式名字一样，此时这两者配置的名字不需要与通知方法的形参名一样。

```xml
<aop:pointcut id="myPointcut1" expression="execution(* com.service.EmployeeServiceImpl.*(..)) and args(x1,y1)"/>
      <aop:before method="before2" pointcut-ref="myPointcut1" arg-names="x1,y1"/>
```

3. 由于所有的通知方法都可以添加JoinPoint类型作为第一个参数，而这个类型是可以很方便的得到参数，你也可以采用这种方式，这样就不需要上面的2种方法来达成同样的目的。



在官方文档中有这么一段：

@Before("com.xyz.myapp.SystemArchitecture.dataAccessOperation() && args(account,..)")

public void validateAccount(Account account) {    // ...}

The args(account,..) part of the pointcut expression serves two purposes.First, it restricts matching to only those method executions where the method takes at least one parameter, and the argument passed to that parameter is an instance of Account. 

Second, it makes the actual Account object available to the advice through the account parameter.

上面的话中,表明了args指定的参数类型可以靠使用它的通知方法参数类型来确定!  args本身自己就有两种用法,一种是指定类型:args(int,int),另外一种就是像上面那样指定名字。



### 执行顺序

​	在同一个切面中，配置的同类型通知，其顺序官方没有明确的说明，就不能认为以配置的顺序为准，但是如果是在不同的切面中配置，可以通过order属性来准确的控制其执行顺序，数字小的先执行。



### 通知器（adivsor）：

​	Adivsor:通知器或者统治者，有某个或某些特定通知类型的切面类,

​	特定通知是靠此类实现某些接口来表示的。

#### 	spring有如下接口来表明不同的通知类型：

	1. MethodBeforeAdvice：前置通知
 	2. AfterReturningAdvice：返回通知
	3. ThrowsAdvice：异常通知
	4. MethodInterceptor：环绕通知

****注意：没有最终通知（after通知）****

案例：

```java
public class MyAdvisor implements MethodBeforeAdvice, AfterReturningAdvice, MethodInterceptor, ThrowsAdvice {
    @Override
    public void before(Method method, Object[] args, Object target) throws Throwable {
        System.out.println("before----");
    }

    @Override
    public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable {
        System.out.println("-----debug: returnValue = " + returnValue);
    }

    @Override
    public Object invoke(MethodInvocation invocation) throws Throwable {
        //这行代码相当于改变了传递给目标对象方法的参数值.
        invocation.getArguments()[0] = (Integer) invocation.getArguments()[0] + 100;
        System.out.println("around before");
        Object result = invocation.proceed();
        System.out.println("around after");
        return result;
    }


    /**
     * 异常通知接口是个空接口
     * 方法的签名必须是:
     * 1.返回类型是void
     * 2.方法名是afterThrowing
     * 3.方法的参数可以是
     * 3.1 Method method, Object[] args, Object target
     * 3.2 或者Method method, Object[] args, Object target,异常类
     *
     * @param method
     * @param args
     * @param target
     * @throws Throwable
     */
    public void afterThrowing(Method method, Object[] args, Object target, RuntimeException re) throws Throwable {
        System.out.println("throw----" + re.getMessage());
    }
}
```

```xml
<aop:config>
    <aop:pointcut id="myPointcut"
                  expression="execution(* com.service..*.*(..))"/>
    <aop:advisor advice-ref="myAdvisor"
                 pointcut-ref="myPointcut"/>
</aop:config>
```





### 切点表达式

spring aop只针对方法进行aop代理，不想aspectj联盟搞的aop实现这个aop联盟的实现功能比spring aop要强大，比如可以针对字段进行切面编程。



1. 切点指示器（PCD:PointCutDesigner）：指示器可以理解为一种描述找到方法的方式，spring支持的切点指示器有如下几个：

   ​	1.1 excution: 用来匹配连接点方法的，用的最多的一个指示器

   ​	1.2 within: 英文的意思是：在某某之内，一般就是指的是在”某些“类之内，within（com.service.*）就是指com.service包下的所有类的方法进行aop代理

   ​	1.3  this：指的就是动态代理生成的对象，这种指示器一般用来表示某个动态代理对象是某个类型，比如this(com.service.EmployeeService)，就表示动态代理对象是EmployeeService的实现类

   ​	1.4 target：指的是被代理的对象，指定的是“某个”特定的目标对象

   ​	1.5 args：此指示器是在方法的参数层面来描述，比如args(Integer,String)就表示所有有两个参数，并且类型分别是Integet,String的方法。

   ​	1.6 @target:就表示目标类型上有特定注解修饰的目标对象，例如 @target(com.MyFirstAnnotation)，就会找所有被spring管理的bean上面有MyFirstAnnotation注解的目标类

   ​	1.7 @args：与arg类似，只不过是表面参数上有特定注解的

   ​	1.8 @within：与within类似，只不过是表面类上有特定的注解修饰

   ​	1.9 @annotation：指的是连接点方法上有特定注解

   ​	1.10 @bean ：这个指示器不是aop联盟的标准，是spring自己提供的指示特定bean的名字的指示器

2. 指示器的逻辑运算符 

   ​	并且：and(&&)    、   或者：or(||) 、    非：not(!)

3. execution指示器

   ​	它的编写格式：

   ​	execution(modifiers-pattern? ret-type-pattern declaring-type-pattern thriws-pattern?)

   ​	上面格式的含义如下：

   ​	3.1  ？：表示有或者没有，没有问号就表示必须写

   ​	3.2  modifiers-pattern:修饰符模式

   ​			ref-type-pattern：返回类型模式

   ​			declaring-type-pattern:指的就是方法参数的模式

   ​			throws-pattern:指的是方法抛出的异常的模式

   ​		其中三个模式必不可少：返回类型，方法名，方法参数

   ​	通配符：  *：表示任意名字、  ..：任意段的任意字符

   ​	常见的例子：   1. execution(public  *  *(..))：找到所有的公有方法

   							  2. execution(*  *To(..))：找到任意返回类型，任意类的以To结尾的任意方法
      							  3. publc * com.service.emp.EmployeeService+.*(..)    ;    +：表示接口的所有方法以及此接口实现类自己的方法都会被aop代理
                           							  4. public * com.service..* .*(..)  表示com.service包以及子孙包下
                                       							  5. within( com.service..*)  表示com.service包以及子孙包下的所有类，写法与execution指示器是不同的，不需要写返回类型
                                                   							  6. target( com.service.emp.impl.EmployeeServiceImpl) 给EmployeeServiceImpl进行aop代理，不能使用通配符，表达式中指定父类型或者接口时是可以的。
                                                               							  7. this(com.service.emp.impl.EmployeeServiceImpl):给EmployeeServiceImpl类进行aop代理，写法与taregt类似。   意思是：如果能代理成功，那么生成的代理类是表达式里面设定的类型的实例
                                                                           							  8. bean(emp)表示给emp这个bean进行aop代理

#### 参考资料

中文文档：https://blog.csdn.net/ABCD898989/article/details/50809321

英文文档：https://docs.spring.io/spring/docs/5.2.0.RELEASE/spring-framework-reference/core.html#aop-pointcuts

Spring Aop原理之切点表达式解析：https://juejin.im/entry/5b9f69266fb9a05cfb3da610





## spring-tx  事务

#### spring事务写法要点：

 1. 配置一个DataSource

 2. 配置事务管理器，用上dataSource

 3. 配置一个事务通知tx:advice

    ​	3.1 对某些方法进行事务相关属性配置，比如超时（timeout），事务隔离级别，事务传播方面的配置，只读配置。

    ​	3.2  一定要记得关联事务管理器，默认名字是transactionManager

4. 配置aopconfig，确定对哪些业务类的方法进行事务处理     ***事务的处理是针对业务类，不是dao***



事务管理器：主要是用来管理物理连接，事务提交，回滚等功能，有了事务配置，对我们的dao里面用的连接相关的信息就有了要求：

1. 因为这个事务管理器是针对DataSource，所以我们的dao必须用“同一个”dataSource

 	2. DataSource获取方法必须是Spring提供的方式。



tx:advice的事务管理器设置：如果你配置的事务管理器的名字叫做transactionManager，那么transaction-manager就可以不用设置。



我们也可以配置多个method，一般的配置，查询操作用只读事务，会优化性能，它也支持通配符*

默认情况下，spring会对运行时异常产生回滚，检查异常不回滚，如果想针对检查异常也回滚，那么就需要配置roolback-for

mybatis这种持久化层框架，其所有数据库操作的异常都是运行时异常，所以method的rollback-for保留默认即可，不需要额外配置。



案例：

```xml
<tx:attributes>
            <tx:method name="get*" read-only="true"/>
            <tx:method name="*" propagation="REQUIRED" rollback-for="com.dao.MyCheckEx"/>
        </tx:attributes>
    </tx:advice>

    <aop:config>
        <aop:pointcut id="serivceTx" expression="execution(* com.service..*.*(..))"/>
        <aop:advisor advice-ref="txAdvisor" pointcut-ref="serivceTx"/>
    </aop:config>
```



#### 事务传播：

​	事务传播：transaction propogation:主要指的是先前的事务信息，如何影响后开启事务

比如：

```java
service(){
    serviceA();
    serviceB();
}

serviceA(){//有事务
          }

serviceB(){
    //有事务
}
```

传播有七个值，默认就是Required

​	**** tx:attributes是必须配置，如果不配置，整个就运行在非事务环境下****

#### 事务整合配置

当mybatis与spring进行整合的时候，它内部有一个异常翻译机制，就是把mybatis的异常全部翻译为spring的DataAccessException异常，而DataAccessException是一个运行时异常。

案例：

```xml
<bean id="dataSource" class="com.alibaba.druid.pool.DruidDataSource">
    <property name="username" value="root"/>
    <property name="password" value="root"/>
    <property name="url" value="jdbc:mysql://localhost:3306/demo"/>
</bean>

<bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
    <property name="dataSource" ref="dataSource"></property>
    <property name="mapperLocations" value="classpath*:*Mapper.xml"/>
</bean>

...

<!--事务管理器用的dataSource必须与sqlSessionFactory一样(与mybatis整合时)-->
<bean id="transactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
    <property name="dataSource" ref="dataSource"/>
</bean>


<tx:advice id="txAdvisor">

    <tx:attributes>
        <tx:method name="get*" read-only="true"/>
        <tx:method name="*"/>
    </tx:attributes>
</tx:advice>

<aop:config>
    <aop:pointcut id="servicePointcut"
                  expression="execution(* com.service..*.*(..))"/>

    <aop:advisor advice-ref="txAdvisor" pointcut-ref="servicePointcut"/>
</aop:config>
```

