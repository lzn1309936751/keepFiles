# Spring MVC

## Spring MVC简介

 Spring MVC属于SpringFrameWork的后续产品，已经融合在Spring Web Flow里面。Spring 框架提供了构建 Web 应用程序的全功能 MVC 模块。使用 Spring 可插入的 MVC 架构，从而在使用Spring进行WEB开发时，可以选择使用Spring的Spring MVC框架或集成其他MVC开发框架 。

## Spring MVC核心组件

1. DispatcherServlet：前置控制器，是整个流程控制的核心，控制其他组件的执行，进行统一调度，降低组件之间的耦合性，相当于总指挥。

2. Handler：处理器，完成具体的业务逻辑，相当于 Servlet 或 Action。

3. HandlerMapping：DispatcherServlet 接收到请求之后，通过 HandlerMapping 将不同的请求映射到不同的 Handler。

4. HandlerInterceptor：处理器拦截器，是一个接口，如果需要完成一些拦截处理，可以实现该接口。

5. HandlerExecutionChain：处理器执行链，包括两部分内容：Handler 和 HandlerInterceptor（系统会有一个默认的 HandlerInterceptor，如果需要额外设置拦截，可以添加拦截器）。

6. HandlerAdapter：处理器适配器，Handler 执行业务方法之前，需要进行一系列的操作，包括表单数据的验证、数据类型的转换、将表单数据封装到 JavaBean 等，这些操作都是由 HandlerApater 来完成，开发者只需将注意力集中业务逻辑的处理上，DispatcherServlet 通过 HandlerAdapter 执行不同的 Handler。

7. ModelAndView：装载了模型数据和视图信息，作为 Handler 的处理结果，返回给 DispatcherServlet。

8. ViewResolver：视图解析器，DispatcheServlet 通过它将逻辑视图解析为物理视图，最终将渲染结果响应给客户端。

## Spring MVC流程

SimpleUrlHandlerMapping和SimpleControllerHandlerAdapter这两个类

  \+ DispatcherServlet的doDispatch方法是研究spring mvc的好的入口点,

整个mvc执行流程可以看DispatcherServlet的doDispatch方法.

### 流程图

![](C:\Users\Sam\Desktop\笔记\新建文件夹\SpringMVC流程图.png)

### 具体流程

1. 浏览器请求一个地址

2. DispatcherSevlet收到这个请求

3. DispatcherServlet就交给HandlerMapping去找一个对应的Handler。这个handler就是我么的后端控制器。

4. 控制器的执行，不是写死的，因为控制器的种类有很多，比如类上面加@Controller是一个控制器，类实现一个Controller接口也是一个控制器，所以DispatcherServlet是无法预知各种各样的控制器，那么怎么执行控制器呢？。

5. 首先依据当前的控制器，去找对应的HandlerAdpter,看看是否有HandlerAdapter可以执行这个，如果有，就利用当前找到的HandlerAdapter去执行控制方法，具体可以去看SimpleControllerHandlerAdapter类的源代码。

6. HandlerAdapter就开始执行，HandlerAdapter的执行其实就是调用Handler（后端控制器）的相关方法去执行，放回一个ModelAndView;

7. 依据ModelAndView,可以得到对应的视图名。

8. 依据视图名，交给某一个合适的视图解析器，去解析一个View对象。

9. 依据视图对象的render(呈现)。

10. 比如有一个视图对象InternalResourceView,他就会调用Request的forward来

    把找到的jsp视图对象转发

## Spring MVC实现

spring mvc的具体实现流程。

### 1-添加依赖

```xml
<dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-webmvc</artifactId>
      <version>5.2.0.RELEASE</version>
</dependency>
```

springMVC需要添加一个依赖，此依赖传递了几个其他的依赖

如：spring-aop，spring-web，spring-context等..

也就是说，只要添加了这一个依赖，其他的几个关于spring的依赖都不需要自己添加。

### 2-web配置

我们需要在web.xml中配置**DispatcherServlet**，它被称为前端控制器或者分发器。作用是用来拦截所有的servlet请求的，然后分发给其他的控制器去执行servlet请求。

```xml
<!--
    这个DispatcherServlet是需要一个spring容器的.
    所以就需要一个元数据的东西,目前先学xml
    默认情况下它会在WEB-INF目录下面找当前名字-sevlet的文件:hello-servlet.xml
-->

    <servlet>
        <servlet-name>hello</servlet-name>
        <servlet-class>
            org.springframework.web.servlet.DispatcherServlet
        </servlet-class>
        <init-param>
            <param-name>contextConfigLocation</param-name>
            <param-value>classpath*:hello.xml</param-value>
        </init-param>
    </servlet>

    <!--
    /在容器(tomcat)是代表默认servlet,现在这样配之后就意味DispatcherServlet取代
    容器的那个默认servlet,可以处理所有请求
    -->
    <servlet-mapping>
        <servlet-name>hello</servlet-name>
        <url-pattern>/</url-pattern>
    </servlet-mapping>
```

### 3-springmvc.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xmlns:mvc="http://www.springframework.org/schema/mvc"
       xsi:schemaLocation="http://www.springframework.org/schema/beans 		http://www.springframework.org/schema/beans/spring-beans.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd
       http://www.springframework.org/schema/mvc
       http://www.springframework.org/schema/mvc/spring-mvc-3.2.xsd">
    <!-- 自动扫描 -->
    <context:component-scan base-package="com.controller"></context:component-scan>

    <!-- 配置视图解析器 -->
    <bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
        <property name="prefix" value="/WEB-INF/views/"></property>
        <property name="suffix" value=".jsp"></property>
    </bean>
</beans>
```

### 4-创建控制器

```java
package com.southwind.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloHandler {

    @RequestMapping("/index")
    public String index(){
        System.out.println("执行了index...");
        return "index";
    }
}
```

当我们在浏览器中输入localhost:8080/index地址的时候，此控制器就会根据视图解析器，找到对应的/WEB-INF/views/index.jsp。

## Spring MVC注解

关于Spring MVC的相关注解的使用和解释。

### @Controller

@Controller 在类定义处添加，将该类交个 IoC 容器来管理（结合 springmvc.xml 的自动扫描配置使用），同时使其成为一个控制器，可以接收客户端请求。

### @RequestMapping

#### 相关使用

- RequestMapping注解用在控制器方法上，表明请求某个地址，对应执行某个方法.

```java
@Controller
public class IndexController {
    @RequestMapping("/index")   //访问http://localhost:8080/index就可以执行此方法
    public String index(){
        return "index";
    }
}
```

- RequstMapping可以修饰在类上，实例如下：

```java
@Controller
@RequestMapping("user")
public class IndexController {
    @RequestMapping("/index")  //http://localhost:8080/user/index
    public String index(){
        return "index";
    }
```

- 支持多个地址

```java
@RequestMapping({"/index1","/index2","/index3"}) //意思就是访问这里面其中一个就可以执行方法
```

- 支持ant地址格式：

```java
@RequestMapping("/**/*index")
```

- 支持 RESTful 风格的 URL。

```java
@RequestMapping("/rest/{name}/{id}")
public String rest(@PathVariable("name") String name,@PathVariable("id") int id){
    System.out.println(name);
    System.out.println(id);
    return "index";
}
```

- 备胎（fallback),表示如果没哟方法满足，就执行此方法。

```java
/**
 * 这种配置方法,就是默认处理方法
 * 英文fallback(备胎)
 * @return
 */
@RequestMapping("*")
public String index3(){
    return "index";
}
```



#### 相关属性

1. value：指定URL请求的实际地址，是该注解的默认值。
2. method：指定请求的 method 类型，GET、POST、PUT、DELET。
3. params：指定请求中必须包含某些参数，否则无法调用该方法。
4. headers：指定请求头中必须有某些值。
5. produces：(产生,生产的意思),这个地方其实依据请求信息中的accept来限缩。
6. consumes：(消费的意思):就是浏览器端传过来的内容必须是某个类型。

java代码案列：

```java
/**
     * 下面的这个配置意思是:
     * 1.请求地址为/index2
     * 2.请求必须有参数a并且值为5
     * 3.请求头部必须有b,并且值为3
     * 4.请求accept里面必须有application/json:表示本处理方法必须响应application/json的内容
     * 5.请求必须传递的是text/html内容类型的数据
     *
     * 满足这5个条件,此方法才会处理这样的请求
     *
     * @return
     */
    @RequestMapping(value = "/index2",
            method = RequestMethod.POST,
    params = "a=5",headers = "b=3",
    produces = "application/json",
            consumes = "text/html"
    )
    public String index3(){
        //response.setContentType("application/json")
        return "index";
    }
```



#### 支持参数类型

RequestMapping注解修饰的方法,支持以下一些类型作为参数

- HttpServletRequest 

- HttpServletResponse 

- CookieValue 

- HttpSession


具体就看官方文档:搜索HandlerMethod,去找表格。

### @RequestParam

#### 相关使用

该注解是完成Http请求参数与业务方法形参的映射。

```java
@RequestMapping(value = "/index")
public String index(@RequestParam("name") String str,@RequestParam("id") int age){
    return "index";
}
```

上述代码表示将请求的参数 name 和 id 分别赋给了形参 str 和 age 。

#### 相关属性

1. value：如vale="num",表示将HTTP请求中名为num的参数赋给对应的形参。
2. requried：设置 num 是否为必填项，true 表示必填，false 表示非必填，可省略。
3. defaultValue = “0”：如果 HTTP 请求中没有 num 参数，默认值为0.

### @PathVariable

该注解也是完成请求参数与形参的映射。支持restful风格的URL的请求参数获取。就是从url路径上取得数据，比如/a/b{abc} ->  abc->给方法的参数

```java
@RequestMapping("/rest/{name}/{id}")
public String rest(@PathVariable("name") String name,@PathVariable("id") int id){
    System.out.println(name);
    System.out.println(id);
    return "index";
}
```

上述代码表示获取/rest后的name,id的值，并将其绑定到形参中。

### 组合注解

组合注解的作用就是简化RequestMapping的书写，下面是用的比较多的四个组合注解。

- GetMapping:查询
- PostMapping:增加
- PutMapping:修改
- DeleteMapping:删除

具体实例代码：

```java
@Controller
@RequestMapping("/dept")
public class Home4Controller {
    @GetMapping("/get")
    public String index(){
        return "index";
    }
    @PostMapping("/post")
    public String index2(){
        return "index";
    }
    @DeleteMapping("/delete")
    public String index3(){
        return "index";
    }
    @PutMapping("/put")
    public String index4(){
        return "index";
    }
    @PatchMapping("/patch")
    public String index5(){
        return "index";
    }
}
```

**注意事项**

1. 如果多个模式都匹配一个url，那么最精确的最优先匹配，在官方文档的RequestMapping->Pattern Match节中有详细的说明。

2. 在配置多段url的时候,比如/home/list,如果InternalResourceViewResolver的前缀不以/开头
   表示相对地址,那么控制器方法返回index,实际的视图地址为:/home/WEB-INF/views/index.jsp

   所以强烈建议:视图解析器的前缀一定加上**/**开头.

## Spring MVC数据绑定

数据绑定：在后端的业务方法中直接获取客户端 HTTP 请求中的参数，将请求参数映射到业务方法的形参中，Spring MVC 中数据绑定的工作是由 HandlerAdapter 来完成的。

### 基本类型

```java
@GetMapping("/simple") 
public String index(int pageNo){
    System.out.println("-----debug: pageNo = " + pageNo);
    return "index";
}
```

请求http://localhost:8080/simple?pageNo=3 可得到参数。

springMVC默认以控制器方法参数上的参数名称为请求的参数名。

如果请求http://localhost:8080/simple，

这里不带参数，就会报错，因为基本类型int不能为null，所以建议使用Integer包装类型。

###  包装类型 

```java
@GetMapping("/wrapper")
public String index(String abc,Integer pageNo){ 
  	System.out.println("---" + abc);
    System.out.println("-----debug: pageNo = " + pageNo);
    return "index";
}
```

请求http://localhost:8080/wrapper?abc=aaa&pageNo=3 可得到参数

包装类型可以为null。

### 复杂类型

```java
@GetMapping("/index")
public String index(UserInfo userInfo){ 
    //可以从http://localhost:8080/index?id=1&name="12"取到值。
  	System.out.println("---" + userInfo);
    return "index";
}
```

已知UserInfo有一个id属性，和一个name属性。

### List 类型

因为spring mvc比较水，所以传list参数是需要添加一个VO类：

```java
public class EmpVO {
    private List<Emp> emps;
    public List<Emp> getEmps() {
        return emps;
    }
    public void setEmps(List<Emp> emps) {
        this.emps = emps;
    }
}
```

在vo类里面存取list对象。

再写上控制器方法：

```java
@GetMapping("/list")
public String index(EmpVO empVO){
    System.out.println("-----debug: empVO = " + empVO);
    return "index";
}
```

jsp：

```jsp
<form method="post" action="/list">
    <input type="text" name="emps[0].id"/>
    <input type="text" name="emps[0].username"/>
    <input type="text" name="emps[0].gender"/>

    <input type="text" name="emps[1].id"/>
    <input type="text" name="emps[1].username"/>
    <input type="text" name="emps[1].gender"/>

    <input type="submit" value="提交"/>
</form>
```

### 其他类型

如array，map，set等。具体原理如上述一致。

## Spring MVC数据转换器

数据转换器是指将客户端 HTTP 请求中的参数转换为业务方法中定义的形参，自定义表示开发者可以自主设计转换的方式，HandlerApdter 已经提供了通用的转换，String 转 int，String 转 double，表单数据的封装等，但是在特殊的业务场景下，HandlerAdapter 无法进行转换，就需要开发者自定义转换器。

比如Converter与Formatter：

Formatter:就是用来把字符串转换其它类型或者反之,所以Formatter特别适合在serlvet环境下使用。

Converter:用来在任意两个类型之间进行转换。



这2个接口是在spring 3.0之后才出现，

以前spring进行类型转换使用jdk(主要用在窗口程序开发中)PropertyEditor体系，

这种PropertyEditor体系就是stirng->其它类型的转换,因为这种体系有2个主要的缺点。

1.线程不安全

 2.跟UI的东西耦合

 所以spring 3.0就推出了自己的转换体系,以Formmatter与Converter为代表

### ConversionService

为了方便Formmatter与Converter这2个接口的使用,就有一个转换服务接口,ConversionService

spring在做数据绑定时,首先判断spring容器中是否有ConversionService

如果有,就用转换服务来进行类型转换,如果没有就回退(fallback)到原始的

PropertyEditor体系来进行类型转换。

### Converter

用来在任意两个类型之间转换。

比如客户端输入 String 类型的数据 "2019-03-03"，自定义转换器将该数据转为 Date 类型的对象。

实例代码如下：

- 创建 DateConverter 转换器，实现 Conveter 接口。

```java
package com.southwind.converter;

import org.springframework.core.convert.converter.Converter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateConverter implements Converter<String, Date> {

    private String pattern;

    public DateConverter(String pattern){
        this.pattern = pattern;
    }

    @Override
    public Date convert(String s) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(this.pattern);
        Date date = null;
        try {
            date = simpleDateFormat.parse(s);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }
}
```

- springmvc.xml 配置转换器。

```xml
<!-- 配置自定义转换器 -->
<bean id="conversionService" class="org.springframework.context.support.ConversionServiceFactoryBean">
    <property name="converters">
        <list>
            <bean class="com.southwind.converter.DateConverter">
                <constructor-arg type="java.lang.String" value="yyyy-MM-dd"></constructor-arg>
            </bean>
        </list>
    </property>
</bean>

<mvc:annotation-driven conversion-service="conversionService">
    
</mvc:annotation-driven>
```

- jsp页面

```jsp
<%--
  Created by IntelliJ IDEA.
  User: southwind
  Date: 2019-03-14
  Time: 14:47
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>
    <form action="/converter/date" method="post">
        请输入日期:<input type="text" name="date"/>(yyyy-MM-dd)<br/>
        <input type="submit" value="提交"/>
    </form>
</body>
</html>
```

- Handler

```java
package com.southwind.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
@RequestMapping("/converter")
public class ConverterHandler {

    @RequestMapping("/date")
    public String date(Date date){
        return date.toString();
    }
}
```

### Formatter

Formatter:就是用来把字符串转换其它类型或者反之,所以Formatter特别适合在serlvet环境下使用。

1.写一个类,实现Formatter接口

parse用来把字符串转换为实现接口时指定的类型实参

print用来把指定的类型实参转换为字符串

```java
public class EmpFormatter implements Formatter<Emp> {

    @Override
    public Emp parse(String text, Locale locale) throws ParseException {
        String[] data = text.split(",");
        Emp emp = new Emp();
        emp.setFirstName(data[0]);
        emp.setLastName(data[1]);
        return emp;
    }

    @Override
    public String print(Emp object, Locale locale) {
        return object.toString();
    }
}
```

2.在控制器类中,利用InitBinder注解给数据绑定器添加自己编写的格式化器

```java
@ControllerAdvice
public class MyControllerAdvice {
    @InitBinder
    public void xxxx(WebDataBinder dataBinder) {
        dataBinder.addCustomFormatter(new EmpFormatter());//这个是自定义的Formatter
        dataBinder.addCustomFormatter(new DateFormatter());
    }
}
```

3.在控制类中，写上访问的地址：

```java
//:/formatter/emp?xxx=chen,jun
// 通过指定RequestParam就明确表明把请求参数中xxx的值转换为一个Emp
// 这是必须指定的

@GetMapping("/emp")
public String receiveEmp(@RequestParam("xxx") Emp emp){
    System.out.println("-----debug: emp = " + emp);
    return "index";
}
```

### 日期转换

下列为字符转日期格式的案例。

#### DateTimeFormat注解

用来设置url路径上取得日期数据的日期格式。

```java
@Autowired(required = false)
private ConversionService conversionService;

@GetMapping("/date")
public String receiveDate(@DateTimeFormat(pattern = "yyyy-MM-dd") Date date) {
        System.out.println("-----debug: conversionService = " + conversionService);
        System.out.println("-----debug: date = " + date);
        return "index";
    }
```

此时，才参数上设置其实是不生效的。

加上如下配置：

```xml
<!-- 
	此注解会自动创建ConversionService(转换服务)
 	所以在上面案例中会自动注入转换服务。
	因为有了转换服务，那么就会去找支持@DateTimeFormat注解的转换器
	再添加上此转换器。
-->
<mvc:annotation-driven />
```

在spring中,像annotation-driven这种东西,比如mvc-annotation-driven

  tx:annotation-driven主要是增加对注解的支持.以及往spring容器中注入普通的bean

  以及注入BFPP(BeanFactoryPostProcessor)或BPP(BeanPostProcessor)(这2个东西是用来增加spring功能的类型)。

  一般会有对应的Enable开头的注解完成xml这个配置类似的功能

  比如:tx:annotation-driven->EnableTransactionManagement.

mvc:annotation-driven这个设置,处理对转换服务进行设定以外,还可以对校验进行设置。

#### 手动添加转换器

```java
@InitBinder
public void xxxx(WebDataBinder dataBinder) {
	DateFormatter dateFormatter = new DateFormatter();
	dateFormatter.setPattern("yyyy-MM-dd");
    dataBinder.addCustomFormatter(dateFormatter);
}
@GetMapping("/date2")
public String receiveDate2(Date date) {
	System.out.println("-----debug: date = " + date);
    return "index";
}
```

手动添加DateFormatter，并设置日期格式，也可以做到和DateTimeFormat注解一样的效果。

## Spring MVC绑定器

### WebDataBinder

WebDataBinder是DataBinder(数据绑定)的子类

数据绑定类的作用主要有以下几个:

1.类型转换(主要是把字符串类型转换为其它类型,比如Integer,Date等等

2.校验(判断数据是否符合要求,比如密码长度是否有8位,年龄是否在合理区间)

 3.处理绑定结果:可以得到哪些绑定有问题。

实例如下；

```java
@InitBinder
public void xxxx(WebDataBinder dataBinder) {
    //这是字符串转日期的Formatter，也可以自定义Formatter
    dataBinder.addCustomFormatter(new DateFormatter());
}
```

上述代码表示将http请求的参数转为Data类型。

### DateTimeFormat注解

用来设置url路径上取得日期数据的日期格式。

```java
@GetMapping("/date")
public String receiveDate(@DateTimeFormat(pattern = "yyyy-MM-dd") Date date){

    System.out.println("-----debug: date = " + date);
    return "index";
}
```

**注意**：需要添加绑定器：

```java
@InitBinder
public void xxxx(WebDataBinder dataBinder) {
    dataBinder.addCustomFormatter(new DateFormatter());
}
```



### InitBinder注解

初始化绑定器，给绑定器添加一些定制内容，比如格式化器。

被InitBinder注解修饰的方法的要求

1.方法名是任意的

2.方法的返回值必须void

3.方法的参数与RequestMapping修饰的方法参数类似

 4.方法的参数可以有多个

```java
@InitBinder
public void xxxx(WebDataBinder dataBinder) {
    dataBinder.addCustomFormatter(new DateFormatter());
}
```



但是一般用InitBinder修饰的方法,其参数主要写这么几个

1.WebDataBinder

2.Locale

3.WebRequest

InitBinder注解在使用的某个控制器中修饰,只在本控制器有效,也就是说只对本控制器的所有请求方法是有效的,但是对其它控制器的，请求方法是无效。

### 配置全局绑定器

需要掌握配置的方式有以下两种。

#### 元数据配置

- 开启注解驱动

```xml
<mvc:annotation-driven conversion-service="conversionService"></mvc:annotation-driven>
<!-- 这里的conversionService就在下面 -->
```

mvc:annotation-driven这个设置,处理对转换服务进行设定以外,还可以对校验进行设置

详细情况可以参考EnableWebMvc注解的注释。

- 创建转换服务

```xml
<bean id="conversionService" class="org.springframework.format.support.FormattingConversionServiceFactoryBean">
    <!--往转换服务里面添加Formatter -->
    <property name="formatters">
        <bean class="com.formatter.EmpFormatter"/>
    </property>
</bean>
```

#### ControllerAdvice注解

被ControllerAdvice注解修饰的类就表明

这个类是所有控制器的一个切面类。

```java
@ControllerAdvice
public class MyControllerAdvice {
    @InitBinder
    public void xxxx(WebDataBinder dataBinder) {
        dataBinder.addCustomFormatter(new EmpFormatter());//这个是自定义的Formatter
        dataBinder.addCustomFormatter(new DateFormatter());
    }
}
```

被ControllerAdvice修饰的类主要作用:

1.设定绑定器

2.进行全局的异常处理

**注意**:在这种类里面写的功能没什么意义

## Spring 校验

检验可以分为两类，前端校验和后端校验

### 前端校验

前端校验:js完成,主要的目的是用户友好,但是
最大的问题是js可以被禁用.
搜索:jquery 非侵入式校验(jquery unobtrusive)

### 后端校验

后端校验:是必须要有.

pring 中的校验大体可以分为2套
一套是spring自己实现的校验体系
另外一套是java标准校验(以下学的是这一个)。

### 校验实现

下面是完整的校验实例。

#### 1-添加依赖

```xml
<!--
    这个依赖会传递校验java标准的校验api
    hibernate是对这套校验API的实现
-->
<dependency>
    <groupId>org.hibernate.validator</groupId>
    <artifactId>hibernate-validator</artifactId>
    <version>6.1.0.Final</version>
</dependency>
```

#### 2-添加注解

在需要校验的字段上面添加相应对校验注解，如：@Size。

```java
public class EmpEntity {
    private Integer id;
    @Size(min=2,max = 8,message = "2-8zhi jian")
    private String username;
    
    //get Set...
}
```

#### 3-Vaild注解

给控制器方法需要校验的每一个参数都要加@Valid注解,表示需要校验。

```java
@Controller
public class ValidationController {
    @RequestMapping("/insert")
    public ModelAndView insert(@Valid EmpEntity empEntity) {
        ModelAndView mav = new ModelAndView();
        System.out.println("-----debug: empEntity = " + empEntity);
        return mav;
    }
}
```

**注意**：我们要启用以上的注解，那么就要在xml中要配置mvc:annotation-driven,表示启用springmvc校验功能。

```xml
<mvc:annotation-driven />
```

#### 4-检验异常

BindingResult：

BindingResult译为 绑定结果的意思。

可以用来处理校验错误的

如：输出校验错误的错误信息。

```java
@Controller
public class ValidationController {
    @RequestMapping("/insert")
    public ModelAndView insert(@Valid EmpEntity empEntity, BindingResult bindingResult) {
        ModelAndView mav = new ModelAndView();
        //判断是否有校验错误
        if(bindingResult.hasErrors()){
            //得到所有的字段异常
            List<FieldError> errors = bindingResult.getFieldErrors();
            //进行遍历
            for(FieldError error:errors){
               //得到字段名与异常信息，并保存
                mav.addObject(error.getField(),
                              error.getDefaultMessage() );
            }
            mav.setViewName("error");//可以跳到一个异常页面
        }else{
            mav.setViewName("ok");
        }
        return mav;
    }
}
```

给每一个需要校验的参数后面,加一个BindingResult类型。

### 校验错误分类

#### 字段级别

字段级别的错误,比如usernmae长度在2-8之间

#### 类级别

类级别的错误,比如一个类中有2个字段,分别叫出生日期与雇佣日期，因为雇佣日期不能在出生日期之前所以这2个字段进行比较,就叫做类级别。

## Spring MVC视图

按照mvn的理念，永远应该是转发到jsp，控制器方法直接显示视图，视图解析器会加上在xml配置的前后缀。

### forward

根据逻辑视图名转发到某个物理视图，或者转发到某个请求方法中，

- 转发到逻辑视图中，方法有以下两种。

1. 直接返回字符串，代表逻辑视图名。

```java
@RequestMapping("/demo1")
public String demo1(){
    return "view";
}
```

2. 返回ModelAndView

```java
 @RequestMapping("/demo2")
public ModelAndView demo2(){
    ModelAndView mav = new ModelAndView();
    mav.setViewName("view");
    return mav;
}
```

- 转发至其他请求方法。

返回字符串,加前缀forward,比如"forward:其它请求方法的地址" ，  这种加前缀是告诉视图解析器直接转发（forward）到指定的地址,而不是用来显示视图用的,所以不需要加前缀与后缀。

```java
@RequestMapping("/demo1")
public String demo1(){
    return "forward:demo2";
}
```

### redirect

重定向到其他方法。方法有以下两种。

- 返回字符串,加前缀redirect,比如"redirect:其它请求方法的地址" ，  这种加前缀是告诉视图解析器直接重定向到指定的地址,而不是用来显示视图用的,所以不需要。加前缀与后缀.

```java
@GetMapping("/demo1")
public void demo1(){
    return "redirect:demo2"
}
@GetMapping("/demo2")
public void demo2(){
    return "view"
}
```

- 返回RedirectView类型,直接设置其它请求方法的地址,不需要加前缀。

```java
@RequestMapping("/demo5")
public RedirectView demo5(){
    //返回RedirectView时,指定的是跳转的地址,
    //视图解析器直接一句指定的地址加载视图(不加在xml中设定的前后缀值)
    RedirectView rv = new RedirectView("dis");
    return  rv;
}
 @RequestMapping("/dis")
public String dis(){
    return "view";
}

```

### 上述总结

> 总结:在返回的string类型数据中,有前缀(不管是forward还是redirect)后面跟着的就是。
>
> 一个地址,不是一个逻辑视图名.也就是说视图解析器不会自动帮我们加上前后缀。

### *传递数据至视图

如何将我们的数据传到视图中去呢。方法有以下三种。

- 利用servlet的api,比如请求作用域,会话作用域,应用程序作用域都可以

```java
@GetMapping("/demo1")
public String demo(HttpServletRequest request){
    request.setAttribute("f", "/forward/demo1");
    return "view";
}
```



- 利用ModelAndView.

```java
@GetMapping("/demo2")
public ModelAndView demo2(){
    ModelAndView mav = new ModelAndView();
    mav.addObject("f", "数据");
    mav.setViewName("view");
    return mav;
}
```



- 利用Model,Model,Map<string,Object>类型作为参数。

```java
@GetMapping("/demo3")
public String demo3(Model model){
    //Model接口的实现类BindingAwareModelMap
    model.addAttribute("f", "/forwad/demo3");
    return "view";
}
/**
     * 在控制器方法中,写下面三种类型,效果是一样的
     * 最后一个Map的写法,必须要求键是String类型,
     * @param model
     * @param modelMap
     * @param map
     * @return
     */
@GetMapping("/demo4")
public String demo4(Model model, ModelMap modelMap, Map<String,Object> map){
    //Model接口的实现类BindingAwareModelMap
    model.addAttribute("f", "/forwad/demo4");
    return "view";
}
```



### 请求之间传递数据

请求之间传递数据有以下三种方法。

- 拼接URL的方式。

```java
// 利用拼接url的方式传递数据,url致命缺点:1.长度是有限制,2.拼接字符繁琐
@GetMapping("/demo21")
public String demo21(){

    return "redirect:demo22?f=redirect-demo21";
}
```



- 利用回话作用域，应用程序作用域。

```java
// 第一组方法:利用session(HttpSession)和application(ServletContext)
@GetMapping("/demo1")
public String demo1(HttpSession session){
    session.setAttribute("f", "/redirect/demo1");
    return "redirect:demo12";
}

```



- 利用RedirectAttributes。 利用addFlashAttribute方法来传递。

   原理:把数据放到session中,读取之后自动删除。

```java
@GetMapping("/demo31") 
public String demo31(RedirectAttributes redirectAttributes){
    //因为我们是重定向到32,所以addAttribute添加的数据自动帮我们拼接到url上
    redirectAttributes.addAttribute("f1", "demo31 f1");
    // addFlashAttribute是把数据自动放到session中,跳转到的方法demo32的model参数自动有这个值.
    redirectAttributes.addFlashAttribute("f", "demo3-flash");
    return "redirect:demo32";
}
//因为addFlashAttribute是把数据放到session中,读取到了之后自动从session中删除数据
//这个方法用来演示已经读不到数据,操作步骤:/demo31->跳转到了32,接着访问/demo33
@GetMapping("/demo33")
public String demo33(){
    return "view";
}

```

## Spring MVC静态资源处理

要处理静态资源之前。我么需要了解servlet的一些原理。

- 当在web.xml中配置多个servlet时,tomcat对其的映射匹配是有优先级的,考虑到在mvc中DispatcherServlet
  的url-pattern常设置为/,所以只说明2种url-pattern,一种是/,另一种是扩展名模式,其它模式的详细情况见我
  写的servlet的md文件。

  **记住:扩展名映射的优先级高于/**

   而且在servlet的url-pattern配置中/ 代表着找不到对应servlet处理当前请求的url时,由这个/对应的servlet处理，简单来说就是/的url-pattern就可以处理所有的请求,比如/first,/demo.css,/a/b/c.js等都可以处理。

  而在tomcat和jetty这种servlet容器中,这个url-pattern为/,其对应的servlet是tomcat自己编写,并配置
  在全局的web.xml中的(在tomcat安装目录下的web.xml中)。

  所以:当DispatcherServlet的url-pattern设置为/,就表示任何请求都交给DispatcherServlet去处理。

- 为什么不能访问静态资源。

  假定在web根目录下有一个demo.css,在mvc环境下为什么不能访问/demo.css,原因是:

1. 项目的web.xml中只配置了一个DispatcherServlet,它的url-pattern为/
2. 所以/demo.css就交给DispatcherServlet去处理
3. DispatcherServlet把/demo.css交给所有的HandlerMapping接口的实现类
4. 遍历所有的HandlerMapping,看哪一个HandlerMapping可以依据/demo.css找到对应的Handler
5. 由于默认情况下,HandlerMapping只会找哪一个方法上修饰了@RequestMapping("/demo.css")
6. 结果找不到,所以HandlerMapping就找不到Handler处理这个请求.
7. 找不到对应的Handler,就没法由HandlerAdapter去处理这个请求.
8. mvc就报404错误
   但是:
9. 当在applicationcontext.xml中配置了mvc:resource就意味添加一个HandlerMapping
   并告诉此handlerMapping,哪些地址可以处理,交给谁处理
   2.所以静态资源的处理就完成了.

### 方式一:
```xml
<mvc:resources mapping="/css/**" location="/static/css/"/>
```
当请求地址为/css/demo.css 时到web根目录下的/static/css/demo.css找文件
当请求地址为/css/main/demo2.css 时到web根目录下的/static/css/main/demo2.css找文件

当有多个位置(location)要设置时,用逗号分隔.mvc内部用ResourceHttpRequestHandler来处理

你也可以把资源放置在类路径下,比如下面的配置
```xml
 <mvc:resources mapping="/css/**" location="classpath:/static/css/"/>
```
上面的location配置不支持classpath*这种配置方式.
> 注意:这种方式需要启用mvc:annotation-driven,因为它会把对静态资源的处理的HandlerMapping
> 注册在最后(优先级最低),不开启就导致RequestMapping可能失效
#### 源码分析
1. 配置mvc:resources时会利用ResourcesBeanDefinitionParser解析
2. 解析器会注册ResourceHttpRequestHandler,此类HttpRequestHandler的实现类,并把location的值传给ResourceHttpRequestHandler
3. 解析器也会注册SimpleUrlHandlerMapping,并设置mapping属性设置的值作为此HandlerMapping的url值
4. 当请求过来时会依据url交给HandlerMapping处理,然后就会调用ResourceHttpRequestHandler来处理资源请求
### 方式二
把资源的处理转交给默认servlet去处理,但仍然利用了spring mvc框架
一般所有的servlet容器都有默认的处理静态资源的servlet,如果想让spring mvc让默认servlet处理静态资源
只需要在DispatcherServlet关联的spring元数据中配置下面的内容即可

```xml
<mvc:default-servlet-handler />
```
如果容器的默认servlet的名字不叫default,那么就设定default-servlet-name属性的值为对应容器的
servlet名字即可.
```xml
<mvc:default-servlet-handler default-servlet-name="xxx"/>
```
mvc内部用DefaultServletHttpRequestHandler来处理默认servlet服务静态资源的情况
> 注意:这种方式需要启用mvc:annotation-driven,因为它会把对静态资源的处理的HandlerMapping
> 注册在最后(优先级最低),不开启就导致RequestMapping可能失效
> 而且这种方式要求资源放置在默认servlet可以访问的地方,比如web根目录下就可以,类路径下就不行
#### 源码分析
    1. 当在xml中设置了mvc:default-servlet-handler之后,会由DefaultServletHandlerBeanDefinitionParser解析
    此解析器的源代码非常少,是学习BeanDefinitionParser的一个好的入口点
    2. 解析器会注册SimpleUrlHandlerMapping 针对的地址为/**,还会注册对应的HttpRequestHandlerAdapter
    3.此HandlerAdapter就是专门处理HttpRequestHandler的执行的,而DefaultServletHttpRequestHandler就是
    HttpRequestHandler的实现类

 >  由于它注册的HandlerMapping的地址为/**,所以可以处理任何请求,所以需要把此HandlerMapping放在最后以避免它先处理了
 >  其它的请求,比如RequestMappingHandlerMapping能处理的请求.这点可以通过设置其order来实现 

### 方式三
直接使用容器的默认servlet处理,不经过spring mvc框架
比如下面的配置
```xml
<servlet-mapping>
    <servlet-name>default</servlet-name>
    <url-pattern>*.css</url-pattern>
</servlet-mapping>
<servlet-mapping>
    <servlet-name>default</servlet-name>
    <url-pattern>*.js</url-pattern>
</servlet-mapping>
```

### 总结：
1. 方式1与方式二都要求配置mvc:annotation-driven 
2. 方式1用到了spring mvc的特性,支持资源解析器链与资源转换.
3. 方式二与方式三,静态资源放置的位置必须是默认servlet可以访问的地方 

**建议开发时用mvc:resources的方式** 

## Spring MVC JSON处理

### 响应JSON数据

响应JSON的方法有三种。

1. 类上面有@Controller注解,方法上有ResponseBody。

```java
/**
     * ResponseBody注解的含义:
     * 1. 就是把方法的返回类型交给一个特殊的特性去处理(HttpMessageConverter)
     * 2.处理的结果直接放到http响应体里面
     * @return
     */
@RequestMapping("/list")
@ResponseBody
public EmpVO list() throws ParseException {

    EmpVO empVO = new EmpVO(1, "aaa", new Date());
    return empVO;
}
```



2. 类上面有@Controller 和ResponseBody注解

```java


@Controller
@ResponseBody
public class HomeController {
    @RequestMapping("/list")
    public EmpVO list() throws ParseException {
        EmpVO empVO = new EmpVO(1, "aaa", new Date());
        return empVO;
    }
}
```

该注解表示本类的下面所有的请求方法都是响应。

3. 类上面有@ResetController注解

```java
@RestController
public class HomeController {
    @RequestMapping("/list")
    public EmpVO list() throws ParseException {
        EmpVO empVO = new EmpVO(1, "aaa", new Date());
        return empVO;
    }
}
```

该注解是组合注解。表示@Controller和ResponsBody的组合。

#### 原理

ResponseBody注解主要是靠HttpMessageConverter来处理,处理方式是
直接把控制器方法的返回数据,经过某一个消息转换器处理之后,发送到http协议
的响应体里面。

#### 日期处理

1. 直接在类上面加JsonFormat,只对这一个有效.只对jackson序列化有效。

```java
@JsonFormat(pattern = "yyyy-MM-dd")
private Date birthday;
```

2. 是在applicationContext中配置消息转换器,这个是全局有效,不需要加JSONFormat注解。

```xml
<mvc:annotation-driven >

    <!--
       1. 当你要调整HttpMessageConverter的时候,就是在这里进行配置
       2. 如果配置register-defaults为true(默认值就是true),就表示默认会注册spring mvc
            自带的许多消息转换器
       3. 如果你自己配置了一个消息转换器,那么会以你配置的为准,就不会再用自带的那一个.

        -->
    <mvc:message-converters register-defaults="true">
        <bean class="org.springframework.http.converter.json.MappingJackson2HttpMessageConverter">
            <property name="objectMapper">
                <bean class="com.fasterxml.jackson.databind.ObjectMapper">
                    <property name="dateFormat" >
                        <bean class="java.text.SimpleDateFormat">
                            <constructor-arg name="pattern" value="yyyy-MM-dd"/>
                        </bean>
                    </property>
                </bean>
            </property>
        </bean>
    </mvc:message-converters>
</mvc:annotation-driven>

```

### 接受JSON数据

步骤如下:
1.请求方法参数上要加RequestBody注解

```java
/**
     * RequestBody注解,就是把请求传递过来的请求体
     * 中的数据利用消息转换器,转换为被它修饰的参数的类型
     * @param empVO
     * @return
     */
    @RequestMapping("/insert")
    @ResponseBody
    public EmpVO insert(@RequestBody EmpVO empVO) {
        System.out.println("-----debug: empVO = " + empVO);
        EmpVO result = new EmpVO(1, "server", new Date());
        return result;
    }

```



2.客户端发起请求时,必须是post请求

```js
/**
* ajax方法的参数含义如下:
* 1.data:表明请求传递的数据
* 2. type:表明请求的方法(比如get,post)
* 3.contentType:表明请求的内容类型
* 4. dataType:是"期望"服务端返回的数据类型
*/
$("#btnInsert").click(function () {
    var data = {id:100,username:"client"};
    $.ajax({
        url:"/insert",
        data: JSON.stringify(data),
        type:"POST",
        contentType:"application/json",
        dataType:"json",
        success:function (data) {
            alert(data.username);

        }

    });
});
```



3.客户端发起请求时,传递过来的数据,必须能反序列化为被
RequestBody修饰的参数的类型.

 ### 源码分析

 #### 初始化时

 我们以代码配置入手,xml配置方式是类似的

 1. 添加EnableWebMvc,导入了WebMvcConfigurationSupport类

 2. WebMvcConfigurationSupport提供配置消息转换器与添加默认转换器的功能,
    可以在此类的getMessageConverters的方法中看到应用

 3. 在WebMvcConfigurationSupport类中配置HandlerAdapter时会用到消息转换器,
    见方法requestMappingHandlerAdapter

 4. 在RequestMappingHandlerAdapter类的afterPropertiesSet方法中有添加返回值处理器,
    它会调用getDefaultReturnValueHandlers方法,而此方法会实例化RequestResponseBodyMethodProcessor对象
    并把消息转换器传递给RequestResponseBodyMethodProcessor对象会选择一个支持的结果处理者,并用它处理结果

    

 #### 控制器方法执行时

  1. RequestMappingHandlerAdapter类的invokeHandlerMethod方法中
  2. invokeHandlerMethod会调用ServletInvocableHandlerMethod对象的invokeAndHandle方法
  3. invokeAndHandle方法会选择一个合适的结果处理者,并用它处理结果,见HandlerMethodReturnValueHandlerComposite
     类的handleReturnValue方法 
  4. 所有的结果处理者中,只要有一个表明它可以处理结果,就直接用这一个处理者,见selectHandler方法
  5. 每一个结果处理者表明自己可以处理结果是靠supportsReturnType方法来实现的
  6. RequestResponseBodyMethodProcessor类的supportsReturnType实现是看是否有ResponseBody注解 
  7. RequestResponseBodyMethodProcessor类的handleReturnValue方法调用writeWithMessageConverters
     (注意:也在这个方法中设置了ModelAndViewContainer对象的setRequestHandled=true,表明直接处理请求,不走后续的视图解析流程)
  8. writeWithMessageConverters方法会遍历所有的消息转换器,通过调用消息转换器的方法canWrite
     确定用哪一个消息转换器
  9. 而MappingJackson2HttpMessageConverter类实现canWrite是看ObjectMapper是否可以序列化方法返回值(见此类的父类中canWrite方法实现)
     10.最后调用消息转换器的write方法,完成响应   

## Spring MVC异常处理

当控制器方法抛出异常,会被标识了@ControllerAdvice注解的类中的标记了@ExceptionHandler方法去处理。

### ControllerAdvice注解

此注解修饰的类一般只写3种类型的方法
1 @InitBinder
2 @ModelAttribute
3 @ExceptionHandler

此注解的属性主要用来限制此类可以作用在哪些控制器上.

### ExceptionHandller注解

下面的代码表明此异常处理方法可以处理算术异常及其子异常。

```java
@ExceptionHandler(ArithmeticException.class)
public String handleArithmeticException(ArithmeticException ae){
    return "error";
}
```

异常处理方法的参数一般就是某个异常类型,可以写Throwable这个顶级异常

异常处理可以返回的类型与RequestMapping注解修饰的方法的返回类型一致。

> 注意:异常处理方法不能处理视图找不到的情况,因为它主要作用在控制器方法执行过程中

### RestControllerAdvice注解

等价于ControllerAdvice + ResponseBody注解


### 异常执行源码分析

初始化时

1. 在DispatcherServlet中的initStrategies方法中调用initHandlerExceptionResolvers方法
2. initHandlerExceptionResolvers方法会找是否在spring中有注册异常处理处理器,没有就用默认的
3. 默认的异常处理器在DispatcherServlet.properties文件中可以看到,其中的ExceptionHandlerExceptionResolver
   就是用来处理@ExceptionHandler注解的
4. ExceptionHandlerExceptionResolver类的afterPropertiesSet方法会调用initExceptionHandlerAdviceCache方法
5. initExceptionHandlerAdviceCache方法会在spring容器中找到所有修饰了
   ControllerAdvice(直接或间接,比如@RestControllerAdvice)注解的bean
6. 实例化ExceptionHandlerMethodResolver类,实例化时会找出所有的异常处理方法(修饰了@ExceptionHandler注解的方法)

执行时:

1. 调用DispatcherServlet的doDispatch,此方法调用processDispatchResult
2. processDispatchResult方法会调用processHandlerException方法
3. processHandlerException方法遍历所有的异常解析器的resolveException方法不返回空就结束遍历
4. 会调用ExceptionHandlerExceptionResolver类的doResolveHandlerMethodException方法
5. doResolveHandlerMethodException会调用getExceptionHandlerMethod,会依据当前抛出的异常,找到合适的
   异常处理方法来处理异常
6. resolveException方法也返回ModelAndView类型
7. 回到processDispatchResult方法,看是否有视图,右视图就调用render方法呈现视图,
   没有就直接响应(比如@ResetControllerAdvice修饰的情况)

> 异常处理是一个理解控制器方法执行逻辑的好地方,相对简单,对理解参数解析器与结果解析器非常好入手.


### ControllerAdvice执行源码分析

1. @ControllerAdvice注解修饰的bean在运行时是靠ControllerAdviceBean记录信息的
2. ControllerAdviceBean主要用在ExceptionHandlerExceptionResolver与RequestMappingHandlerAdapter中
3. 用在异常中的流程上面已经分析过了.用在RequestMappingHandlerAdapter的主要作用是找到InitBinder与ModelAttribute
   两个注解修饰的方法,见initControllerAdviceCache方法
4. InitBinder修饰的方法在会在创建DataBinderFactory对象时使用.ModelAttribute的类似

# Spring MVC拦截器

1. ##### 拦截器：直接或间接实现HandlerInterceptor或者WebRequestInterceptor ####

控制器执行的基本流程：

	1. 控制器方法执行
 	2. 视图解析
 	3. 视图呈现（render）



## 实现HandlerInterceptor接口3个方法的含义理解

1. preHandler是在控制器方法执行之前运行

   返回false表示后续流程就不走了，类似于filter代码不调用chain.doFilter

```java
  @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        System.out.println("2222 pre Handle---");
        return true;
    }
```

	2. postHandler是在控制器方法执行完成之后，但是在视图处理之前运行

```java
 @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        System.out.println("2222post handle-----");
    }
```

3. afterCompletion这个方法是在视图已经处理完毕之后在执行

```java
@Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        super.afterCompletion(request, response, handler, ex);
        System.out.println("22222after compltion----");
    }
```

上述方法都是重写HandlerInterceptor接口实现的。

## 注册拦截器：mvc:intercpetors

在mvc:interceptors下面直接配置拦截器，默认是拦截所有的请求地址

以配置的顺序为执行的顺序

```xml
<mvc:intercpetors>
	<bean class = "com.controller.FirstInterceptor"/>
    <bean class = "com.controller.SecondInterceptor"/>
</mvc:intercpetors>
```

## 静态资源排除设置

下面配置方法可以指定拦截器应用的路径，哪些路径模式生效，哪些排除(exclude)

排除可以配置多个，在实际场景下主要应用来排除静态资源，需要灵活配置哪些资源需要排除或者在某些条件下排除就需要在preHandle方法中写代码实现。

在我们案例中静态资源的配置情况来看，排除地址应该写为/* * /*.css,而不能写为 *.css

ant: 

​	/a?c: /abc，/adc

​	/*.css : a.css，abc.css

​	/* */ *.css：/a/b/c.css，/a.css，/ab/cde/xxx/aab.css

```xml
<mvc:intrceptors>
    <mvc:interceptor>
        <mvc:mapping path="/**"/>
        <mvc:exclude-mapping path = "/login" />
        <mvc:exclude-mapping path = "/index" />
        <bean class="com.controller.AuthenticationInterceptor"/>
    </mvc:interceptor>
</mvc:intrceptors>
```

## Filter与Interceptor

### 相同点：

1. 执行原理类似，都是环绕的执行方式
2. 都是用来进行全局的一些处理，不用把代码写到每一个处理者里面
3. 都可以认为是一个切面类

### 不同点：

	1. 拦截器是被spring管理的，所以可以注入一些东西
 	2. 拦截器可以设置排除一些路径，而且支持ant格式的模式地址

# Spring MVC文件上传下载

## 文件上传

### 页面：

处理文件上传的方法，参数类型写上MultipartFile，然后参数名是页面中文件上传控件的名字

得到上传过来的文件名，一般要改名，比如用UUID

```java
@PostMapping("/你定义的路径")
public String upload(MultipartFile myfile){
    String filename = myfile.getOringinalFilename();
    String path = "你要传的路径"+File.separator+ filename;
    File file = new File(path);
    try{
        myfile.transferTo(file);
    }catch(IOException e){
        e.printStackTrace();
    }
    return "ok";
}
```

同时在jsp页面中必须是使用post的方式来提交你要上传的文件。

### 服务端

#### 方法一：

1. 添加apache commons依赖
2. 配置commons解析器CommonsMultipartResolver,id的值必须配置并且必须是multipartResolver
3. 控制类方法参数类型是MultipartFile,参数名是页面中文件控件的名字（不匹配时，可以用RequestParam注解，注解的值等于控件名即可）

> 为什么必须是multipartResolver这个名字，可以在DispatcherServlet的initMultipartResolver方法中看到原因，因为它固定式以这个名字来找MultipartResolver类型的bean的

#### 方法二：(推荐的方法，这种方法是利用servlet3.0的方式，所以你的tomcat必须支持servlet 3.0)

	1. 配置DispatcherServlet的文件上传部分
 	2. 配置解析器类型为StandardServletMultipartResolver,id的值必须配置并且必须是multipartResolver（这个配置是可选的，可以不用配置）
 	3. 不需要添加commons的依赖

> 可以不用配置StandardServletMultipartResolver的原因是RequestParamMethodArgumentResovler
>
> 解析参数时，会委托给MultipartResolutionDelegate类的resolveMultipartArgument的方法去解析



## 文件下载

ResponseEntity：是代表Http协议中的头（header）和体(body)

InputSteamSouce这个接口是用来得到一个输入流的(InputStream)

得到输入流之后就交给spring mvc框架去读取信息，然后在响应给浏览器

下面代码的核心逻辑就是构建一个Http的响应，包含头和体

	1. 头包含响应的内容类型
 	2. 体就包含文件的信息(输入流)

```java
@RequestMapper("/你指定的路径")
public ResponseEntity<InputStreamSource> download(String filename) throw IOException{
    //在mav系统下pathSeparator值为：，separator值为：/
    String fullPath = "你要下载到的路径"+File.separator+filename;
    File file= new File(fullPath);
    
    //这个guess方法是依据文件名来取得媒体类型也就是mime类型，
    //比如常见有Image/jpg,application/json
    String mediaType = URLConnection.guessContentTypeFromName(filename);
    if(mediaType == null){
        //识别不了时，通通用这个，一般用来表示下载二进制数据
        mediaType = MediaType.APPLICATION_OCTET_STREAM_VALUE;
    }
    HttpHeaders respHeaders = new HttpHeaders();
    respHeaders.setContentType(MediaType.parseMediaType(mediaType));
    
    //attachment:附加的意思，表示告诉浏览器弹出一个另存为窗口来下载文件，inline是直接在浏览器中打开下载的文件
    //需要进行URL编码处理，否则另存为对话框不能显示中文
    respHeaders.setContentDispositionFormData("attachment",
                                     URLEncode.encode(filename,"UTF-8"));
    InputStreamResource isr = new InputStreamResourse(new FileInputStream(file));
    return new ResponseEntity<>(isr,respHeaders,HttpStatus.OK);
}
```

## 中文乱码

1. tomcat层面设置utf-8
2. 配置全局的编码过滤器

```xml
 <filter>
        <filter-name>encoding</filter-name>
        <filter-class>org.springframework.web.filter.CharacterEncodingFilter</filter-class>
        <init-param>
            <param-name>forceEncoding</param-name>
            <param-value>true</param-value>
        </init-param>
        <init-param>
            <param-name>encoding</param-name>
            <param-value>UTF-8</param-value>
        </init-param>
    </filter>
```

3. 下载文件的时候文件名进行url编码

## 详细说明

### spring mvc中进行文件上传处理有两种做法

 1. 第一种上传方式，利用第三方的库来处理文件上传，这个库主要的作用就是解析http协议中文件数据与表单数据，就是multipart/form-data编码类型提交过来的数据

    这个库一般用apache commons- fileupload

    做法的第一步：

    	1. 添加apache commons-flieupload依赖
     	2. 告诉mvc,我现在准备用这个库来做文件上传

    ```xml
    <bean id ="multipartResolver" class = "org.springframework.web.multipart.commons.CommonsMultipartResolver"/>
    ```

    ​		id值必须是multipartResolver.

    	3. 处理文件上传的方法类型必须是MultipartFile,参数名必须跟页面中file控件的名字一样，如果不一样就利用@RequestParam注解取别名
     	4. 利用MultipartFile对象的transferTo方法保存文件即可

	2. 第二种上传方式，就是利用Servlet 3.0的新技术来处理文件上传

    	1. 在我们的DispatcherServlet上进行multipart-config的设置(在web.xml中)
    	2. 告诉mvc，你要用servlet标准的上传技术，也就是一个MultipartResolver解析器 * 

    ```xml
    <bean id ="multipartResolver" class = "org.springframework.web.multipart.support.StandardServletMultipartResolver"
    ```

    ​		id必须是multipartResolver

上传过程中的中文的处理

为什么中文会是一个问题，原因有以下几个方面产生

	1. tomcat容器本身默认的编码是ISO-8859-1
 	2. 页面不是utf-8
 	3. 浏览器传递的数据编码不是utf-8

解决中文文件名上传的问题

1. 需要在jsp里面设置相关的utf-8
2. 配置一个过滤器来处理请求的编码问题

## 参考资料

https://www.baeldung.com/spring-file-upload

# Spring MVC 动态注册

### servlet动态注册方法一

	1. 写一个类实现ServletContainerInitializer接口
 	2. 在此实现类中写上注册的代码

```java
public class MyServletContaninerInit implements ServletCOntainerInitializer{
    @Override
    public void onStartup(Set<Class<?>> c,ServletContext ctx) throws ServletException{
        ServletRegistration.Dynamic servletRegistration = ctx.addServlet("first",new FirstServlet());
        servletRegistration.addMapping("/first");
    }
}
```

3.  在类路径下(maven项目就是在resources下)建立/META-INF/services文件夹，然后在此文件夹下建立一个文件，名字“必须”是javax.serlvet.ServletContainerInitializer(是ServletContainerInitializer接口的全称)
4. 再此文件中，填上第一步写的类的全称，如果有多个类实现了SerlvetContainerInitializer接口，就一行一个



### 动态注册servlet的第二种方法

本质上与第一种方法是类似

1. 写一个类实现ServletContainerInititalizer接口

```java
@HandlesTypes(MyApplnitializer.class)
public class MyServletContainerInit implements ServletContainerInitializer{
    @Override
    public void onStartup(Set<Class<?>> clazzes,ServletContext ctx) throws ServletException{
        for(Class<?> clz:clazzes){
            //就是判断传递过来的类型是否是MyAppInitializer的实现类
            //因为HandleTypes可以填多个类型
            if(MyAppInitialize.class.isAssignableFrom(clz)){
                try{
                    MyAppInitializer instance = (MyAppInitializer) clz.newInstance();
                }catch(InstantiationException e){
                    e.printStackTrace();
                }catch(InstantiationException e){
                    e.printStackTrace();
                }catch(IllegalAccessException e){
                    e.printStackTrace();
                }
            }
        }
    }
}
```

2. 写一个接口（一般是接口），比如叫MyAppInitializer

3. 在ServletContainerInitializer实现类上添加@HandlerTypes注解，指定第二步的接口类型用来告诉ServletContainerInitializer接口实现类的写法一般就是直接调用第二步接口所有实现类的某个方法

4. ServletContainerInitializer接口实现类的写法一般就是直接调用第二步接口所有实现类的某个方法。



### 参考资料

https://www.ibm.com/developerworks/cn/java/j-lo-servlet30/index.html