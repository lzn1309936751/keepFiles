
$(function(){
    $("#btnLogin").click(function(){
        $.ajax({
            url:"http://localhost:8080/login",
            type:"POST",
            data:{username:"user",password:"123"},
            xhrFields:{
                withCredentials:true
            },
            success:function(result){
                if(result.code=="200"){
                    alert('ok');
                    //href="/xxx";
                }else if(result.code=="500"){
                    alert('账号密码不对');
                }
                
                console.log(result);
            }
            
        });
        
    }); // btnLogin
    
    
    $("#btnQuery").click(function(){
        $.ajax({
            url:"http://localhost:8080/api/query",
            type:"GET",
            // xhrFields:{
            // 	withCredentials:true
            // },
            success:function(result){
                alert('1')
                alert(result)
                if(result.code == "403"){
                    //href = "login.html";
                    alert(result.msg);
                    
                }else if(result.code == "200"){
                    alert(result.msg);
                }
                console.log(result);
            }
            
        });
        
    });
})//