package com.nf.privilege.controller.role;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nf.privilege.controller.BaseServlet;
import com.nf.privilege.entity.Role;
import com.nf.privilege.service.RoleService;
@WebServlet("/admin/role/list")
public class RoleListServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RoleService roleService = new RoleService();
		//��ѯ���н�ɫ
		
		List<Role> role = roleService.getAllRole();
		request.setAttribute("role", role);
		request.getRequestDispatcher("/WEB-INF/views/be/roleList.jsp").forward(request, response);
	}

}
