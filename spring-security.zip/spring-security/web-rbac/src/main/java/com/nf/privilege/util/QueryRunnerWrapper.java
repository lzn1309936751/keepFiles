package com.nf.privilege.util;

import java.sql.Connection;
import java.sql.SQLException;
import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;


public class QueryRunnerWrapper {
	public QueryRunnerWrapper(){}
	private QueryRunner runner = new QueryRunner(true);
	public boolean modify(String sql,Object...params){
		Connection conn = null;
		int count = 0;
		try{
			conn =ConnectionHelper.getConnection();
			count = runner.update(conn, sql, params);
		}catch(SQLException e){
		}finally{
			DbUtils.closeQuietly(conn);
		}
		return count>0;
	}
	public  <T> T  query(String sql,ResultSetHandler<T> rsh,Object...params){
		T list = null;
		Connection conn = null;
		try{
			conn =ConnectionHelper.getConnection();
			list = runner.query(conn, sql, rsh, params);
		}catch(SQLException e){
		}finally{
			DbUtils.closeQuietly(conn);
		}
		return list;
	}
	
}
