package com.nf.privilege.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nf.privilege.entity.Privilege;
import com.nf.privilege.entity.Role;
import com.nf.privilege.entity.User;
import com.nf.privilege.service.PrivilegeService;
import com.nf.privilege.service.RoleService;
import com.nf.privilege.service.UserService;

public class PrivilegeFilter implements Filter{

	
	

	
	private String loginUrl = null;
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp;
	
		HttpSession session = request.getSession();
		

		User user = (User)session.getAttribute("user");
		if(user==null) {
			response.sendRedirect(loginUrl);
			return;
		}

		UserService userService = new UserService();
		
		Role role = userService.getUserRole(user.getId());
		

		
		RoleService roleService = new RoleService();
		
		List<Privilege> privileges = roleService.getRolePrivilege(role.getId());
		 
		
		String requestUri = getRequestUrl(request);
		List<String> list = getprivilege(privileges);
		
		if(isAllowd(list, requestUri)) {
			chain.doFilter(req, resp);
		}else {
			response.sendRedirect("/privilege.html");
		}
	}
	
	public boolean isAllowd(List<String> list,String requestUri) {
		boolean isAllowd = false;
		for(String allowList:list) {
			if(allowList.equals(requestUri)) {
				isAllowd=true;
				break;
			}
		}
		return isAllowd;
	}
	
	
	
	//��ȡȨ��·��
	public List<String> getprivilege(List<Privilege> privileges){
		Set<String> set = new TreeSet<String>();
		for(Privilege privilege:privileges) {
			String[] uris = privilege.getUri().trim().split(",");			
			if(uris!=null) {
				for(String uri:uris) {
					set.add(uri);
				}
			}
		}
		return new ArrayList<String>(set);
	}
	

	public String getRequestUrl(HttpServletRequest request) {
		String context = request.getContextPath();		
		String requestUri =  request.getRequestURI();
		String result = requestUri.substring(context.length());
		return result;
	}
	
	@Override
	public void init(FilterConfig config) throws ServletException {
		
		loginUrl = config.getInitParameter("loginUrl");
		
	}

}
