package com.nf.privilege.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class ConnectionHelper {
	//配置文件路径
	private final static String RESOURCE = "/dbconfig.properties";
	//调用jdbc类路
	private final static String DIRVERCASSNAME = "db.dirverClassName";
	//调用数据
	private final static String DBURL = "db.url";
	
	private final static String DBUSERNAME = "db.username";
	private final static String DBPASSWORD = "db.password";
	
	private static String DRIVERCLASSNAME = "";
	private static String URL = "";
	private static String USERNAME = "";
	private static String PASSWORD = "";
	/**
	 * class.getResoureceAsStream与classload区别
	 * class.在本类中�?在目录查找资源文�?
	 * classload ,在类文件的根目录下找资源文件
	 */
	static{
		//读取配置文件
		InputStream stream = ConnectionHelper.class.getResourceAsStream(RESOURCE);
		Properties pro = new Properties();
		try {
			
			pro.load(stream);
			DRIVERCLASSNAME = pro.getProperty(DIRVERCASSNAME);
			URL = pro.getProperty(DBURL);
			USERNAME = pro.getProperty(DBUSERNAME);
			PASSWORD = pro.getProperty(DBPASSWORD);
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				stream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	//加载数据库驱�?
	static{
		try {
			Class.forName(DRIVERCLASSNAME);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 打开数据库连
	 * @return 返回数据库连
	 */
	public static Connection getConnection(){
		Connection conn = null;
		try {
			//打开数据�?
			conn = DriverManager.getConnection(URL,USERNAME,PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	public static void main(String[] args) {
		System.out.println(getConnection());
	}
}
