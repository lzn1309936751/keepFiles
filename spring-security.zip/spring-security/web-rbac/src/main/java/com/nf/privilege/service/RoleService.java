package com.nf.privilege.service;

import java.util.List;

import com.nf.privilege.dao.RoleDaoImpl;
import com.nf.privilege.entity.Privilege;
import com.nf.privilege.entity.Role;

public class RoleService {
	
    RoleDaoImpl roleDao = new RoleDaoImpl();


    public boolean addRole(Role role) {

    	return roleDao.addRole(role);
    }

    public Role findRole(String id) {
        return roleDao.findRole(id);
    }


    public List<Role> getAllRole() {
        return roleDao.getAll();
    }


    public List<Privilege> getRolePrivilege(String role_id) {
        return roleDao.getPrivilege(role_id);
	}


    public void updateRolePrivilege(Role role, List<Privilege> privileges) {
        roleDao.getPrivilegeRole(role, privileges);
    }
}