package com.nf.privilege.controller.user;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nf.privilege.controller.BaseServlet;
import com.nf.privilege.entity.Privilege;
import com.nf.privilege.entity.Role;
import com.nf.privilege.entity.User;
import com.nf.privilege.service.RoleService;
import com.nf.privilege.service.UserService;
@WebServlet("/login/query")
public class UserQueryServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName=request.getParameter("userName");
		String password = request.getParameter("password");
		UserService userService = new UserService();
		User user = userService.findUser(userName, password);
		HttpSession session = request.getSession();
//		Role role = userService.getUserRole(user.getId());
//		RoleService roleService = new RoleService();
	
		if(user!=null) {
//		  List<Privilege> privileges = roleService.getRolePrivilege(role.getId());
		 
//		 / session.setAttribute("privileges", privileges);
          session.setAttribute("user", user);
		  response.getWriter().print(true);
		}else {
			response.getWriter().print(false);
		}
	}
}
