package com.nf.privilege.controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

public class BaseServlet extends HttpServlet{
	public static final int PAGE_SIZE=9; 
	
}
