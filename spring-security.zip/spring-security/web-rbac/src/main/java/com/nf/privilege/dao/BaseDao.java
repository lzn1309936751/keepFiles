package com.nf.privilege.dao;

import com.nf.privilege.util.QueryRunnerWrapper;

public abstract class BaseDao {
	protected QueryRunnerWrapper runner = new QueryRunnerWrapper();
	
}
