package com.nf.privilege.controller.user;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nf.privilege.controller.BaseServlet;
import com.nf.privilege.entity.User;
import com.nf.privilege.service.UserService;
@WebServlet("/admin/user/inser")
public class UserInserServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userName = request.getParameter("userName");		
		String password = request.getParameter("password");
		String roleId = request.getParameter("roleId");
		User user = new User();
		user.setUsername(userName);
		user.setPassword(password);;
		UserService userService = new UserService();

		userService.addUser(user);

		User u = userService.findUser(userName,password);
		
		userService.updateUserRole(u, roleId);
		
	}
	
}
