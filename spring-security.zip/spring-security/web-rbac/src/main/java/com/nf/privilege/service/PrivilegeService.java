package com.nf.privilege.service;

import java.util.List;

import com.nf.privilege.dao.PrivilegeDaoImpl;
import com.nf.privilege.entity.Privilege;

public class PrivilegeService {
	
    PrivilegeDaoImpl privilegeDao = new PrivilegeDaoImpl();





    public Privilege findPrivilege(String id) {
        return privilegeDao.findPrivilege(id);
    }


    public List<Privilege> getAllPrivileges() {
        return privilegeDao.getAllPrivileges();
    }
}
