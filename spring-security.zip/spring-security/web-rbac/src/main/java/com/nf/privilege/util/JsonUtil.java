package com.nf.privilege.util;

import java.io.IOException;
import java.io.OutputStream;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {
	public static void write(OutputStream out, Object value) {
		ObjectMapper mapper= new ObjectMapper();
		try {
			mapper.writeValue(out, value);
		} catch (IOException e) {
			e.printStackTrace();
			
		}
	}
}
