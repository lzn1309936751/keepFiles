package com.nf.privilege.controller.role;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nf.privilege.controller.BaseServlet;
import com.nf.privilege.entity.Privilege;
import com.nf.privilege.entity.Role;
import com.nf.privilege.service.PrivilegeService;
import com.nf.privilege.service.RoleService;
@WebServlet("/admin/role-privilege/inser")
public class RolePrivilegeInsertServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String[] ids = request.getParameterValues("privilege_id");

		String roleId = request.getParameter("role_id");
		

		RoleService roleService = new RoleService();
		Role role = roleService.findRole(roleId);
		

		PrivilegeService privilegeService = new PrivilegeService();
		List<Privilege> list = new ArrayList<Privilege>();
		for(String pid:ids) {
			Privilege privilege = privilegeService.findPrivilege(pid);
			list.add(privilege);
			
		}
		
		roleService.updateRolePrivilege(role, list);
		response.getWriter().print(true);
		
	}
}
