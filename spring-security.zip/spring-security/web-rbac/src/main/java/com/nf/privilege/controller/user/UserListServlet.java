package com.nf.privilege.controller.user;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nf.privilege.controller.BaseServlet;
import com.nf.privilege.entity.Role;
import com.nf.privilege.entity.User;
import com.nf.privilege.service.RoleService;
import com.nf.privilege.service.UserService;
@WebServlet("/admin/user/list")
public class UserListServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserService userService = new UserService();
		List<User> allUser = userService.getAllUser();
		
		RoleService roleService = new RoleService();
		List<Role> roles = roleService.getAllRole();
		request.setAttribute("allUser",allUser);

		request.setAttribute("roles",roles);
		request.getRequestDispatcher("/WEB-INF/views/be/userList.jsp").forward(request, response);
	}
}
