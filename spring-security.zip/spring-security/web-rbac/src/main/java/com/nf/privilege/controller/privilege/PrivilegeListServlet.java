package com.nf.privilege.controller.privilege;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nf.privilege.controller.BaseServlet;
import com.nf.privilege.entity.Privilege;
import com.nf.privilege.service.PrivilegeService;
import com.nf.privilege.service.RoleService;

@WebServlet("/admin/privilege/list")
public class PrivilegeListServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		
		
		List<Map<String,Object>> jsonArray = new ArrayList<Map<String,Object>>();
		
		

		PrivilegeService privilegeService = new PrivilegeService();
		List<Privilege> list = privilegeService.getAllPrivileges();

		String roleId = request.getParameter("roleId");
		RoleService roleService = new RoleService();
		

		List<Privilege> rolePrivilege = roleService.getRolePrivilege(roleId);
		
		
		for(Privilege p:list) {

			Map<String, Object> jsonObject = new HashMap<String, Object>();
			jsonObject.put("id", p.getId());
			jsonObject.put("pId", p.getPid());
			jsonObject.put("name", p.getName());
			jsonObject.put("open","true");
			for(Privilege r:rolePrivilege) {

				if(p.getId().equals(r.getId())) {
					jsonObject.put("checked","true");
				}
			}
			jsonArray.add(jsonObject);
			
			
		}
		ObjectMapper mapper= new ObjectMapper();
		String json = mapper.writeValueAsString(jsonArray);
		response.getWriter().print(json);
	}
}