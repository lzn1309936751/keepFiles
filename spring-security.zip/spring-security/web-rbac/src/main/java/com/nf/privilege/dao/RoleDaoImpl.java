package com.nf.privilege.dao;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.nf.privilege.entity.Privilege;
import com.nf.privilege.entity.Role;

public class RoleDaoImpl extends BaseDao{
	

	public boolean addRole(Role role) {
		String sql = "insert into role values(?,?)";
		return runner.modify(sql,role.getName(),role.getDescription());
	}

	public Role findRole(String id) {
		String sql = "select * from role where id = ? ";
		BeanHandler<Role> rsh = new BeanHandler<>(Role.class);
		return runner.query(sql, rsh, id);
	}

	public List<Role> getAll(){
		String sql = "select * from Role";
		BeanListHandler<Role> rsh = new BeanListHandler<Role>(Role.class);
		return runner.query(sql, rsh);
	}
	

	public List<Privilege> getPrivilege(String role_id){
		String sql ="select p.* from privilege p inner join role_privilege rp on p.id=rp.privilege_id where rp.role_id = ? ";
		BeanListHandler<Privilege> rsh = new BeanListHandler<Privilege>(Privilege.class);
		return runner.query(sql, rsh, role_id);
	}
	

	public void getPrivilegeRole(Role role,List<Privilege> privileges) {

		String delete = "delete from role_privilege where role_id = ? ";
		runner.modify(delete,role.getId());

		String sql ="insert into role_privilege(role_id,privilege_id) values(?,?)";
		for(Privilege privilege:privileges) {
			runner.modify(sql, role.getId(),privilege.getId());
		}
	}

}
