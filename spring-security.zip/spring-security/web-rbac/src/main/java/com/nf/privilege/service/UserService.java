package com.nf.privilege.service;

import java.util.List;

import com.nf.privilege.dao.UserDaoImpl;
import com.nf.privilege.entity.Role;
import com.nf.privilege.entity.User;

public class  UserService{
	
	
    UserDaoImpl userDao = new UserDaoImpl();


    public boolean  addUser(User user) {

        return userDao.addUser(user);
    }


    public User findUser(String id) {
        return userDao.findUser(id);
    }


    public List<User> getAllUser() {
        return userDao.getAll();
    }


    public Role getUserRole(String user_id) {
        return userDao.getRoles(user_id);
    }


    public void updateUserRole(User user,String roleId) {

        userDao.updateRole(user, roleId);
    }
    public User findUser(String userName, String password) {
    	return userDao.findUser(userName, password);
    }
}
