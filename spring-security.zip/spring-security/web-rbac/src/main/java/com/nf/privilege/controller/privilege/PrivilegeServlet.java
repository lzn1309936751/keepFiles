package com.nf.privilege.controller.privilege;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nf.privilege.controller.BaseServlet;
import com.nf.privilege.entity.Privilege;
import com.nf.privilege.entity.Role;
import com.nf.privilege.service.RoleService;
import com.nf.privilege.service.UserService;
import com.nf.privilege.util.JsonUtil;

@WebServlet("/privileges/query")
public class PrivilegeServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userId = request.getParameter("id");
		UserService userService = new UserService();
		RoleService roleService = new RoleService();
		Role role = userService.getUserRole(userId);

		Role roles = userService.getUserRole(userId);

		List<Privilege> list = roleService.getRolePrivilege(roles.getId());
		
		JsonUtil.write(response.getOutputStream(), list);
	}
}
