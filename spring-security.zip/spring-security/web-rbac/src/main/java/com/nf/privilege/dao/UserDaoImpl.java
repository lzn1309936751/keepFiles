package com.nf.privilege.dao;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.nf.privilege.entity.Privilege;
import com.nf.privilege.entity.Role;
import com.nf.privilege.entity.User;

public class UserDaoImpl extends BaseDao{
	
	

	public boolean addUser(User user) {
		String sql = "insert into user values(?,?)";
		return runner.modify(sql, user.getUsername(), user.getPassword());
	}
	
	

	public User findUser(String id) {
		String sql = "select * from user where id = ? ";
		BeanHandler<User> rsh = new BeanHandler<>(User.class);
		return runner.query(sql, rsh, id);
	}
	public List<User> getAll(){
		String sql = "select u.*,r.name from user u inner join user_role ur on u.id=ur.user_id inner join role r on ur.role_id =r.id";
		BeanListHandler<User> rsh = new BeanListHandler<User>(User.class);
		return runner.query(sql, rsh);
	}
	
	

	public Role getRoles(String user_id){

		String sql = "select r.* from role r,user_role ur where ur.user_id = ? and r.id = ur.role_id";
		BeanHandler<Role> rsh = new BeanHandler<Role>(Role.class);
		return runner.query(sql, rsh, user_id);	
	}
	
	
	public void updateRole(User user,String roleId) {

		String delete = "delete user_role where user_id = ? ";
		runner.modify(delete, user.getId());

		String add =  "insert into user_role (user_id,role_id) values(?,?)";
		
		runner.modify(add, user.getId(),roleId);
	
	}
	

	 public User findUser(String userName, String password) {
        String sql = "select * from user where username = ? and password = ?  ";
        BeanHandler<User> rsh = new BeanHandler<User>(User.class);
        User user = runner.query(sql, rsh, userName,password);
        return user;
	}
}
