package com.nf.privilege.dao;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.nf.privilege.entity.Privilege;

public class PrivilegeDaoImpl extends BaseDao {
	
	
	

	public Privilege findPrivilege(String id) {
		String sql = "select * from privilege where id = ? ";
		BeanHandler<Privilege> rsh = new BeanHandler<>(Privilege.class);
		return runner.query(sql, rsh, id);
	}

	public List<Privilege> getAllPrivileges(){
		String sql = "select * from privilege";
		BeanListHandler<Privilege> rsh = new BeanListHandler<Privilege>(Privilege.class);
		return runner.query(sql, rsh);
	}
	
}
