package com.nf.privilege.controller.be;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nf.privilege.controller.BaseServlet;
@WebServlet("/admin/not/list")
public class NotListServlet  extends BaseServlet{
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/views/be/notList.jsp").forward(request, response);
	}

}
