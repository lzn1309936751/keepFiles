package main.java.com.service;


import main.java.com.dao.UserDao;
import main.java.com.entity.DeptEntity;
import main.java.com.entity.UserEntity;
import main.java.com.utils.ConnectionHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author lzn
 */
public class UserService {
    UserDao userDao=new UserDao();
    /**
     * 查询用户所有记录
     */
    public List<UserEntity> query(int start,int num){
        return userDao.query(start, num);
    }

    /**
     * 获取总记录数
     */
    public int getRecordCount(){
        return userDao.getRecordCount();
    }

    /**
     * 查询用户一条记录
     */
    public UserEntity queryById(Integer id){
        return userDao.queryById(id);
    }

    /**
     * 添加用户
     * @param userName,deptId
     * @return
     */
    public int insert(String userName,Integer deptId){
        return userDao.insert(userName, deptId);
    }

    /**
     * 修改用户
     * @param userName,deptId,userId
     * @return
     */
    public int update(String userName,Integer deptId,Integer userId){
        return userDao.update(userName, deptId, userId);
    }

    /**
     * 删除部门
     * @param userId
     * @return
     */
    public int delete(Integer userId){
        return userDao.delete(userId);
    }
}
