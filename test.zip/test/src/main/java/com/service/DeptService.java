package main.java.com.service;

import main.java.com.dao.DeptDao;
import main.java.com.entity.DeptEntity;
import main.java.com.utils.ConnectionHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * @author lzn
 */
public class DeptService{
    DeptDao deptDao=new DeptDao();

    /**
     * 部门查询所有记录
     */
    public List<DeptEntity> query(int start,int end){
        return deptDao.query(start, end);
    }

    /**
     * 获取总记录数
     */
    public int getRecordCount(){
        return deptDao.getRecordCount();
    }

    /**
     * 部门查询一条记录
     */
    public DeptEntity queryById(Integer id){
        return deptDao.queryById(id);
    }

    /**
     * 部门添加
     * @param deptName
     * @return
     */
    public int insert(String deptName){
        return deptDao.insert(deptName);
    }

    /**
     * 部门修改
     * @param deptName,deptId
     * @return
     */
    public int update(String deptName,Integer deptId){
        return deptDao.update(deptName,deptId);
    }

    /**
     * 删除部门
     * @param deptId
     * @return
     */
    public int delete(Integer deptId){
        return deptDao.delete(deptId);
    }
}
