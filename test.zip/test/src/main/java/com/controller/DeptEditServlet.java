package main.java.com.controller;


import main.java.com.entity.DeptEntity;
import main.java.com.service.DeptService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author lzn
 */
@WebServlet("/deptEdit")
public class DeptEditServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer deptId=Integer.valueOf(req.getParameter("deptId"));
        DeptService deptService=new DeptService();
        DeptEntity dept=deptService.queryById(deptId);
        req.setAttribute("dept",dept);
        req.getRequestDispatcher("/WEB-INF/views/deptEdit.jsp").forward(req,resp);
    }
}
