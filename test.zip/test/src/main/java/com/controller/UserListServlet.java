package main.java.com.controller;

import main.java.com.entity.UserEntity;
import main.java.com.entity.UserVO;
import main.java.com.service.UserService;
import main.java.com.utils.PageInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @author lzn
 */
@WebServlet("/userList")
public class UserListServlet extends HttpServlet {
    private static final Integer PAGESIZE=3;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        UserService userService=new UserService();
        Integer recordCount=userService.getRecordCount();
        PageInfo pageInfo=new PageInfo(getParameterInteger(req,"pageNo",1),recordCount,PAGESIZE);
        List<UserEntity> userList=userService.query(pageInfo.getOffset(),PAGESIZE);
        UserVO userVO=new UserVO(pageInfo,userList);

        req.setAttribute("userVO",userVO);
        req.getRequestDispatcher("/WEB-INF/views/userList.jsp").forward(req,resp);
    }

    private Integer getParameterInteger(HttpServletRequest req, String pageNo, int i) {
        String pageno=req.getParameter(pageNo);
        Integer pageNum=0;
        if (pageno==""||pageno==null){
            pageNum=i;
        }else {
            pageNum=Integer.valueOf(pageno);
        }
        return pageNum;
    }

}
