package main.java.com.controller;

import main.java.com.entity.DeptEntity;
import main.java.com.entity.DeptVO;
import main.java.com.service.DeptService;
import main.java.com.utils.PageInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @author lzn
 */
@WebServlet(name = "deptList",urlPatterns="/deptList")
public class DeptListServlet extends HttpServlet {
    private static final Integer PAGESIZE=3;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        DeptService deptService=new DeptService();
        int recordCount=deptService.getRecordCount();
        PageInfo pageInfo=new PageInfo(getParameterInteger(req,"pageNo",1),recordCount,PAGESIZE);
        List<DeptEntity> deptList=deptService.query(pageInfo.getOffset(),PAGESIZE);
        DeptVO deptVO=new DeptVO(pageInfo,deptList);
        req.setAttribute("deptVO",deptVO);
        req.getRequestDispatcher("/WEB-INF/views/deptList.jsp").forward(req,resp);
    }

    private Integer getParameterInteger(HttpServletRequest req, String pageNo, int i) {
        String pageno=req.getParameter(pageNo);
        Integer pageNum=0;
        if (pageno==""||pageno==null){
            pageNum=i;
        }else {
            pageNum=Integer.valueOf(pageno);
        }
        return pageNum;
    }
}
