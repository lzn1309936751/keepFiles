package main.java.com.controller;

import main.java.com.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author lzn
 */
@WebServlet("/userInsert")
public class UserInsertServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");
        UserService userService=new UserService();
        String userName=req.getParameter("userName");
        Integer deptId=Integer.valueOf(req.getParameter("deptId"));

        userService.insert(userName,deptId);
        resp.sendRedirect("/userList");
    }
}
