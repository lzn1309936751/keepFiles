package main.java.com.controller;

import main.java.com.entity.DeptEntity;
import main.java.com.service.DeptService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @author lzn
 */
@WebServlet("/userAdd")
public class UserAddServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        DeptService deptService=new DeptService();
        List<DeptEntity> deptList=deptService.query(0,100);
        req.setAttribute("deptList",deptList);
        req.getRequestDispatcher("/WEB-INF/views/userAdd.jsp").forward(req,resp);
    }
}
