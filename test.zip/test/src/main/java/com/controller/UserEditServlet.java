package main.java.com.controller;


import main.java.com.entity.DeptEntity;
import main.java.com.entity.UserEntity;
import main.java.com.service.DeptService;
import main.java.com.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @author lzn
 */
@WebServlet("/userEdit")
public class UserEditServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer userId=Integer.valueOf(req.getParameter("userId"));
        UserService userService=new UserService();
        UserEntity user=userService.queryById(userId);
        DeptService deptService=new DeptService();
        List<DeptEntity> deptList=deptService.query(1,100);

        req.setAttribute("deptList",deptList);
        req.setAttribute("user",user);
        req.getRequestDispatcher("/WEB-INF/views/userEdit.jsp").forward(req,resp);
    }
}
