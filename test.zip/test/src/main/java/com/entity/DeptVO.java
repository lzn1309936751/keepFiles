package main.java.com.entity;

import main.java.com.utils.PageInfo;

import java.util.List;

/**
 * @author lzn
 */
public class DeptVO {
	private PageInfo pageInfo;
	private List<DeptEntity> dept;
	
	public DeptVO(){
		
	}
	
	public DeptVO(PageInfo pageInfo,List<DeptEntity> dept) {
		this.pageInfo=pageInfo;
		this.dept=dept;
	}
	
	public PageInfo getPageInfo() {
		return pageInfo;
	}
	public void setPageInfo(PageInfo pageInfo) {
		this.pageInfo = pageInfo;
	}
	public List<DeptEntity> getDept() {
		return dept;
	}
	public void setDept(List<DeptEntity> dept) {
		this.dept = dept;
	}
}
