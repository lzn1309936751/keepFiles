package main.java.com.entity;

/**
 * @author lzn
 */
public class DeptEntity {
    private Integer deptId;
    private String deptName;

    public void setDeptId(Integer deptId) {
        this.deptId = deptId;
    }

    public Integer getDeptId() {
        return deptId;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getDeptName() {
        return deptName;
    }
}
