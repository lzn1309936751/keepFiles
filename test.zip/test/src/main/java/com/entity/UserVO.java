package main.java.com.entity;

import main.java.com.utils.PageInfo;

import java.util.List;

/**
 * @author lzn
 */
public class UserVO {
	private PageInfo pageInfo;
	private List<UserEntity> user;

	public UserVO(){

	}

	public UserVO(PageInfo pageInfo, List<UserEntity> user) {
		this.pageInfo=pageInfo;
		this.user=user;
	}
	
	public PageInfo getPageInfo() {
		return pageInfo;
	}
	public void setPageInfo(PageInfo pageInfo) {
		this.pageInfo = pageInfo;
	}
	public List<UserEntity> getUser() {
		return user;
	}
	public void setUser(List<UserEntity> user) {
		this.user = user;
	}
}
