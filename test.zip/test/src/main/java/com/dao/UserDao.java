package main.java.com.dao;

import main.java.com.entity.DeptEntity;
import main.java.com.entity.UserEntity;
import main.java.com.utils.ConnectionHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author lzn
 */
public class UserDao {
    /**
     * 查询用户所有记录
     */
    public List<UserEntity> query(int start,int num){
        List<UserEntity> userEntities=new ArrayList<>();
        Connection conn = ConnectionHelper.getConnection();
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        String sql = "select u.userId, u.userName, u.deptId,d.deptName from test_user u join test_dept d on u.deptId = d.deptId limit ?,?";
        try {
            pstmt=conn.prepareStatement(sql);
            pstmt.setObject(1,start);
            pstmt.setObject(2,num);
            rs=pstmt.executeQuery();
            while (rs.next()){
                UserEntity user=new UserEntity();
                user.setUserId(rs.getInt("userId"));
                user.setUserName(rs.getString("userName"));
                user.setDeptId(rs.getInt("deptId"));
                user.setDeptName(rs.getString("deptName"));
                userEntities.add(user);
            }
        } catch (SQLException e) {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return userEntities;
    }

    /**
     * 获取总记录数
     */
    public int getRecordCount(){
        List<UserEntity> userEntities=new ArrayList<>();
        Connection conn = ConnectionHelper.getConnection();
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        String sql = "select u.userId, u.userName, u.deptId,d.deptName from test_user u join test_dept d on u.deptId = d.deptId";
        int rows=0;
        try {
            pstmt=conn.prepareStatement(sql);
            rs=pstmt.executeQuery();
            while (rs.next()){
                UserEntity user=new UserEntity();
                user.setUserId(rs.getInt("userId"));
                user.setUserName(rs.getString("userName"));
                user.setDeptId(rs.getInt("deptId"));
                user.setDeptName(rs.getString("deptName"));
                userEntities.add(user);
            }
            rows=userEntities.size();
        } catch (SQLException e) {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return rows;
    }

    /**
     * 查询用户一条记录
     */
    public UserEntity queryById(Integer id){
        UserEntity user=null;
        Connection conn = ConnectionHelper.getConnection();
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        String sql = "select u.userId, u.userName, u.deptId,d.deptName from test_user u join test_dept d on u.deptId = d.deptId where userId=?";
        try {
            pstmt=conn.prepareStatement(sql);
            pstmt.setObject(1,id);
            rs=pstmt.executeQuery();
            if (rs.next()){
                user=new UserEntity();
                user.setUserId(rs.getInt("userId"));
                user.setUserName(rs.getString("userName"));
                user.setDeptId(rs.getInt("deptId"));
                user.setDeptName(rs.getString("deptName"));
            }

        } catch (SQLException e) {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return user;
    }

    /**
     * 添加用户
     * @param userName,deptId
     * @return
     */
    public int insert(String userName,Integer deptId){
        Connection conn = ConnectionHelper.getConnection();
        PreparedStatement pstmt=null;
        String sql = "insert into test_user(userName,deptId) values (?,?)";
        int num=0;
        try{
            pstmt=conn.prepareStatement(sql);
            pstmt.setString(1,userName);
            pstmt.setObject(2,deptId);
            num=pstmt.executeUpdate();
        } catch (SQLException e) {
            try {
                pstmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return num;
    }

    /**
     * 修改用户
     * @param userName,deptId,userId
     * @return
     */
    public int update(String userName,Integer deptId,Integer userId){
        Connection conn = ConnectionHelper.getConnection();
        PreparedStatement pstmt=null;
        String sql = "update test_user set userName=?,deptId=? where userId=?";
        int num=0;
        try{
            pstmt=conn.prepareStatement(sql);
            pstmt.setString(1,userName);
            pstmt.setObject(2,deptId);
            pstmt.setObject(3,userId);
            num=pstmt.executeUpdate();
        } catch (SQLException e) {
            try {
                pstmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return num;
    }

    /**
     * 删除部门
     * @param userId
     * @return
     */
    public int delete(Integer userId){
        Connection conn = ConnectionHelper.getConnection();
        PreparedStatement pstmt=null;
        String sql = "delete from test_user where userId=?";
        int num=0;
        try{
            pstmt=conn.prepareStatement(sql);
            pstmt.setObject(1,userId);
            num=pstmt.executeUpdate();
        } catch (SQLException e) {
            try {
                pstmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return num;
    }
}
