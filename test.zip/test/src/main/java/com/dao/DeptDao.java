package main.java.com.dao;

import main.java.com.entity.DeptEntity;
import main.java.com.utils.ConnectionHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author lzn
 */
public class DeptDao {
    /**
     * 部门查询所有记录
     */
    public List<DeptEntity> query(int start,int num){
        List<DeptEntity> deptEntities=new ArrayList<DeptEntity>();
        Connection conn = ConnectionHelper.getConnection();
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        String sql = "select deptId,deptName from test_dept limit ?,?";
        try {
            pstmt=conn.prepareStatement(sql);
            pstmt.setObject(1,start);
            pstmt.setObject(2,num);
            rs=pstmt.executeQuery();
            while (rs.next()){
                DeptEntity dept=new DeptEntity();
                dept.setDeptId(rs.getInt("deptId"));
                dept.setDeptName(rs.getString("deptName"));
                deptEntities.add(dept);
            }
        } catch (SQLException e) {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return deptEntities;
    }

    /**
     * 获取总记录数
     */
    public int getRecordCount(){
        List<DeptEntity> deptEntities=new ArrayList<DeptEntity>();
        Connection conn = ConnectionHelper.getConnection();
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        String sql = "select deptId,deptName from test_dept";
        int rows=0;
        try {
            pstmt=conn.prepareStatement(sql);
            rs=pstmt.executeQuery();
            while (rs.next()){
                DeptEntity dept=new DeptEntity();
                dept.setDeptId(rs.getInt("deptId"));
                dept.setDeptName(rs.getString("deptName"));
                deptEntities.add(dept);
            }
            rows=deptEntities.size();
        } catch (SQLException e) {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return rows;
    }

    /**
     * 部门查询一条记录
     */
    public DeptEntity queryById(Integer id){
        DeptEntity dept=null;
        Connection conn = ConnectionHelper.getConnection();
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        String sql = "select deptId,deptName from test_dept where deptId=?";
        try {
            pstmt=conn.prepareStatement(sql);
            pstmt.setObject(1,id);
            rs=pstmt.executeQuery();
            if (rs.next()){
                dept=new DeptEntity();
                dept.setDeptId(rs.getInt("deptId"));
                dept.setDeptName(rs.getString("deptName"));
            }

        } catch (SQLException e) {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return dept;
    }

    /**
     * 部门添加
     * @param deptName
     * @return
     */
    public int insert(String deptName){
        Connection conn = ConnectionHelper.getConnection();
        PreparedStatement pstmt=null;
        String sql = "insert into test_dept(deptName) values (?)";
        int num=0;
        try{
            pstmt=conn.prepareStatement(sql);
            pstmt.setString(1,deptName);
            num=pstmt.executeUpdate();
        } catch (SQLException e) {
            try {
                pstmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return num;
    }

    /**
     * 部门修改
     * @param deptName
     * @return
     */
    public int update(String deptName,Integer deptId){
        Connection conn = ConnectionHelper.getConnection();
        PreparedStatement pstmt=null;
        String sql = "update test_dept set deptName=? where deptId=?";
        int num=0;
        try{
            pstmt=conn.prepareStatement(sql);
            pstmt.setString(1,deptName);
            pstmt.setObject(2,deptId);
            num=pstmt.executeUpdate();
        } catch (SQLException e) {
            try {
                pstmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return num;
    }

    /**
     * 删除部门
     * @param deptId
     * @return
     */
    public int delete(Integer deptId){
        Connection conn = ConnectionHelper.getConnection();
        PreparedStatement pstmt=null;
        String sql = "delete from test_dept where deptId=?";
        int num=0;
        try{
            pstmt=conn.prepareStatement(sql);
            pstmt.setString(1,String.valueOf(deptId));
            num=pstmt.executeUpdate();
        } catch (SQLException e) {
            try {
                pstmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        return num;
    }

}
