package main.java.com.utils;

/**
 * @author lzn
 */
public class PageInfo {
    /**
     * 当前页(默认为首页)
     */
    private int pageNo = 1;
    /**
     *总记录数
     */
    private int recordCount;
    /**
     *每页显示的记录数
     */
    private int pageSize = 5;

    public PageInfo() {
    }

    public PageInfo(int pageNo, int recordCount) {
        this.pageNo = pageNo;
        this.recordCount = recordCount;
    }

    public PageInfo(int pageNo, int recordCount, int pageSize) {
        this.pageNo = pageNo;
        this.recordCount = recordCount;
        this.pageSize = pageSize;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getRecordCount() {
        return recordCount;
    }

    public int getPageSize() {
        return pageSize;
    }

    /**
     * 第一页
     */
    public int getFirst() {
        return 1;
    }

    /**
     * 上一页
     */
    public int getPrev() {
        return Math.max(pageNo-1, 1);
    }

    /**
     * 下一页
     */
    public int getNext() {
        return Math.min(pageNo+1, getPageCount());
    }

    /**
     * 最后一页
     */
    public int getLast() {
        return  getPageCount();
    }

    /**
     * 获取总页数
     */
    public int getPageCount(){
        return (int)Math.ceil(this.recordCount * 1.0 / this.pageSize);
    }

    public int getOffset(){
        return (this.pageNo-1) * this.pageSize;
    }

    /**
     * 获取当前页的开始值
     */
    public int getStart() {
    	return (this.pageNo-1) * this.pageSize  + 1;
    }

    /**
     * 获取当前页的结束值
     */
    public int getEnd() {
    	return this.pageNo * this.pageSize ;
    }
}