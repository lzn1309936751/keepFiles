$(function(){
	$(document).ajaxError(function(){
		alert("发生错误!发生错误!发生错误!");
	});
	
	//--------------查询---------------
	function getAll(){
		$.getJSON("/be/category/list",function(data){
			$.each(data,function(index,category){
				var $tr=$("<tr><td></td><td></td><td>" +
						"<a href='#' class='delete btn btn-danger'>删除</a>" +
						"<a href='#' class='edit btn btn-info'>编辑</a></td></tr>");
				$tr.find("td:first").text(category.category_id);
				$tr.find("td:eq(1)").text(category.category_name);
				$tr.find("td a:eq(0)").data("cid",category.category_id);
				$tr.find("td a:eq(1)").data("cid",category.category_id);
				$tr.appendTo("tbody");
			});
		});
	}
	
	getAll();
	
	//----------------删除----------------
	$("tbody").on("click",".delete",function(e){
		e.preventDefault();
		var $that=$(this);
		if(confirm("确定要删除吗？")){
			$.post("/be/category/delete",{cid:$(this).data("cid")},function(){
				console.log($that);
				$that.closest("tr").remove();
			});
		}
	});
	
	//-----------------添加---------------
	$("#content").on("click",".add",function(){
		$("#save").data("op","insert");
		$("#category_name").val("");
		$("#myModal").modal('show');
	});
	
	$("#save").click(function(){
		var op=$("#save").data("op");
		if(op!="insert"){
			return;
		}
		$("#myModal").modal('hide');
		var obj={cname:$("#category_name").val()};
		console.log(obj);
		$.post("/be/category/add",obj,function(){
			$("tbody").empty();
			getAll();
		});
	});
	
	
	
	//-----------------修改---------------
	$("tbody").on("click",".edit",function(){
		$("#save").data("op","update");
		$("#category_id").val($(this).closest("tr").find("td:eq(0)").text());
		$("#category_name").val($(this).closest("tr").find("td:eq(1)").text());
		$("#myModal").modal('show');
	});
	
	$("#save").click(function(){
		var op=$("#save").data("op");
		if(op!="update"){
			return;
		}
		$("#myModal").modal('hide');
		var obj={cid:$("#category_id").val(),cname:$("#category_name").val()};
		console.log(obj);
		
		$.post("/be/category/update",obj,function(){
			$("tbody").empty();
			getAll();
		});
	});
	
})
