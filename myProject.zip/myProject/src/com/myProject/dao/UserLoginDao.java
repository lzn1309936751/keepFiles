package com.myProject.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.myProject.entity.Product;
import com.myProject.entity.UserLogin;

public class UserLoginDao extends BaseDao{
	public boolean insert(Object...params) {
		String sql="insert into userLogin values(?,?,?)";
		return queryRunner.modify(sql, params)>0;
	}
	
	public boolean delete(Object...params) {
		String sql="delete from userLogin where user_uid=?";
		return queryRunner.modify(sql, params)>0;
	}
	
	public boolean update(Object...params) {
		String sql="update userLogin set user_uname=?,user_password=? where user_uid=?";
		return queryRunner.modify(sql, params)>0;
	}
	
	public List<UserLogin> queryAll(){
		String sql="select user_uid,user_uname,user_password,user_sex from userLogin";
		BeanListHandler<UserLogin> bhandler=new BeanListHandler<>(UserLogin.class);
		return queryRunner.Query(sql, bhandler);
	}
	
	public UserLogin queryById(Object...params){
		String sql="select user_uid,user_uname,user_password,user_sex from userLogin where user_uid=?";
		BeanHandler<UserLogin> bhandler=new BeanHandler<>(UserLogin.class);
		return queryRunner.Query(sql, bhandler,params);
	}
	
	public List<UserLogin> getPagedRecords(int start,int end){
		String sql="select * from (select ROW_NUMBER() over (order by user_uid) as rowNo,* from userLogin) u where rowNo between ? and ?";
		BeanListHandler<UserLogin> bhandler=new BeanListHandler<>(UserLogin.class);
		return queryRunner.Query(sql, bhandler,start,end);
	}
	
	public int RecordCount() {
		String sql="select count(*) from userLogin";
		ScalarHandler<Integer> shandler=new ScalarHandler<>();
		int rows=Integer.valueOf(queryRunner.Query(sql, shandler).toString());
		return rows;
	}
	
	public List<UserLogin> getProductsByCondition
	(Map<String,Object> condition,int offset,int count){
		List<Object> list=new ArrayList<Object>();
		
		String sql=getSqlByCondition("select * from (select ROW_NUMBER() over"
				+ " (order by user_uid) as rowNo,* from userLogin where 1=1",condition);
			   sql+= ") as p where rowNo between ? and ?";
		
		BeanListHandler<UserLogin> handler=new BeanListHandler<>(UserLogin.class);
		
		for(Object o:condition.values().toArray()) {
			list.add(o);
		}
		list.add(offset);
		list.add(count);
		List<UserLogin> users=queryRunner.Query(sql, handler, list.toArray());
		return users;
	}
	
	protected String getSqlByCondition(String initSql,Map<String,Object> condition) {
		StringBuilder builder=new StringBuilder(initSql);
		for(String fieldName:condition.keySet()) {
			builder.append(" and ");
			builder.append(fieldName);
			builder.append(" like ? ");
		}
		return builder.toString();
	}
	
	public int getProductsCountByCondition(Map<String,Object> condition) {
		String sql=getSqlByCondition("select count(*) from userLogin where 1=1",condition);
		ScalarHandler<Integer> handler=new ScalarHandler<>();
		int rows=Integer.valueOf(queryRunner.Query
				(sql, handler, condition.values().toArray().toString()));
		return rows;
	}
}
