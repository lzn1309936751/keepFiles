package com.myProject.dao;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.myProject.entity.Grade;

public class GradeDao extends BaseDao{
	public List<Grade> queryAll(){
		String sql="select grade_id,grade_name from grade";
		BeanListHandler<Grade> bhandler=new BeanListHandler<>(Grade.class);
		return queryRunner.Query(sql, bhandler);
	}
}
