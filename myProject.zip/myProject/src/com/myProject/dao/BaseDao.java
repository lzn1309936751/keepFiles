package com.myProject.dao;

import com.myProject.util.QueryRunnerWrapper;

public abstract class BaseDao {
	protected QueryRunnerWrapper queryRunner=new QueryRunnerWrapper();
}
