package com.myProject.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.myProject.entity.Product;
import com.myProject.entity.StoreInformation;

public class StoreInformationDao extends BaseDao{
	public boolean insert(Object...params) {
		String sql="insert into storeInformation values(?,?,?,?,?)";
		return queryRunner.modify(sql, params)>0;
	}
	
	public boolean delete(Object...params) {
		String sql="delete from storeInformation where store_id=?";
		return queryRunner.modify(sql, params)>0;
	}
	
	public boolean update(Object...params) {
		String sql="update storeInformation set store_name=?,store_description=?,store_service=?,store_logistics=?,grade_id=? where store_id=?";
		return queryRunner.modify(sql, params)>0;
	}
	
	public List<StoreInformation> queryAll(){
		String sql="select s.store_id,s.store_name,s.store_description,s.store_service,"
				+ "s.store_logistics,g.grade_name from storeInformation s join grade g on s.grade_id=g.grade_id";
		BeanListHandler<StoreInformation> bhandler=new BeanListHandler<>(StoreInformation.class);
		return queryRunner.Query(sql, bhandler);
	}
	
	public StoreInformation queryById(Object...params){
		String sql="select s.store_id,s.store_name,s.store_description,s.store_service,s.store_logistics,g.grade_name from storeInformation s"
				+ " join grade g on s.grade_id=g.grade_id where store_id=?";
		BeanHandler<StoreInformation> bhandler=new BeanHandler<>(StoreInformation.class);
		return queryRunner.Query(sql, bhandler,params);
	}
	
	public List<StoreInformation> getPagedRecords(int start,int end){
		String sql="select * from (select ROW_NUMBER() over (order by store_id) as rowNo,* from storeInformation) s join grade g on s.grade_id=g.grade_id where rowNo between ? and ?";
		BeanListHandler<StoreInformation> bhandler=new BeanListHandler<>(StoreInformation.class);
		return queryRunner.Query(sql, bhandler,start,end);
	}
	
	public int RecordCount() {
		String sql="select count(*) from storeInformation";
		ScalarHandler<Integer> shandler=new ScalarHandler<>();
		int rows=Integer.valueOf(queryRunner.Query(sql, shandler).toString());
		return rows;
	}
	
	public List<StoreInformation> getProductsByCondition
	(Map<String,Object> condition,int offset,int count){
		List<Object> list=new ArrayList<Object>();
		
		String sql=getSqlByCondition("select * from (select ROW_NUMBER() over"
				+ " (order by store_id) as rowNo,* from storeInformation where 1=1",condition);
			   sql+= ") as p where rowNo between ? and ?";
		
		BeanListHandler<StoreInformation> handler=new BeanListHandler<>(StoreInformation.class);
		
		for(Object o:condition.values().toArray()) {
			list.add(o);
		}
		list.add(offset);
		list.add(count);
		List<StoreInformation> store=queryRunner.Query(sql, handler, list.toArray());
		return store;
	}
	
	protected String getSqlByCondition(String initSql,Map<String,Object> condition) {
		StringBuilder builder=new StringBuilder(initSql);
		for(String fieldName:condition.keySet()) {
			builder.append(" and ");
			builder.append(fieldName);
			builder.append(" like ? ");
		}
		return builder.toString();
	}
	
	public int getProductsCountByCondition(Map<String,Object> condition) {
		String sql=getSqlByCondition("select count(*) from storeInformation where 1=1",condition);
		ScalarHandler<Integer> handler=new ScalarHandler<>();
		int rows=Integer.valueOf(queryRunner.Query
				(sql, handler, condition.values().toArray().toString()));
		return rows;
	}
}
