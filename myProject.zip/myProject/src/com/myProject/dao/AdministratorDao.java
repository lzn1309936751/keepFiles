package com.myProject.dao;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.myProject.entity.Administrator;

public class AdministratorDao extends BaseDao{
	public boolean insert(Object...params) {
		String sql="insert into administrator values(?,?,?,?,?,?)";
		return queryRunner.modify(sql, params)>0;
	}
	
	public boolean delete(Object...params) {
		String sql="delete from administrator where admin_id=?";
		return queryRunner.modify(sql, params)>0;
	}
	
	public boolean update(Object...params) {
		String sql="update administrator set admin_name=?,admin_password=?,admin_sex=?,admin_manager=?,admin_salary=?,admin_phone=? where admin_id=?";
		return queryRunner.modify(sql, params)>0;
	}
	
	public List<Administrator> queryAll(){
		String sql="select admin_id,admin_name,admin_password,admin_sex,admin_manager,admin_salary,admin_phone from administrator";
		BeanListHandler<Administrator> bhandler=new BeanListHandler<>(Administrator.class);
		return queryRunner.Query(sql, bhandler);
	}
	
	public Administrator queryById(Object...params){
		String sql="select admin_id,admin_name,admin_password,admin_sex,admin_manager,admin_salary,admin_phone from administrator where admin_id=?";
		BeanHandler<Administrator> bhandler=new BeanHandler<>(Administrator.class);
		return queryRunner.Query(sql, bhandler,params);
	}
}
