""package com.myProject.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.myProject.entity.Category;
import com.myProject.entity.Product;

public class ProductDao extends BaseDao{
	public boolean insert(Product product) {
		String sql="insert into product(product_name,product_desc,product_unitprice,"
				+ "product_image,category_id,store_id) values(?,?,?,?,?,?)";
		int affectedRows=queryRunner.modify(sql,product.getProduct_name(),
				product.getProduct_desc(),
				product.getProduct_unitprice(),
				product.getProduct_image(),
				product.getCategory_id(),
				product.getStore_id());
		return affectedRows>0?true:false;
	}
	
	public boolean delete(Integer id) {
		String sql="delete from product where product_id=?";
		int affectedRows=queryRunner.modify(sql, id);
		 return affectedRows>0?true:false;
	}
	
	public boolean update(Product product) {
		String sql="update product set product_name=?,product_desc=?,product_unitprice=?,"
				+ "product_image=?,category_id=?,store_id=? where product_id=?";
		int affectedRows=queryRunner.modify(sql,product.getProduct_name(),
				product.getProduct_desc(),
				product.getProduct_unitprice(),
				product.getProduct_image(),
				product.getCategory_id(),
				product.getStore_id(),
				product.getProduct_id());
		return affectedRows>0?true:false;
	}
	
	public List<Product> queryAll() {
		String sql="select p.product_id,p.product_name,p.product_desc,p.product_unitprice,p.product_image,c.category_name,"
		+ "s.store_name from product p join category c on p.category_id=c.category_id join storeInformation s on p.store_id=s.store_id";
		BeanListHandler<Product> bhandler=new BeanListHandler<>(Product.class);
		return queryRunner.Query(sql,bhandler);
	}
	
	public Product queryByProductId(Object...params){
		String sql="select category_id,product_unitprice,* from product where product_id=?";
		BeanHandler<Product> bhandler=new BeanHandler<>(Product.class);
		return queryRunner.Query(sql, bhandler,params);
	}
	
	public Product queryById(Integer id) {
		String sql="select p.product_id,p.product_name,p.product_desc,p.product_unitprice,p.product_image,c.category_id,c.category_name,s.store_name"
		+ " from product p join category c on p.category_id=c.category_id join storeInformation s on p.store_id=s.store_id where product_id=?";
		BeanHandler<Product> bhandler=new BeanHandler<>(Product.class);
		return queryRunner.Query(sql,bhandler,id);
	}
	
	public List<Product> getPagedRecords(int start,int end){
		String sql="select * from (select ROW_NUMBER() over (order by product_id) as rowNo,* from product) p "
				+ "join category c on p.category_id=c.category_id join storeInformation s on p.store_id=s.store_id where rowNo between ? and ?";
		BeanListHandler<Product> bhandler=new BeanListHandler<>(Product.class);
		return queryRunner.Query(sql, bhandler,start,end);
	}
	
	public int RecordCount() {
		String sql="select count(*) from product";
		ScalarHandler<Integer> shandler=new ScalarHandler<>();
		int rows=Integer.valueOf(queryRunner.Query(sql, shandler).toString());
		return rows;
	}
	
	public List<Product> getProductsByCondition
	(Map<String,Object> condition,int offset,int count){
		List<Object> list=new ArrayList<Object>();
		
		String sql=getSqlByCondition("select * from (select ROW_NUMBER() over"
				+ " (order by product_id) as rowNo,* from product where 1=1",condition);
			   sql+= ") as p where rowNo between ? and ?";
		
		BeanListHandler<Product> handler=new BeanListHandler<>(Product.class);
		
		for(Object o:condition.values().toArray()) {
			list.add(o);
		}
		list.add(offset);
		list.add(count);
		List<Product> products=queryRunner.Query(sql, handler, list.toArray());
		return products;
	}
	
	protected String getSqlByCondition(String initSql,Map<String,Object> condition) {
		StringBuilder builder=new StringBuilder(initSql);
		for(String fieldName:condition.keySet()) {
			builder.append(" and ");
			builder.append(fieldName);
			builder.append(" like ? ");
		}
		return builder.toString();
	}
	
	public int getProductsCountByCondition(Map<String,Object> condition) {
		String sql=getSqlByCondition("select count(*) from product where 1=1",condition);
		ScalarHandler<Integer> handler=new ScalarHandler<>();
		int rows=Integer.valueOf(queryRunner.Query
				(sql, handler, condition.values().toArray()));
		return rows;
	}
	
}
