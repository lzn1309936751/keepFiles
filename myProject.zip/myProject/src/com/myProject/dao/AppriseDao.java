package com.myProject.dao;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.myProject.entity.Apprise;
import com.myProject.entity.Cart;

public class AppriseDao extends BaseDao{
	public boolean insert(Apprise apprise) {
		String sql="insert into apprise values(?,?,?,?)";
		return queryRunner.modify(sql, apprise.getApprise_content(),
				apprise.getApprise_time(),
				apprise.getProduct_id(),
				apprise.getUser_uid())>0;
	}
	
	public List<Apprise> queryAll(Object...params){
		String sql="select apprise_id,apprise_content,apprise_time,product_id from apprise where user_uid=?";
		BeanListHandler<Apprise> bhandler=new BeanListHandler<>(Apprise.class);
		return queryRunner.Query(sql, bhandler);
	}
	
	public Apprise queryById(int oid){
		String sql="select apprise_id,apprise_content,apprise_time,product_id from apprise where product_id=?";
		BeanHandler<Apprise> bhandler=new BeanHandler<>(Apprise.class);
		return queryRunner.Query(sql, bhandler,oid);
	}
	
	public List<Apprise> queryBySameId(int oid){
		String sql="select a.apprise_id,a.apprise_content,a.apprise_time,a.product_id,u.user_uname from apprise a join userLogin u on a.user_uid=u.user_uid where product_id=?";
		BeanListHandler<Apprise> bhandler=new BeanListHandler<>(Apprise.class);
		return queryRunner.Query(sql, bhandler,oid);
	}
}
