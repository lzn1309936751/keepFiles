package com.myProject.dao;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.myProject.entity.Cart;
import com.myProject.entity.OrderInformation;

public class OrderInformationDao extends BaseDao{
	public boolean insert(OrderInformation order) {
		String sql="insert into orderInformation values(?,?,?,?)";
		return queryRunner.modify(sql, order.getOrder_time(),
				order.getCart_id(),
				order.getProduct_id(),
				order.getUser_uid())>0;
	}
	
	public boolean delete(Object...params) {
		String sql="delete from orderInformation where order_id=?";
		return queryRunner.modify(sql, params)>0;
	}
	
	public List<OrderInformation> queryAll(Object...params){
		String sql="select o.order_id,p.product_image,p.product_id,p.product_name,p.product_unitprice,p.product_desc,c.cart_num,c.cart_subTotal,o.order_time"
				+ " from orderInformation o join product p on o.product_id=p.product_id join cart c on c.cart_id=o.cart_id where o.user_uid=?";
		BeanListHandler<OrderInformation> bhandler=new BeanListHandler<>(OrderInformation.class);
		return queryRunner.Query(sql, bhandler,params);
	}
	
	public OrderInformation queryById(int id){
		String sql="select o.order_id,p.product_image,p.product_id,p.product_name,p.product_unitprice,p.product_desc,c.cart_num,c.cart_subTotal,o.order_time"
				+ " from orderInformation o join product p on o.product_id=p.product_id join cart c on c.cart_id=o.cart_id where o.order_id=?";
		BeanHandler<OrderInformation> bhandler=new BeanHandler<>(OrderInformation.class);
		return queryRunner.Query(sql, bhandler,id);
	}
	
	//查询订单表内的商品数量，作为销售的成交数量
	public int RecordSaleCount() {
		String sql="select count(*) from orderInformation where order_time between '2019-08-5' and '2019-08-9' ";
		ScalarHandler<Integer> shandler=new ScalarHandler<>();
		int rows=Integer.valueOf(queryRunner.Query(sql, shandler).toString());
		return rows;
	}
	
	//查询订单表内的商品数量，作为销售的成交数量
	public List<OrderInformation> RecordSaleMoneyCount(){
		String sql="select c.cart_subTotal,o.order_time from orderInformation o join product p on o.product_id=p.product_id join"
				+ " cart c on c.cart_id=o.cart_id where where o.order_time between '2019-08-5' and '2019-08-9' ";
		BeanListHandler<OrderInformation> bhandler=new BeanListHandler<>(OrderInformation.class);
		return queryRunner.Query(sql, bhandler);
	}
	
}
