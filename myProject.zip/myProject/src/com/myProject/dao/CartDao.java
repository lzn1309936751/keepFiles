package com.myProject.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.myProject.entity.Cart;

public class CartDao extends BaseDao{
	private Map<Integer,Cart> carts=new HashMap<>();
	public boolean insert(Cart cart) {
		String sql="insert into cart values(?,?,?,?,?,?)";
		return queryRunner.modify(sql, cart.getCart_time(),
				cart.getCart_num(),
				cart.getCart_subTotal(),
				cart.getCategory_id(),
				cart.getProduct_id(),
				cart.getUser_uid())>0;
	}
	
	public boolean delete(Object...params) {
		String sql="delete from cart where cart_id=?";
		return queryRunner.modify(sql, params)>0;
	}
	
	public boolean update(Object...params) {
		String sql="update cart set cart_num=?,cart_subTotal=? where product_id=? and user_uid=?";
		return queryRunner.modify(sql, params)>0;
	}
	
	public List<Cart> queryAll(Object...params){
		String sql="select c.cart_id,p.product_id,p.product_image,p.product_name,p.product_unitprice,c.cart_time,c.cart_num,c.cart_subTotal"
				+ " from cart c join product p on c.product_id=p.product_id where c.user_uid=?";
		BeanListHandler<Cart> bhandler=new BeanListHandler<>(Cart.class);
		return queryRunner.Query(sql, bhandler,params);
	}
	
	public List<Cart> ById(int pid){
		String sql="select c.cart_id,p.product_image,p.product_name,p.product_unitprice,c.cart_time,c.cart_num,c.cart_subTotal,u.user_uid"
				+ " from cart c join product p on c.product_id=p.product_id join userLogin u on c.user_uid=u.user_uid  where p.product_id = ? ";
		BeanListHandler<Cart> bhandler=new BeanListHandler<>(Cart.class);
		return queryRunner.Query(sql, bhandler,pid);
	}
	
	public Cart getByNum(int pid,int uid){
		String sql="select cart_num from cart where product_id = ? and user_uid=?";
		BeanHandler<Cart> bhandler=new BeanHandler<>(Cart.class);
		return queryRunner.Query(sql, bhandler,pid,uid);
	}
	//统计购物车内的商品条数
	public int RecordTotalCount(int uid) {
		String sql="select count(*) from cart where user_uid=?";
		ScalarHandler<Integer> shandler=new ScalarHandler<>();
		int rows=Integer.valueOf(queryRunner.Query(sql, shandler,uid).toString());
		return rows;
	}
	
	public Cart RecordCategoryCounts() {
		String sql="select count(category_id) from cart";
		BeanHandler<Cart> bhandler=new BeanHandler<>(Cart.class);
		return queryRunner.Query(sql, bhandler);
	}
}
