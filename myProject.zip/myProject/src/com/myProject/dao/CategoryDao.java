package com.myProject.dao;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.myProject.entity.Category;

public class CategoryDao extends BaseDao{
	public boolean insert(Object...params) {
		String sql="insert into category values(?)";
		return queryRunner.modify(sql, params)>0;
	}
	
	public boolean delete(Object...params) {
		String sql="delete from category where category_id=?";
		return queryRunner.modify(sql, params)>0;
	}
	
	public boolean update(Object...params) {
		String sql="update category set category_name=? where category_id=?";
		return queryRunner.modify(sql, params)>0;
	}
	
	public List<Category> queryAll(){
		String sql="select category_id,category_name from category";
		BeanListHandler<Category> bhandler=new BeanListHandler<>(Category.class);
		return queryRunner.Query(sql, bhandler);
	}
	
	public Category queryById(Object...params){
		String sql="select category_id,category_name from category where category_id=?";
		BeanHandler<Category> bhandler=new BeanHandler<>(Category.class);
		return queryRunner.Query(sql, bhandler,params);
	}
}
