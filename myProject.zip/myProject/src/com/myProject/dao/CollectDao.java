package com.myProject.dao;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.myProject.entity.Cart;
import com.myProject.entity.Collect;

public class CollectDao extends BaseDao{
	public boolean insert(Collect collect) {
		String sql="insert into collect values(?,?,?)";
		return queryRunner.modify(sql,
				collect.getCollect_time(),
				collect.getProduct_id(),
				collect.getUser_uid())>0;
	}
	
	public boolean delete(Object...params) {
		String sql="delete from collect where collect_id=?";
		return queryRunner.modify(sql, params)>0;
	}
	
	public List<Collect> queryAll(Object...params){
		String sql="select c.collect_id,p.product_image,p.product_name,p.product_unitprice,p.product_desc,c.collect_time "
				+ "from collect c join product p on c.product_id=p.product_id where c.user_uid=?";
		BeanListHandler<Collect> bhandler=new BeanListHandler<>(Collect.class);
		return queryRunner.Query(sql, bhandler,params);
	}
}
