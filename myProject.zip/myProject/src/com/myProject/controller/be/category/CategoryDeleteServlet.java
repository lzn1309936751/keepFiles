package com.myProject.controller.be.category;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.service.CategoryService;
import com.myProject.util.JsonUtils;


@WebServlet("/be/category/delete")
public class CategoryDeleteServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		CategoryService categoryService=new CategoryService();
		String cid=req.getParameter("cid");
		boolean b=false;
		b=categoryService.delete(cid);
		
		JsonUtils.write(resp.getOutputStream(), b);
	}
}
