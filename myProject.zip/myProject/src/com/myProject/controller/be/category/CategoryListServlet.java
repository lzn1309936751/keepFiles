package com.myProject.controller.be.category;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Category;
import com.myProject.service.CategoryService;
import com.myProject.util.JsonUtils;

@WebServlet("/be/category/list")
public class CategoryListServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest rep, HttpServletResponse resp) throws ServletException, IOException {
		
		CategoryService categoryService=new CategoryService();
		List<Category> cateList=categoryService.queryAll();
		JsonUtils.write(resp.getOutputStream(), cateList);
	}
}
