package com.myProject.controller.be.category;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.service.CategoryService;
import com.myProject.util.JsonUtils;

@WebServlet("/be/category/add")
public class CategoryAddServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		CategoryService categoryService=new CategoryService();
		String cname=req.getParameter("cname");
		boolean b=categoryService.insert(cname);
		
		JsonUtils.write(resp.getOutputStream(), b);
	}
}
