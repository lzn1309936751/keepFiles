package com.myProject.controller.be.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Administrator;
import com.myProject.service.AdministratorService;

@WebServlet("/be/admin/index")
public class AdminIndexServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		AdministratorService adminService=new AdministratorService();
		List<Administrator> adminList=adminService.queryAll();
		req.setAttribute("adminList",adminList );
		req.getRequestDispatcher("/WEB-INF/views/be/admin/list.jsp").forward(req, resp);
	}
}
