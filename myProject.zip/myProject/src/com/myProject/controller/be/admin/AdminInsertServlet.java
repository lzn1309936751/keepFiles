package com.myProject.controller.be.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Administrator;
import com.myProject.service.AdministratorService;
import com.myProject.util.JsonUtils;

@WebServlet("/be/admin/insert")
public class AdminInsertServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name=req.getParameter("name");System.out.println(name);
		String pwd=req.getParameter("pwd");
		String sex=req.getParameter("sex");
		String manager=req.getParameter("manager");
		float salary=Float.valueOf(req.getParameter("salary"));
		String phone=req.getParameter("phone");
		
		
		AdministratorService adminService=new AdministratorService();
		boolean b=adminService.insert(name,pwd,sex,manager,salary,phone);
		req.getRequestDispatcher("/be/admin/index").forward(req, resp);
		
		JsonUtils.write(resp.getOutputStream(), b);
	}
}
