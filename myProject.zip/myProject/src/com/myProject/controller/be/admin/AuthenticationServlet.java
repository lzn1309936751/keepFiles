package com.myProject.controller.be.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myProject.entity.Administrator;
import com.myProject.service.AdministratorService;

@WebServlet("/be/admin/authen")
public class AuthenticationServlet extends HttpServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String adminName=req.getParameter("txtAdmin");
		String adminPwd=req.getParameter("txtPwd");
		
		AdministratorService adminService=new AdministratorService();
		List<Administrator> adminList=adminService.queryAll();
		HttpSession session=req.getSession();
		for(Administrator a:adminList) {
			if(adminName.equals(a.getAdmin_name())&&adminPwd.equals(a.getAdmin_password())) {
				session.setAttribute("adminName",adminName );
				resp.sendRedirect("/be/Beindex");
				return ;
			}
		}
		resp.sendRedirect("/be/dologin");
		
	}
}
