package com.myProject.controller.be.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Administrator;
import com.myProject.service.AdministratorService;

@WebServlet("/be/admin/edit")
public class AdminEditServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer aid=Integer.valueOf(req.getParameter("aid"));
		AdministratorService adminService=new AdministratorService();
		Administrator adminList=adminService.queryById(aid);
		req.setAttribute("adminList", adminList);
		
		req.getRequestDispatcher("/WEB-INF/views/be/admin/edit.jsp").forward(req, resp);
	}
}
