package com.myProject.controller.be.store;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.service.StoreInformationService;

@WebServlet("/be/store/update")
public class StoreUpdateServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer sid=Integer.valueOf(req.getParameter("sid"));
		String sname=req.getParameter("sname");
		Float description=Float.valueOf(req.getParameter("description"));
		Float service=Float.valueOf(req.getParameter("service"));
		Float logistics=Float.valueOf(req.getParameter("logistics"));
		String grade=req.getParameter("grade");
		
		StoreInformationService storeService=new StoreInformationService();
		boolean b=storeService.update(sname,description,service,logistics,grade,sid);
		req.getRequestDispatcher("/be/store/index").forward(req, resp);
	}
}
