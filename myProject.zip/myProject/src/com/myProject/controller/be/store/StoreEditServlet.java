package com.myProject.controller.be.store;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Grade;
import com.myProject.entity.StoreInformation;
import com.myProject.service.GradeService;
import com.myProject.service.StoreInformationService;

@WebServlet("/be/store/edit")
public class StoreEditServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer sid=Integer.valueOf(req.getParameter("sid"));
		StoreInformationService storeService=new StoreInformationService();
		StoreInformation slist=storeService.queryById(sid);
		req.setAttribute("slist", slist);
		
		GradeService gradeService=new GradeService();
		List<Grade> gradeList=gradeService.queryAll();
		req.setAttribute("gradeList", gradeList);
		req.getRequestDispatcher("/WEB-INF/views/be/store/edit.jsp").forward(req, resp);
	}
}
