package com.myProject.controller.be.store;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Grade;
import com.myProject.entity.Product;
import com.myProject.entity.StoreInformation;
import com.myProject.page.PageInfo;
import com.myProject.service.GradeService;
import com.myProject.service.ProductService;
import com.myProject.service.StoreInformationService;
import com.myProject.vo.ProductVO;
import com.myProject.vo.StoreInformationVO;

@WebServlet("/be/store/index")
public class StoreIndexServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		StoreInformationService storeServic=new StoreInformationService();
		int recordCount=storeServic.RecordCount();
		PageInfo pageInfo=new PageInfo(getParamInteger(req, "pageno", 1),recordCount,PAGE_SIZE);
		List<StoreInformation> storeList=storeServic.getPagedRecords(pageInfo.getStart(),pageInfo.getEnd());
		GradeService servic=new GradeService();
		List<Grade> grades=servic.queryAll();
		StoreInformationVO storeVO=new StoreInformationVO(pageInfo,storeList,grades);
		req.setAttribute("svo", storeVO);
		req.getRequestDispatcher("/WEB-INF/views/be/store/list.jsp").forward(req, resp);
	}
}
