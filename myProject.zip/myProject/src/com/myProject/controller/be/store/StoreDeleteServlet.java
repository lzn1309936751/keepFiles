package com.myProject.controller.be.store;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.service.StoreInformationService;

@WebServlet("/be/store/delete")
public class StoreDeleteServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer sid=Integer.valueOf(req.getParameter("sid"));
		StoreInformationService storeServic=new StoreInformationService();
		Boolean b=storeServic.delete(sid);
		req.getRequestDispatcher("/be/store/index").forward(req, resp);
	}
}
