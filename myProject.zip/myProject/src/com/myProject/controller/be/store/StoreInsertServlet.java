package com.myProject.controller.be.store;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.service.StoreInformationService;

@WebServlet("/be/store/insert")
public class StoreInsertServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String sname=req.getParameter("sname");
		String grade=req.getParameter("grade");
		Float description=Float.valueOf(req.getParameter("description"));
		Float service=Float.valueOf(req.getParameter("service"));
		Float logistics=Float.valueOf(req.getParameter("logistics"));
		
		StoreInformationService storeService=new StoreInformationService();
		boolean b=storeService.insert(sname,description,service,logistics,grade);
		req.getRequestDispatcher("/be/store/index").forward(req, resp);
	}
}
