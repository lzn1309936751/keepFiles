package com.myProject.controller.be.product;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Product;
import com.myProject.service.ProductService;

@MultipartConfig
@WebServlet("/be/product/update")
public class ProductUpdateServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Part part=req.getPart("pimage");
		String filename=generateFileName(part);
		
		if(filename.isEmpty()) {
			filename=req.getParameter("oldimage");
		}
		Product product=getProduct(req,filename);
		try {
			String realPath=req.getServletContext().getRealPath(filename);
			writeFile(realPath,part);
			updateProduct(product);
			resp.sendRedirect("/be/product/index");
		}catch(RuntimeException re) {
			re.printStackTrace();
			
			req.setAttribute("product", product);
			req.getRequestDispatcher("/be/product/edit").forward(req, resp);
		}
	}

	private void updateProduct(Product product) throws ServletException,IOException{
		ProductService proService=new ProductService();
		proService.update(product);
	}

	private void writeFile(String filename, Part part) throws IOException{
		if(part.getSize()<=0) {
			return;
		}
		part.write(filename);
	}

	private Product getProduct(HttpServletRequest req, String filename) {
		Integer pid=Integer.valueOf(req.getParameter("pid"));
		String pname=req.getParameter("pname");
		String pdesc=req.getParameter("pdesc");
		BigDecimal unitPrice=new BigDecimal(req.getParameter("unitprice"));
		Integer cid=Integer.valueOf(req.getParameter("cid"));
		Integer sid=Integer.valueOf(req.getParameter("sid"));
		return new Product(pname,pdesc,unitPrice,filename,cid,sid,pid);
	}

	private String generateFileName(Part part) {
		if(part.getSize()==0) {
			return "";
		}
		String submittedFileName=part.getSubmittedFileName();
		String fileExt=submittedFileName.substring(submittedFileName.lastIndexOf("."));
		return "/image/"+UUID.randomUUID()+fileExt;
	}
}
