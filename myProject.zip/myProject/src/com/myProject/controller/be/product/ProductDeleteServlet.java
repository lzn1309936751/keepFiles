package com.myProject.controller.be.product;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JButton;

import com.myProject.controller.BaseServlet;
import com.myProject.service.ProductService;
import com.myProject.util.JsonUtils;

@WebServlet("/be/product/delete")
public class ProductDeleteServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer pid=Integer.valueOf(req.getParameter("pid"));
		ProductService service=new ProductService();
		boolean b=service.delete(pid);
		resp.sendRedirect("/be/product/index");
	}
}
