package com.myProject.controller.be.product;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Category;
import com.myProject.entity.Product;
import com.myProject.entity.StoreInformation;
import com.myProject.service.CategoryService;
import com.myProject.service.StoreInformationService;

@WebServlet("/be/product/add")
public class ProductAddServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		CategoryService service=new CategoryService();
		StoreInformationService storeService=new StoreInformationService();
		//设置一个空的产品对象
		req.setAttribute("product",new Product());
		List<Category> categoryList=service.queryAll();
		req.setAttribute("categoryList", categoryList);
		List<StoreInformation> storeList=storeService.queryAll();
		req.setAttribute("storeList", storeList);
		req.getRequestDispatcher("/WEB-INF/views/be/product/add.jsp").forward(req, resp);
	}
}
