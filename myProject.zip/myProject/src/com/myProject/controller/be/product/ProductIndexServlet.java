package com.myProject.controller.be.product;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Product;
import com.myProject.page.PageInfo;
import com.myProject.service.ProductService;
import com.myProject.vo.ProductVO;

//商品信息管理页面
@WebServlet("/be/product/index")
public class ProductIndexServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ProductService service=new ProductService();
		int recordCount=service.RecordCount();
		PageInfo pageInfo=new PageInfo(getParamInteger(req, "pageno", 1),recordCount,PAGE_SIZE);
		List<Product> proList=service.getPagedRecords(pageInfo.getStart(),pageInfo.getEnd());
		ProductVO productVO=new ProductVO(pageInfo,proList);
		req.setAttribute("pvo", productVO);
		req.getRequestDispatcher("/WEB-INF/views/be/product/list.jsp").forward(req, resp);
	}
}
