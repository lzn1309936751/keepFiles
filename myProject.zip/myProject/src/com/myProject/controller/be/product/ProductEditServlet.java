package com.myProject.controller.be.product;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Category;
import com.myProject.entity.Product;
import com.myProject.entity.StoreInformation;
import com.myProject.service.CategoryService;
import com.myProject.service.ProductService;
import com.myProject.service.StoreInformationService;

@WebServlet("/be/product/edit")
public class ProductEditServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer pid=Integer.valueOf(req.getParameter("pid"));
		ProductService proService=new ProductService();
		CategoryService cateService=new CategoryService();
		StoreInformationService storeService=new StoreInformationService();
		
		Product product=proService.queryById(pid);
		req.setAttribute("product", product);
		
		List<Category> cateList=cateService.queryAll();
		req.setAttribute("cateList", cateList);
		
		List<StoreInformation> storeList=storeService.queryAll();
		req.setAttribute("storeList", storeList);
		
		req.getRequestDispatcher("/WEB-INF/views/be/product/edit.jsp").forward(req, resp);
	}
}
