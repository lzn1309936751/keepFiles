package com.myProject.controller.be.product;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Category;
import com.myProject.entity.Product;
import com.myProject.service.CategoryService;
import com.myProject.service.ProductService;

@MultipartConfig
@WebServlet("/be/product/insert")
public class ProductInsertServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Part part=req.getPart("pimage");
		String filename=generateFileName(part);
		
		Product product=null;
		try {
			product=getProduct(req,"/images/"+filename);
			String realPath="G:\\java\\workspace\\myProject\\WebContent\\photos\\"+filename;
			writeFile(realPath,part);
			insertProduct(product);
			
			resp.sendRedirect("/be/product/index");
		}catch(RuntimeException re) {
			re.printStackTrace();
			
			req.setAttribute("product", product);
			CategoryService cateService=new CategoryService();
			List<Category> cateList=cateService.queryAll();
			req.setAttribute("cateList",cateList);
			req.setAttribute("msg", "添加商品信息出错了！！！");
			req.getRequestDispatcher("/WEB-INF/views/be/product/add.jsp").forward(req, resp);
		}
	}

	private void insertProduct(Product product) throws ServletException,IOException{
		ProductService proService=new ProductService();
		proService.insert(product);
	}

	private void writeFile(String filename, Part part) throws IOException{
		if(part.getSize()<=0) {
			return;
		}
		part.write(filename);
	}

	private Product getProduct(HttpServletRequest req, String filename) {
		String pname=req.getParameter("pname");
		String pdesc=req.getParameter("pdesc");
		String unitPriceString=req.getParameter("unitprice");
		BigDecimal unitPrice=BigDecimal.valueOf(0);
		if(unitPriceString!=null&&unitPriceString.length()>0) {
			unitPrice=new BigDecimal(unitPriceString);
		}
		Integer cid=Integer.valueOf(req.getParameter("cid"));
		Integer sid=Integer.valueOf(req.getParameter("sid"));
		return new Product(pname,pdesc,unitPrice,filename,cid,sid);
	}

	private String generateFileName(Part part) {
		if(part.getSize()==0) {
			return "";
		}
		String submittedFileName=part.getSubmittedFileName();
		String fileExt=submittedFileName.substring(submittedFileName.lastIndexOf("."));
		return UUID.randomUUID()+fileExt;
	}
}
