package com.myProject.controller.be.salestate;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.OrderInformation;
import com.myProject.service.OrderInformationService;

@WebServlet("/be/salestate/view")
public class ViewSaleStateServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		OrderInformationService orderService=new OrderInformationService();
		int salenum=orderService.RecordSaleCount();
		req.setAttribute("salenum", salenum);
		double totalMoney=0;
		List<OrderInformation> orderList=orderService.RecordSaleMoneyCount();
		for(OrderInformation o:orderList) {
			totalMoney+=o.getCart_subTotal();
		}
		req.setAttribute("totalMoney", totalMoney);
		req.getRequestDispatcher("/WEB-INF/views/be/salestate/salestate.jsp").forward(req, resp);
		
	}
}
