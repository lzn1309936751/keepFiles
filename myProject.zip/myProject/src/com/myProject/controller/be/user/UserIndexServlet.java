package com.myProject.controller.be.user;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.UserLogin;
import com.myProject.page.PageInfo;
import com.myProject.service.UserLoginService;
import com.myProject.vo.UserVO;

@WebServlet("/be/user/index")
public class UserIndexServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		UserLoginService userService=new UserLoginService();
		int recordCount=userService.RecordCount();
		PageInfo pageInfo=new PageInfo(getParamInteger(req, "pageno", 1),recordCount,PAGE_SIZE);
		List<UserLogin> userList=userService.getPagedRecords(pageInfo.getStart(), pageInfo.getEnd());
		UserVO userVO=new UserVO(pageInfo,userList);
		req.setAttribute("uvo", userVO);
		
		req.getRequestDispatcher("/WEB-INF/views/be/user/list.jsp").forward(req, resp);
	}
}
