package com.myProject.controller.fe.cart;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Cart;
import com.myProject.entity.UserLogin;
import com.myProject.service.CartService;

@WebServlet("/fe/viewcart")
public class ViewCartServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session=req.getSession();
		UserLogin user=(UserLogin) session.getAttribute("userlogin");
		CartService service=new CartService();
		List<Cart> cartList=service.queryAll(user.getUser_uid());
		req.setAttribute("cartList", cartList);
		double total=0;
		for(Cart c:cartList) {
			double s=c.getCart_subTotal();
			total=total+s;
		}
		req.setAttribute("total", total);
		
		req.getRequestDispatcher("/WEB-INF/views/fe/viewcart.jsp").forward(req, resp);
	}
}
