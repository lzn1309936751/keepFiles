package com.myProject.controller.fe.cart;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myProject.controller.BaseServlet;
import com.myProject.controller.be.BeIndexServlet;
import com.myProject.entity.Cart;
import com.myProject.entity.Product;
import com.myProject.entity.UserLogin;
import com.myProject.service.CartService;
import com.myProject.service.ProductService;

@WebServlet("/fe/addToCart")
public class AddToCartServlet extends BaseServlet{
	private static final long serialVersionUID=1L;
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session=req.getSession();
		UserLogin user=(UserLogin) session.getAttribute("userlogin");
		Integer pid=Integer.valueOf(req.getParameter("pid"));
		CartService service=new CartService();
		List<Cart> cart=service.ById(pid);
		ProductService proService=new ProductService();
		Product categoryId=proService.queryById(pid);
		int num=1;
		String referer=req.getHeader("referer");
		//如果商品不为空，进行修改操作
		for (int i = 0; i < cart.size(); i++) {
			if(cart!=null && cart.get(i).getUser_uid()==user.getUser_uid()) {
				Cart c=service.getByNum(pid,user.getUser_uid());//查询该id的商品的数量
				num=c.getCart_num()+1;//给num赋值
				service.update(num,categoryId.getProduct_unitprice().doubleValue()*num,pid,user.getUser_uid());//购物车已存在商品，则把商品数量进行修改（+1）
				resp.sendRedirect(referer);
				return;
			}
		}
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		String time=df.format(new Date());
		int cid=categoryId.getCategory_id();
		Cart c=new Cart();
		c.setCart_time(time);
		c.setCart_num(num);
		c.setCart_subTotal(categoryId.getProduct_unitprice().doubleValue()*num);
		c.setCategory_id(cid);
		c.setProduct_id(pid);
		c.setUser_uid(user.getUser_uid());
		
		service.insert(c);
		
		resp.sendRedirect(referer);
	}

}
