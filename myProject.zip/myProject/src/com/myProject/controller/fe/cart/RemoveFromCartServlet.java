package com.myProject.controller.fe.cart;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.service.CartService;
import com.myProject.util.JsonUtils;

@WebServlet("/fe/removefromcart")
public class RemoveFromCartServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		CartService cartService=new CartService();
		Integer cid=Integer.valueOf(req.getParameter("cid"));
		boolean b=cartService.delete(cid);
		JsonUtils.write(resp.getOutputStream(), b);
	}
}
