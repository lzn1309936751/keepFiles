package com.myProject.controller.fe.cart;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Product;
import com.myProject.entity.UserLogin;
import com.myProject.service.CartService;
import com.myProject.service.ProductService;
import com.myProject.util.JsonUtils;

@WebServlet("/fe/updatecartnum")
public class UpdateCartNumServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer num=Integer.valueOf(req.getParameter("num"));
		Integer pid=Integer.valueOf(req.getParameter("pid"));
		ProductService proService=new ProductService();
		Product categoryId=proService.queryById(pid);
		double subTotal=categoryId.getProduct_unitprice().doubleValue()*num;
		
		HttpSession session=req.getSession();
		UserLogin user=(UserLogin) session.getAttribute("userlogin");
		CartService cartService=new CartService();
		boolean b=cartService.update(num,subTotal,pid,user.getUser_uid());
		
		JsonUtils.write(resp.getOutputStream(), b);
	}
}
