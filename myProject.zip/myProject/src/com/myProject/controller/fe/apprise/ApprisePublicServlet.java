package com.myProject.controller.fe.apprise;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Apprise;
import com.myProject.entity.UserLogin;
import com.myProject.service.AppriseService;

@WebServlet("/fe/apppublic")
public class ApprisePublicServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer pid=Integer.valueOf(req.getParameter("pid"));
		Integer oid=Integer.valueOf(req.getParameter("oid"));
		String txtContext=req.getParameter("txtContext");
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		String time=df.format(new Date());
		HttpSession session=req.getSession();
		UserLogin user=(UserLogin) session.getAttribute("userlogin");
		
		AppriseService appService=new AppriseService();
		Apprise appList=new Apprise();
		appList.setApprise_content(txtContext);
		appList.setApprise_time(time);
		appList.setProduct_id(pid);
		appList.setUser_uid(user.getUser_uid());
		appService.insert(appList);
		
		resp.sendRedirect("/fe/viewapprise?oid="+oid+"&pid="+pid);
		
	}
}
