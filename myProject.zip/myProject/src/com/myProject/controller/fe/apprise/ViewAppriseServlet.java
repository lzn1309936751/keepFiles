package com.myProject.controller.fe.apprise;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Apprise;
import com.myProject.entity.OrderInformation;
import com.myProject.service.AppriseService;
import com.myProject.service.OrderInformationService;

@WebServlet("/fe/viewapprise")
public class ViewAppriseServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer oid=Integer.valueOf(req.getParameter("oid"));
		OrderInformationService orderService=new OrderInformationService();
		OrderInformation orderList=orderService.queryById(oid);
		req.setAttribute("orderList", orderList);
		
		Integer pid=Integer.valueOf(req.getParameter("pid"));
		AppriseService appService=new AppriseService();
		List<Apprise> appList=appService.queryBySameId(pid);
		req.setAttribute("appList", appList);
		
		req.getRequestDispatcher("/WEB-INF/views/fe/apprise.jsp").forward(req, resp);;
	}
}
