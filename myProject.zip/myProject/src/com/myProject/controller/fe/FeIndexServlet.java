package com.myProject.controller.fe;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Cart;
import com.myProject.entity.Category;
import com.myProject.entity.Product;
import com.myProject.entity.UserLogin;
import com.myProject.page.PageInfo;
import com.myProject.service.CartService;
import com.myProject.service.CategoryService;
import com.myProject.service.ProductService;
import com.myProject.vo.ProductCategoryVO;

@WebServlet("/fe/index")
public class FeIndexServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer cid=getParamInteger(req, "cid", 0);
		CategoryService cateService=new CategoryService();
		List<Category> cateList=cateService.queryAll();
		
		ProductService productService=new ProductService();
		Map<String,Object> conditions=generateSearchCondition(req);
		int recordCount=productService.getProductsCountByCondition(conditions);
		PageInfo pageInfo=new PageInfo(getParamInteger(req, "pageno", 1),recordCount,PAGE_SIZE);
		List<Product> prouctList=productService.getProductsByCondition(conditions, pageInfo.getStart(),pageInfo.getEnd());
		ProductCategoryVO procateVO=new ProductCategoryVO(prouctList,cateList,pageInfo,cid);
		req.setAttribute("pvo", procateVO);
		//统计购物车内的商品条数
		HttpSession session=req.getSession();
		UserLogin user=(UserLogin) session.getAttribute("userlogin");
		CartService service=new CartService();
		int totalCount=service.RecordTotalCount(user.getUser_uid());
		req.setAttribute("totalCount", totalCount);
		//统计购物车内的商品总数量（num相加）
		int sum=0;
		List<Cart> carts=service.queryAll(user.getUser_uid());
		for(Cart c:carts) {
			sum+=c.getCart_num();
		}
		req.setAttribute("sum", sum);
		
		req.getRequestDispatcher("/WEB-INF/views/fe/index.jsp").forward(req, resp);
		
	}

	private Map<String, Object> generateSearchCondition(HttpServletRequest req) {
		Integer cid=getParamInteger(req, "cid", 0);
		String pname=req.getParameter("pname");
		Map<String,Object> conditions=new HashMap<>(16);
		if(cid!=null) {
			conditions.put("category_id",cid);
		}
		if(pname!=null) {
			conditions.put("product_name",pname);
		}
		return conditions;
	}

}
