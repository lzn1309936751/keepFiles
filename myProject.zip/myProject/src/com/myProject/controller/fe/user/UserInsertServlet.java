package com.myProject.controller.fe.user;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.UserLogin;
import com.myProject.service.UserLoginService;

@WebServlet("/fe/user/insert")
public class UserInsertServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uname=req.getParameter("uname");
		String pwd=req.getParameter("password");
		String sex=req.getParameter("sex");
		String getsex="";
		if("男".equals(sex)){
			getsex="男";
		}else if("女".equals(sex)){
			getsex="女";
		}
		
		String vc=req.getParameter("vc");//获取验证码
		String kaptchaExpected=
				(String)req.getSession().getAttribute("code");
		UserLoginService userService=new UserLoginService();
		List<UserLogin> userList=userService.queryAll();
		for(UserLogin u:userList) {
			if(vc.equalsIgnoreCase(kaptchaExpected)&&!uname.equals(u.getUser_uname())){
				userService.insert(uname,pwd,getsex);
				req.getRequestDispatcher("/fe/user/login").forward(req, resp);
				return;
			}
		}
		resp.sendRedirect("/fe/user/add");
	}
}
