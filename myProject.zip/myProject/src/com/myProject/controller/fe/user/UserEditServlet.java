package com.myProject.controller.fe.user;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.UserLogin;
import com.myProject.service.UserLoginService;

@WebServlet("/fe/user/edit")
public class UserEditServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer uid=Integer.valueOf(req.getParameter("uid"));
		UserLoginService userService=new UserLoginService();
		UserLogin users=userService.queryById(uid);
		req.setAttribute("users", users);
		req.getRequestDispatcher("/WEB-INF/views/be/user/edit.jsp").forward(req, resp);
	}
}
