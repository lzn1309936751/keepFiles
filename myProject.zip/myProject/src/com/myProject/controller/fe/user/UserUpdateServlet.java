package com.myProject.controller.fe.user;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.UserLogin;
import com.myProject.service.UserLoginService;

@WebServlet("/fe/user/update")
public class UserUpdateServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer uid=Integer.valueOf(req.getParameter("uid"));
		String uname=req.getParameter("uname");
		String password=req.getParameter("password");
		UserLoginService userService=new UserLoginService();
		boolean b=userService.update(uname,password,uid);
		resp.sendRedirect("/fe/index");
		
	}
}
