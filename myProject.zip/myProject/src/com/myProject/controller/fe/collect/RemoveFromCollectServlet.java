package com.myProject.controller.fe.collect;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.service.CollectService;
import com.myProject.util.JsonUtils;

@WebServlet("/fe/removefromcollect")
public class RemoveFromCollectServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer cid=Integer.valueOf(req.getParameter("cid"));
		CollectService collectService=new CollectService();
		boolean b=collectService.delete(cid);
		JsonUtils.write(resp.getOutputStream(), b);
	}
}
