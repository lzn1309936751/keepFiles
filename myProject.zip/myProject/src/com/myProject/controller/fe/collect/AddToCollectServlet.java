package com.myProject.controller.fe.collect;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Collect;
import com.myProject.entity.UserLogin;
import com.myProject.service.CollectService;

@WebServlet("/fe/addToCollect")
public class AddToCollectServlet extends BaseServlet{
	private static final long serialVersionUID=1L;
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session=req.getSession();
		UserLogin user=(UserLogin) session.getAttribute("userlogin");
		Integer pid=Integer.valueOf(req.getParameter("pid"));
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		String time=df.format(new Date());
		CollectService collectService=new CollectService();
		Collect collect=new Collect();
		collect.setCollect_time(time);
		collect.setProduct_id(pid);
		collect.setUser_uid(user.getUser_uid());
		collectService.insert(collect);
		
		String referer=req.getHeader("referer");
		resp.sendRedirect(referer);
	}
}
