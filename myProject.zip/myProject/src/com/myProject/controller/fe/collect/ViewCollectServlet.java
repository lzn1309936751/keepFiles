package com.myProject.controller.fe.collect;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.Collect;
import com.myProject.entity.UserLogin;
import com.myProject.service.CollectService;

@WebServlet("/fe/viewcollect")
public class ViewCollectServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {		
		HttpSession session=req.getSession();
		UserLogin user=(UserLogin) session.getAttribute("userlogin");
		CollectService collectService=new CollectService();
		List<Collect> collectList=collectService.queryAll(user.getUser_uid());
		req.setAttribute("collectList", collectList);
		req.getRequestDispatcher("/WEB-INF/views/fe/viewcollect.jsp").forward(req, resp);
	}
}
