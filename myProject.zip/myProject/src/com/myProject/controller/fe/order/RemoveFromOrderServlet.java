package com.myProject.controller.fe.order;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myProject.controller.BaseServlet;
import com.myProject.service.OrderInformationService;
import com.myProject.util.JsonUtils;

@WebServlet("/fe/removefromorder")
public class RemoveFromOrderServlet extends BaseServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer oid=Integer.valueOf(req.getParameter("oid"));
		OrderInformationService orderService=new OrderInformationService();
		boolean b=orderService.delete(oid);
		
		JsonUtils.write(resp.getOutputStream(), b);
	}
}
