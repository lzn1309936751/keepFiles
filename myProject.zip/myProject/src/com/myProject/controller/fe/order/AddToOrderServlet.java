package com.myProject.controller.fe.order;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myProject.controller.BaseServlet;
import com.myProject.entity.OrderInformation;
import com.myProject.entity.UserLogin;
import com.myProject.service.OrderInformationService;

@WebServlet("/fe/addToOrder")
public class AddToOrderServlet extends BaseServlet{
private static final long serialVersionUID=1L;
	
	@Override
	protected void service (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String[] checkbox=req.getParameterValues("mycheckbox");
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		String time=df.format(new Date());
		HttpSession session=req.getSession();
		UserLogin user=(UserLogin) session.getAttribute("userlogin");
		for (int i = 0;i<checkbox.length;i++) {
			String pid=checkbox[i].split(",")[0];
			String cid=checkbox[i].split(",")[1];
			OrderInformation order=new OrderInformation();
			order.setOrder_time(time);
			order.setCart_id(Integer.parseInt(cid));
			order.setProduct_id(Integer.parseInt(pid));
			order.setUser_uid(user.getUser_uid());
			OrderInformationService orderService=new OrderInformationService();
			orderService.insert(order);
		}
		resp.sendRedirect("/fe/vieworder");
	}
}
