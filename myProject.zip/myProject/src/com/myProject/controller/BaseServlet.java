package com.myProject.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract class BaseServlet extends HttpServlet{
	
	public static final int PAGE_SIZE=6;
	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		
	}
	
	protected Integer getParamInteger(HttpServletRequest req,String key,int defaultValue) {
		Integer returnValue=defaultValue;
		try {
			returnValue=Integer.valueOf(req.getParameter(key));
		}catch(Exception e) {
			
		}
		return returnValue;
	}
	
}
