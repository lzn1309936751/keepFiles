package com.myProject.service;

import java.util.List;

import com.myProject.dao.GradeDao;
import com.myProject.entity.Grade;

public class GradeService {
	GradeDao dao=new GradeDao();
	public List<Grade> queryAll(){
		return dao.queryAll();
	}
}
