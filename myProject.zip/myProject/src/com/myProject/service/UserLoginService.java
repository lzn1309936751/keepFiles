package com.myProject.service;

import java.util.List;
import java.util.Map;

import com.myProject.dao.UserLoginDao;
import com.myProject.entity.Product;
import com.myProject.entity.UserLogin;

public class UserLoginService {
	UserLoginDao dao=new UserLoginDao();
	public boolean insert(Object...params) {
		return dao.insert(params);
	}
	
	public boolean delete(Object...params) {
		return dao.delete(params);
	}
	
	public boolean update(Object...params) {
		return dao.update(params);
	}
	
	public List<UserLogin> queryAll(){
		return dao.queryAll();
	}
	
	public UserLogin queryById(Object...params){
		return dao.queryById(params);
	}
	
	public List<UserLogin> getPagedRecords(int start,int end){
		return dao.getPagedRecords(start, end);
	}
	
	public int RecordCount() {
		return dao.RecordCount();
	}
	
	public List<UserLogin> getProductsByCondition
	(Map<String,Object> condition,int offset,int count){
		return dao.getProductsByCondition(condition, offset, count);
	}
	
	public int getProductsCountByCondition(Map<String,Object> condition) {
		return dao.getProductsCountByCondition(condition);
	}
}
