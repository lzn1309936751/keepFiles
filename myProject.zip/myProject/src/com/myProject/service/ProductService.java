package com.myProject.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.handlers.BeanHandler;

import com.myProject.dao.ProductDao;
import com.myProject.entity.Product;

public class ProductService {
	ProductDao dao=new ProductDao();
	public boolean insert(Product product) {
		return dao.insert(product);
	}
	
	public boolean delete(Integer id) {
		return dao.delete(id);
	}
	
	public boolean update(Product product) {
		return dao.update(product);
	}
	
	public List<Product> queryAll() {
		return dao.queryAll();
	}
	
	public Product queryByProductId(Object...params){
		return dao.queryByProductId(params);
	}
	
	public Product queryById(Integer id) {
		return dao.queryById(id);
	}
	
	public List<Product> getPagedRecords(int start,int end){
		return dao.getPagedRecords(start, end);
	}
	
	public int RecordCount() {
		return dao.RecordCount();
	}
	
	public List<Product> getProductsByCondition
	(Map<String,Object> condition,int offset,int count){
		return dao.getProductsByCondition(condition, offset, count);
	}
	
	public int getProductsCountByCondition(Map<String,Object> condition) {
		return dao.getProductsCountByCondition(condition);
	}
	
}
