package com.myProject.service;

import java.util.List;

import com.myProject.dao.CollectDao;
import com.myProject.entity.Cart;
import com.myProject.entity.Collect;

public class CollectService {

	CollectDao dao=new CollectDao();
	public boolean insert(Collect collect) {
		return dao.insert(collect);
	}
	
	public boolean delete(Object...params) {
		return dao.delete(params);
	}
	
	public List<Collect> queryAll(Object...params){
		return dao.queryAll(params);
	}
}
