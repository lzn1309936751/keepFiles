package com.myProject.service;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.myProject.dao.AdministratorDao;
import com.myProject.entity.Administrator;

public class AdministratorService {
	AdministratorDao dao=new AdministratorDao();
	public boolean insert(Object...params) {
		return dao.insert(params);
	}
	
	public boolean delete(Object...params) {
		return dao.delete(params);
	}
	
	public boolean update(Object...params) {
		return dao.update(params);
	}
	
	public List<Administrator> queryAll(){
		return dao.queryAll();
	}
	
	public Administrator queryById(Object...params){
		return dao.queryById(params);
	}
}
