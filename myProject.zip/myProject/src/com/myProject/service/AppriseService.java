package com.myProject.service;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.myProject.dao.AppriseDao;
import com.myProject.entity.Apprise;

public class AppriseService {
	AppriseDao dao=new AppriseDao();
	
	public boolean insert(Apprise apprise) {
		return dao.insert(apprise);
	}
	
	public List<Apprise> queryAll(Object...params){
		return dao.queryAll(params);
	}
	
	public Apprise queryById(int oid){
		return dao.queryById(oid);
	}
	
	public List<Apprise> queryBySameId(int oid){
		return dao.queryBySameId(oid);
	}
}
