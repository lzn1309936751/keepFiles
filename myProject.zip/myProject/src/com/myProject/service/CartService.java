package com.myProject.service;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.myProject.dao.CartDao;
import com.myProject.entity.Cart;

public class CartService {
	CartDao dao=new CartDao();
	
	public List<Cart> ById(int pid){
		return dao.ById(pid);
	}
	
	public Cart getByNum(int pid,int uid){
		return dao.getByNum(pid,uid);
	}
	
	public boolean insert(Cart cart) {
		
		return dao.insert(cart);
	}
	
	public boolean delete(Object...params) {
		return dao.delete(params);
	}
	
	public boolean update(Object...params) {
		return dao.update(params);
	}
	
	public List<Cart> queryAll(Object...params){
		return dao.queryAll(params);
	}
	
	public int RecordTotalCount(int uid) {
		return dao.RecordTotalCount(uid);
	}
	
	public Cart RecordCategoryCounts() {
		return dao.RecordCategoryCounts();
	}
}
