package com.myProject.service;

import java.util.List;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.myProject.dao.OrderInformationDao;
import com.myProject.entity.Cart;
import com.myProject.entity.OrderInformation;

public class OrderInformationService {
	
	OrderInformationDao dao=new OrderInformationDao();
	
	public boolean insert(OrderInformation order) {
		return dao.insert(order);
	}
	
	public boolean delete(Object...params) {
		return dao.delete(params);
	}
	
	public List<OrderInformation> queryAll(Object...params){
		return dao.queryAll(params);
	}
	
	public OrderInformation queryById(int id){
		return dao.queryById(id);
	}
	
	//查询订单表内的商品数量，作为销售的成交数量
		public int RecordSaleCount() {
			return dao.RecordSaleCount();
		}
		
		//查询订单表内的商品数量，作为销售的成交数量
		public List<OrderInformation> RecordSaleMoneyCount(){
			return dao.RecordSaleMoneyCount();
		}
}
