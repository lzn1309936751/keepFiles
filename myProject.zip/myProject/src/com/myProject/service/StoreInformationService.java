package com.myProject.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.myProject.dao.StoreInformationDao;
import com.myProject.entity.Product;
import com.myProject.entity.StoreInformation;

public class StoreInformationService {
	StoreInformationDao dao=new StoreInformationDao();
	public boolean insert(Object...params) {
		return dao.insert(params);
	}
	
	public boolean delete(Object...params) {
		return dao.delete(params);
	}
	
	public boolean update(Object...params) {
		return dao.update(params);
	}
	
	public List<StoreInformation> queryAll(){
		return dao.queryAll();
	}
	
	public StoreInformation queryById(Object...params){
		return dao.queryById(params);
	}
	
	public List<StoreInformation> getPagedRecords(int start,int end){
		return dao.getPagedRecords(start, end);
	}
	
	public int RecordCount() {
		return dao.RecordCount();
	}
	
	public List<StoreInformation> getProductsByCondition
	(Map<String,Object> condition,int offset,int count){
		return dao.getProductsByCondition(condition, offset, count);
	}
	
	public int getProductsCountByCondition(Map<String,Object> condition) {
		return dao.getProductsCountByCondition(condition);
	}
}
