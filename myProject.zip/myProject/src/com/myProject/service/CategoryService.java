package com.myProject.service;

import java.util.List;


import com.myProject.dao.CategoryDao;
import com.myProject.entity.Category;

public class CategoryService {
	CategoryDao dao=new CategoryDao();
	public boolean insert(Object...params) {
		return dao.insert(params);
	}
	
	public boolean delete(Object...params) {
		return dao.delete(params);
	}
	
	public boolean update(Object...params) {
		return dao.update(params);
	}
	
	public List<Category> queryAll(){
		return dao.queryAll();
	}
	
	public Category queryById(Object...params){
		return dao.queryById(params);
	}
}
