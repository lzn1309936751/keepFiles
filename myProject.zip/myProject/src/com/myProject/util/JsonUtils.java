package com.myProject.util;

import java.io.IOException;
import java.io.OutputStream;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.myProject.exception.AppException;

public class JsonUtils {
	
	
	public static void write(OutputStream outputStream,Object o){
		ObjectMapper mapper=new ObjectMapper();
		try {
			mapper.writeValue(outputStream, o);
		} catch (IOException e) {
			e.printStackTrace();
			throw new AppException("json serialize failed");
		}
	}
}
