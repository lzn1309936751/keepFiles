package com.myProject.util;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;

import com.myProject.exception.DaoException;

public class QueryRunnerWrapper {
	
	public int modify(String sql,Object...params){
		Connection conn=null;
		QueryRunner queryRunner = new QueryRunner(true);
		try {
			conn=ConnectionHelper.getConnection();
			return queryRunner.update(conn,sql,params);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DaoException("update db failed"+e.getMessage());
		}finally{
			DbUtils.closeQuietly(conn);
		}
	}
	
	//����id��ѯ
	public <T> T Query(String sql,ResultSetHandler<T> handler,Object...params){
		Connection conn=null;
		QueryRunner queryRunner = new QueryRunner(true);
		try {
			conn=ConnectionHelper.getConnection();
			return queryRunner.query(conn, sql, handler,params);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DaoException("update db failed"+e.getMessage());
		}finally{
			DbUtils.closeQuietly(conn);
		}
	}
	
}

