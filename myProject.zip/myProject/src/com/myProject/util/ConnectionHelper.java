package com.myProject.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;



public class ConnectionHelper {
	private static String Driver="";
	private static String URL="";
	private static String UserName="";
	private static String Pwd="";
	
	static{
		Properties prop=new Properties();
		InputStream in=ConnectionHelper.class.getResourceAsStream("/resource/db.properties");
		try {
			prop.load(in);
			Driver=prop.getProperty("DRIVER");
			URL=prop.getProperty("URL");
			UserName=prop.getProperty("USERNAME");
			Pwd=prop.getProperty("PASSWORD");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	static{
		try {
			Class.forName(Driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() throws SQLException{
		Connection conn=null;
		conn=DriverManager.getConnection(URL, UserName, Pwd);
		return conn;
	}
}
