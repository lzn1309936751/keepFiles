package com.myProject.vo;

import java.util.List;

import com.myProject.entity.UserLogin;
import com.myProject.page.PageInfo;

public class UserVO {
	private PageInfo pageInfo;
	private List<UserLogin> users;
	
	public UserVO() {}
	
	public UserVO(PageInfo pageInfo,List<UserLogin> users) {
		this.pageInfo=pageInfo;
		this.users=users;
	}
	
	public PageInfo getPageInfo() {
		return pageInfo;
	}
	public void setPageInfo(PageInfo pageInfo) {
		this.pageInfo = pageInfo;
	}
	public List<UserLogin> getUsers() {
		return users;
	}
	public void setUsers(List<UserLogin> users) {
		this.users = users;
	}
}
