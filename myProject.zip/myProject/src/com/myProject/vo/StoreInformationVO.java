package com.myProject.vo;

import java.util.List;

import com.myProject.entity.Grade;
import com.myProject.entity.StoreInformation;
import com.myProject.page.PageInfo;

public class StoreInformationVO {
	private PageInfo pageInfo;
	private List<StoreInformation> store;
	private List<Grade> grade;
	
	public StoreInformationVO(PageInfo pageInfo, List<StoreInformation> storeList,List<Grade> grade){
		this.pageInfo=pageInfo;
		this.store=storeList;
		this.grade=grade;
	}
	
	public PageInfo getPageInfo() {
		return pageInfo;
	}
	public void setPageInfo(PageInfo pageInfo) {
		this.pageInfo = pageInfo;
	}
	public List<StoreInformation> getStore() {
		return store;
	}
	public void setStore(List<StoreInformation> store) {
		this.store = store;
	}

	public List<Grade> getGrade() {
		return grade;
	}

	public void setGrade(List<Grade> grade) {
		this.grade = grade;
	}
	
}
