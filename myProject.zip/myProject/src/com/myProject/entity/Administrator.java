package com.myProject.entity;

public class Administrator {
	int admin_id;
	String admin_name;
	String admin_password;
	String admin_sex;
	String admin_manager;
	float admin_salary;
	String admin_phone;
	public int getAdmin_id() {
		return admin_id;
	}
	public void setAdmin_id(int admin_id) {
		this.admin_id = admin_id;
	}
	public String getAdmin_name() {
		return admin_name;
	}
	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}
	public String getAdmin_password() {
		return admin_password;
	}
	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}
	public String getAdmin_sex() {
		return admin_sex;
	}
	public void setAdmin_sex(String admin_sex) {
		this.admin_sex = admin_sex;
	}
	public String getAdmin_manager() {
		return admin_manager;
	}
	public void setAdmin_manager(String admin_manager) {
		this.admin_manager = admin_manager;
	}
	public float getAdmin_salary() {
		return admin_salary;
	}
	public void setAdmin_salary(float admin_salary) {
		this.admin_salary = admin_salary;
	}
	public String getAdmin_phone() {
		return admin_phone;
	}
	public void setAdmin_phone(String admin_phone) {
		this.admin_phone = admin_phone;
	}
}
