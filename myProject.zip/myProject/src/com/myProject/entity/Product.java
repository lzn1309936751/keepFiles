package com.myProject.entity;

import java.math.BigDecimal;

public class Product {
	int product_id;
	String product_name;
	String product_desc;
	BigDecimal product_unitprice;
	String product_image;
	String category_name;
	String store_name;
	int category_id;
	int store_id;
	public Product() {}
	//修改的构造函数
	public Product(String pname, String pdesc, BigDecimal unitPrice, String filename, Integer cid,
			Integer sid,Integer pid) {
		this.product_name=pname;
		this.product_desc=pdesc;
		this.product_unitprice=unitPrice;
		this.product_image=filename;
		this.category_id=cid;
		this.store_id=sid;
		this.product_id=pid;
	}
	//添加的构造函数
	public Product(String pname, String pdesc, BigDecimal unitPrice, String filename, Integer cid, Integer sid) {
		this.product_name=pname;
		this.product_desc=pdesc;
		this.product_unitprice=unitPrice;
		this.product_image=filename;
		this.category_id=cid;
		this.store_id=sid;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getProduct_desc() {
		return product_desc;
	}
	public void setProduct_desc(String product_desc) {
		this.product_desc = product_desc;
	}
	public BigDecimal getProduct_unitprice() {
		return product_unitprice;
	}
	public void setProduct_unitprice(BigDecimal product_unitprice) {
		this.product_unitprice = product_unitprice;
	}
	public String getProduct_image() {
		return product_image;
	}
	public void setProduct_image(String product_image) {
		this.product_image = product_image;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public String getStore_name() {
		return store_name;
	}
	public void setStore_name(String store_name) {
		this.store_name = store_name;
	}
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public int getStore_id() {
		return store_id;
	}
	public void setStore_id(int store_id) {
		this.store_id = store_id;
	}
}
