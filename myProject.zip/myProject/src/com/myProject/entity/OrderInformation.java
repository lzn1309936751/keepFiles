package com.myProject.entity;

public class OrderInformation {
	int order_id;
	String order_time;
	String product_image;
	String product_name;
	float product_unitprice;
	String product_desc;
	int cart_num;
	float cart_subTotal;
	int cart_id;
	int product_id;
	int user_uid;
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
	public String getOrder_time() {
		return order_time;
	}
	public void setOrder_time(String order_time) {
		this.order_time = order_time;
	}
	public String getProduct_image() {
		return product_image;
	}
	public void setProduct_image(String product_image) {
		this.product_image = product_image;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public float getProduct_unitprice() {
		return product_unitprice;
	}
	public void setProduct_unitprice(float product_unitprice) {
		this.product_unitprice = product_unitprice;
	}
	public String getProduct_desc() {
		return product_desc;
	}
	public void setProduct_desc(String product_desc) {
		this.product_desc = product_desc;
	}
	public int getCart_num() {
		return cart_num;
	}
	public void setCart_num(int cart_num) {
		this.cart_num = cart_num;
	}
	public float getCart_subTotal() {
		return cart_subTotal;
	}
	public void setCart_subTotal(float cart_subTotal) {
		this.cart_subTotal = cart_subTotal;
	}
	public int getCart_id() {
		return cart_id;
	}
	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public int getUser_uid() {
		return user_uid;
	}
	public void setUser_uid(int user_uid) {
		this.user_uid = user_uid;
	}
}
