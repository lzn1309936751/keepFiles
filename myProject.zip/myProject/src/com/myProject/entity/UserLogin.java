package com.myProject.entity;

public class UserLogin {
	int user_uid;
	String user_uname;
	String user_password;
	String user_sex;
	public int getUser_uid() {
		return user_uid;
	}
	public void setUser_uid(int user_uid) {
		this.user_uid = user_uid;
	}
	public String getUser_uname() {
		return user_uname;
	}
	public void setUser_uname(String user_uname) {
		this.user_uname = user_uname;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public String getUser_sex() {
		return user_sex;
	}
	public void setUser_sex(String user_sex) {
		this.user_sex = user_sex;
	}
}
