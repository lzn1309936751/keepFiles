package com.myProject.entity;

import java.math.BigDecimal;

public class Cart {
	int cart_id;
	String cart_time;
	int cart_num;
	double cart_subTotal;
	int category_id;
	int product_id;
	int user_uid;
	String product_image;
	String product_name;
	double product_unitprice;
	
	public int getCart_id() {
		return cart_id;
	}
	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public String getCart_time() {
		return cart_time;
	}
	public void setCart_time(String cart_time) {
		this.cart_time = cart_time;
	}
	public int getCart_num() {
		return cart_num;
	}
	public void setCart_num(int cart_num) {
		this.cart_num = cart_num;
	}
	public double getCart_subTotal() {
		return this.cart_subTotal;
	}
	public void setCart_subTotal(double cart_subTotal) {
		this.cart_subTotal= cart_subTotal;
	}
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_image() {
		return product_image;
	}
	public void setProduct_image(String product_image) {
		this.product_image = product_image;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public double getProduct_unitprice() {
		return product_unitprice;
	}
	public void setProduct_unitprice(double product_unitprice) {
		this.product_unitprice = product_unitprice;
	}
	public int getUser_uid() {
		return user_uid;
	}
	public void setUser_uid(int user_uid) {
		this.user_uid = user_uid;
	}
	
	
	@Override
	public String toString() {
		return "Cart [cart_id=" + cart_id + ", cart_time=" + cart_time + ", product_id=" + product_id
				+ ", product_image=" + product_image + ", product_name=" + product_name + ", product_unitprice="
				+ product_unitprice + "]";
	}
	
	

}
