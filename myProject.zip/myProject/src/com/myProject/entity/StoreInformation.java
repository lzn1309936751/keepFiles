package com.myProject.entity;

public class StoreInformation {
	int store_id;
	String store_name;
	float store_description;
	float store_service;
	float store_logistics;
	String grade_name;
	int grade_id;
	public int getStore_id() {
		return store_id;
	}
	public void setStore_id(int store_id) {
		this.store_id = store_id;
	}
	public String getStore_name() {
		return store_name;
	}
	public void setStore_name(String store_name) {
		this.store_name = store_name;
	}
	public float getStore_description() {
		return store_description;
	}
	public void setStore_description(float store_description) {
		this.store_description = store_description;
	}
	public float getStore_service() {
		return store_service;
	}
	public void setStore_service(float store_service) {
		this.store_service = store_service;
	}
	public float getStore_logistics() {
		return store_logistics;
	}
	public void setStore_logistics(float store_logistics) {
		this.store_logistics = store_logistics;
	}
	public String getGrade_name() {
		return grade_name;
	}
	public void setGrade_name(String grade_name) {
		this.grade_name = grade_name;
	}
	public int getGrade_id() {
		return grade_id;
	}
	public void setGrade_id(int grade_id) {
		this.grade_id = grade_id;
	}
}
