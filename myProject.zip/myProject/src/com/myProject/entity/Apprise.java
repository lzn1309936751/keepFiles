package com.myProject.entity;

public class Apprise {
	int apprise_id;
	String apprise_content;
	String apprise_time;
	int product_id;
	int user_uid;
	String user_uname;
	public int getApprise_id() {
		return apprise_id;
	}
	public void setApprise_id(int apprise_id) {
		this.apprise_id = apprise_id;
	}
	public String getApprise_content() {
		return apprise_content;
	}
	public void setApprise_content(String apprise_content) {
		this.apprise_content = apprise_content;
	}
	public String getApprise_time() {
		return apprise_time;
	}
	public void setApprise_time(String apprise_time) {
		this.apprise_time = apprise_time;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public int getUser_uid() {
		return user_uid;
	}
	public void setUser_uid(int user_uid) {
		this.user_uid = user_uid;
	}
	public String getUser_uname() {
		return user_uname;
	}
	public void setUser_uname(String user_uname) {
		this.user_uname = user_uname;
	}
}
