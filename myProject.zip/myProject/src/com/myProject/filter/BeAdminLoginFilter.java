package com.myProject.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class BeAdminLoginFilter implements Filter{
	
	private String loginUrl=null;
	
	private String[] allowList=null;
	
	@Override
	public void destroy() {
		
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req=(HttpServletRequest) request;
		HttpServletResponse resp=(HttpServletResponse) response;
		//下面判断是否是可以直接访问的url
		if(isAllowd(getRequestUrl(req))) {
			chain.doFilter(request, response);
		}else {
			HttpSession session=req.getSession();
			Object user=session.getAttribute("adminName");
			//不为空表示曾经已经登录过
			if(user!=null) {
				chain.doFilter(request, response);
			}else {
				//表示没有登陆过，就需要去登录界面进行登录
				resp.sendRedirect(loginUrl);
			}
		}
		
	}

	private boolean isAllowd(String requestUri) {
		boolean isAllowd=false;
		for(int i=0;i<allowList.length;i++) {
			if(allowList[i].equals(requestUri)) {
				isAllowd=true;
				break;
			}
		}
		return isAllowd;
	}

	private String getRequestUrl(HttpServletRequest req) {
		//得到上下文名字，如果没有就是空串
		String context=req.getContextPath();
		//得到从上下文地址开始到查询字符串结束的之间的url
		String requestUri=req.getRequestURI();
		
		String result=requestUri.substring(context.length());
		return result;
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		loginUrl=filterConfig.getInitParameter("loginUrl");
		allowList=filterConfig.getInitParameter("allowList").split(",");
		
	}

}
