document.write("<h2>系统时间："+new Date().toLocaleString()+"</h2>");

document.getElementById("btnOK").onclick=function(){
	var divDemo=document.getElementById("demo");
	divDemo.innerHTML="欢迎使用JavaScript语言！";
}

document.getElementById("btn").onclick=function(){
	var ele=document.getElementById("img");
	ele.src="0.jpg";
	this.disabled=true;
}

var movies=document.getElementsByClassName("listMovie");
for(i=0;i<movies.length;i++){
	movies[i].onmouseover=function(){this.style.backgroundColor='red';}
	movies[i].onmouseout=function(){this.style.backgroundColor='yellow';}
}