﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prince
{
    public class Prince
    {
        int pid;
        string pName;
        string pCountry;
        int pAge;
        bool pIsMarry;
        string pIsMarrystring;
        public int Pid { get => pid; set => pid = value; }
        public string PName { get => pName; set => pName = value; }
        public string PCountry { get => pCountry; set => pCountry = value; }
        public int PAge { get => pAge; set => pAge = value; }
        public bool PIsMarry
        {
            get { return this.pIsMarry; }
            set
            {
                pIsMarry = value;
                if (value)
                    pIsMarrystring = "已婚";
                else
                    pIsMarrystring = "未婚";
            }
        }

        public string PIsMarrystring
        {
            get { return pIsMarrystring; }
            set { pIsMarrystring = value; }
        }
    }
}
