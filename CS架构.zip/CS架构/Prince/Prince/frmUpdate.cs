﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Prince
{
    public partial class frmUpdate : Form
    {
        public frmUpdate()
        {
            InitializeComponent();
        }
        int pid;
        public frmUpdate(int pid)
        {
            InitializeComponent();
            this.pid = pid;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string name = txtname.Text;
            string country = txtcountry.Text;
            string age = txtage.Text;
            int Marry = radioButton1.Checked ? 1 : 0;
            string constr = ConfigurationManager.ConnectionStrings["SQL"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(constr))
            {
                conn.Open();
                string sql = "update Prince set pName=@pName,pCountry=@pCountry,pAge=@pAge,pIsMarry=@pIsMarry where pid=@pid";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlParameter[] p =
                {
                        new SqlParameter("@pName",name),
                        new SqlParameter("@pCountry",country),
                        new SqlParameter("@pAge",age),
                        new SqlParameter("@pIsMarry",Marry),
                        new SqlParameter ("@pid",pid)
                };
                cmd.Parameters.AddRange(p);
                int count = cmd.ExecuteNonQuery();
                if (count > 0)
                {
                    MessageBox.Show("修改成功！");
                    Form1.main.Form1_Load(null, null);
                }
                else
                    MessageBox.Show("修改失败！");
            }
        }
    }
}
