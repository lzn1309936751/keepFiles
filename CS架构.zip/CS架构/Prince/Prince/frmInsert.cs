﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Configuration;
using System.Data.SqlClient;

namespace Prince
{
    public partial class frmInsert : Form
    {
        public frmInsert()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            string name = txtname.Text;
            string country = txtcountry.Text;
            string age = txtage.Text;
            string ismarry = txtIsmarry.Text;
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("姓名不能为空！");
                return;
            }
            if (string.IsNullOrEmpty(country))
            {
                MessageBox.Show("国家不能为空！");
                return;
            }
            if (string.IsNullOrEmpty(age))
            {
                MessageBox.Show("年龄不能为空！");
                return;
            }
            if (string.IsNullOrEmpty(ismarry))
            {
                MessageBox.Show("婚姻状况不能为空！");
                return;
            }
            string constr = ConfigurationManager.ConnectionStrings["SQL"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(constr))
            {
                conn.Open();
                string sql = "insert into Prince values(@pName,@pCountry,@pAge,@pIsMarry)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlParameter[] p =
                {
                        new SqlParameter("@pName",name),
                        new SqlParameter("@pCountry",country),
                        new SqlParameter("@pAge",age),
                        new SqlParameter("@pIsMarry",ismarry),
                    };
                cmd.Parameters.AddRange(p);
                int count = cmd.ExecuteNonQuery();
                if (count > 0)
                {
                    MessageBox.Show("添加成功！");
                    Form1.main.Form1_Load(null, null);
                }
                else
                    MessageBox.Show("添加失败！");
            }
            
        }
    }
}
