﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Configuration;
using System.Data.SqlClient;

namespace Prince
{
    public partial class Form1 : Form
    {
        public static Form1 main;
        public Form1()
        {
            InitializeComponent();
            main = this;
        }

        public void Form1_Load(object sender, EventArgs e)
        {
            DataLoad();
        }

        public void DataLoad()
        {
            string constr = ConfigurationManager.ConnectionStrings["SQL"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(constr))
            {
                try
                {
                    conn.Open();
                    string sql = "select * from Prince";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    SqlDataReader dr = cmd.ExecuteReader();
                    List<Prince> list = new List<Prince>();
                    Prince model = null;
                    while(dr.Read())
                    {
                        model = new Prince();
                        model.Pid = (int)dr["pid"];
                        model.PName = dr["pName"].ToString();
                        model.PCountry = dr["pCountry"].ToString();
                        model.PAge = (int)dr["pAge"];
                        model.PIsMarry = (bool)dr["pIsMarry"];
                        list.Add(model);
                    }
                    dr.Close();
                    dvgimformation.DataSource = list;
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        

        private void btnselect_Click(object sender, EventArgs e)
        {
            string country = txtCountry.Text;
            string constr = ConfigurationManager.ConnectionStrings["SQL"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(constr))
            {
                try
                {
                    conn.Open();
                    string sql = "select * from Prince where pCountry like @pCountry or pName like @pCountry";
                    SqlParameter[] p =
                        {
                        new SqlParameter("@pCountry", "%"+txtCountry.Text+"%"),
                        new SqlParameter("@pName", "%"+txtCountry.Text+"%")
                      };
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddRange(p);
                    SqlDataReader dr = cmd.ExecuteReader();
                    List<Prince> list = new List<Prince>();
                    Prince model = null;
                    while (dr.Read())
                    {
                        model = new Prince();
                        model.Pid = (int)dr["pid"];
                        model.PName = dr["pName"].ToString();
                        model.PCountry = dr["pCountry"].ToString();
                        model.PAge = (int)dr["pAge"];
                        model.PIsMarry = (bool)dr["pIsMarry"];
                        list.Add(model);
                    }
                    dr.Close();
                    dvgimformation.DataSource = list;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string id = dvgimformation.SelectedRows[0].Cells[0].Value.ToString();
            Delete(id);
        }
        public void Delete(string id)
        {
            string constr = ConfigurationManager.ConnectionStrings["SQL"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(constr))
            {
                try
                {
                    conn.Open();
                    string sql = "delete from Prince where pid=@pid";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.Add(new SqlParameter("@pid",id));
                    int count = cmd.ExecuteNonQuery();
                    if (count > 0)
                    {
                        MessageBox.Show("删除成功！");
                        Form1_Load(null,null);
                    }
                    else
                        MessageBox.Show("删除失败！");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void btninsert_Click(object sender, EventArgs e)
        {
            frmInsert insert = new frmInsert();
            insert.ShowDialog();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            int pid = (int)dvgimformation.SelectedRows[0].Cells["pid"].Value;
            frmUpdate update = new frmUpdate(pid);
            update.ShowDialog();
        }
    }
}
