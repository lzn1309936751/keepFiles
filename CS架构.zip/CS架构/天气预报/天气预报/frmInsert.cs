﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 天气预报
{
    public partial class frmInsert : Form
    {
        public frmInsert()
        {
            InitializeComponent();
        }

        private void frmInsert_Load(object sender, EventArgs e)
        {

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            string name = txtweather.Text.Trim();
            string low = txtlow.Text.Trim();
            string heigh = txtheigh.Text.Trim();
            string address = txtaddress.Text.Trim();
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("天气不能为空!");
                return;
            }
            if (string.IsNullOrEmpty(low))
            {
                MessageBox.Show("最低温度不能为空!");
                return;
            }
            if (string.IsNullOrEmpty(heigh))
            {
                MessageBox.Show("最高温度不能为空!");
                return;
            }
            if (string.IsNullOrEmpty(address))
            {
                MessageBox.Show("地区不能为空!");
                return;
            }
            string sql = "insert into Weather values(@wname,@lowtemp,@heigtemp,@address,@date)";  
            string constr = ConfigurationManager.ConnectionStrings["sql"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(constr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.Add(new SqlParameter("@wname", name));
                    cmd.Parameters.Add(new SqlParameter("@lowtemp",low));
                    cmd.Parameters.Add(new SqlParameter("@heigtemp", heigh));
                    cmd.Parameters.Add(new SqlParameter("@address",address));
                    cmd.Parameters.Add(new SqlParameter("@date", dtetime.Text));
                    int count = cmd.ExecuteNonQuery();
                    if (count > 0)
                    {
                        MessageBox.Show("添加成功!");
                        frmWeather.main.frmWeather_Load(null,null);
                    }
                    else
                    {
                        MessageBox.Show("添加失败!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
