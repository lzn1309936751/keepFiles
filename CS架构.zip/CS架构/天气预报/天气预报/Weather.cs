﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 天气预报
{
    public class Weather
    {
        int wid;
        string wname;
        string lowtemp;
        string  heigtemp;
        string address;
        DateTime wdate;

        public int Wid { get => wid; set => wid = value; }
        public string Wname { get => wname; set => wname = value; }
     
        public string Address { get => address; set => address = value; }
        public DateTime Wdate { get => wdate; set => wdate = value; }
        public string Lowtemp { get => lowtemp; set => lowtemp = value; }
        public string Heigtemp { get => heigtemp; set => heigtemp = value; }
    }
}
