﻿namespace 天气预报
{
    partial class frmWeather
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvimformation = new System.Windows.Forms.DataGridView();
            this.wid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lowtemp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.heigtemp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtweather = new System.Windows.Forms.TextBox();
            this.btnselect = new System.Windows.Forms.Button();
            this.btninsert = new System.Windows.Forms.Button();
            this.lblweather = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvimformation)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvimformation
            // 
            this.dgvimformation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvimformation.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.wid,
            this.wname,
            this.lowtemp,
            this.heigtemp,
            this.address,
            this.wdate});
            this.dgvimformation.Location = new System.Drawing.Point(22, 64);
            this.dgvimformation.Name = "dgvimformation";
            this.dgvimformation.RowTemplate.Height = 23;
            this.dgvimformation.Size = new System.Drawing.Size(630, 340);
            this.dgvimformation.TabIndex = 1;
            // 
            // wid
            // 
            this.wid.DataPropertyName = "wid";
            this.wid.HeaderText = "序号";
            this.wid.Name = "wid";
            // 
            // wname
            // 
            this.wname.DataPropertyName = "wname";
            this.wname.HeaderText = "天气";
            this.wname.Name = "wname";
            // 
            // lowtemp
            // 
            this.lowtemp.DataPropertyName = "lowtemp";
            this.lowtemp.HeaderText = "最低温度";
            this.lowtemp.Name = "lowtemp";
            // 
            // heigtemp
            // 
            this.heigtemp.DataPropertyName = "heigtemp";
            this.heigtemp.HeaderText = "最高温度";
            this.heigtemp.Name = "heigtemp";
            // 
            // address
            // 
            this.address.DataPropertyName = "address";
            this.address.HeaderText = "地区";
            this.address.Name = "address";
            // 
            // wdate
            // 
            this.wdate.DataPropertyName = "wdate";
            this.wdate.HeaderText = "日期";
            this.wdate.Name = "wdate";
            // 
            // txtweather
            // 
            this.txtweather.Font = new System.Drawing.Font("宋体", 14F);
            this.txtweather.Location = new System.Drawing.Point(86, 24);
            this.txtweather.Name = "txtweather";
            this.txtweather.Size = new System.Drawing.Size(128, 29);
            this.txtweather.TabIndex = 2;
            // 
            // btnselect
            // 
            this.btnselect.Font = new System.Drawing.Font("宋体", 14F);
            this.btnselect.Location = new System.Drawing.Point(305, 25);
            this.btnselect.Name = "btnselect";
            this.btnselect.Size = new System.Drawing.Size(75, 28);
            this.btnselect.TabIndex = 3;
            this.btnselect.Text = "查询";
            this.btnselect.UseVisualStyleBackColor = true;
            this.btnselect.Click += new System.EventHandler(this.btnselect_Click);
            // 
            // btninsert
            // 
            this.btninsert.Font = new System.Drawing.Font("宋体", 14F);
            this.btninsert.Location = new System.Drawing.Point(406, 25);
            this.btninsert.Name = "btninsert";
            this.btninsert.Size = new System.Drawing.Size(75, 28);
            this.btninsert.TabIndex = 4;
            this.btninsert.Text = "添加";
            this.btninsert.UseVisualStyleBackColor = true;
            this.btninsert.Click += new System.EventHandler(this.btninsert_Click);
            // 
            // lblweather
            // 
            this.lblweather.AutoSize = true;
            this.lblweather.Font = new System.Drawing.Font("宋体", 14F);
            this.lblweather.Location = new System.Drawing.Point(18, 30);
            this.lblweather.Name = "lblweather";
            this.lblweather.Size = new System.Drawing.Size(66, 19);
            this.lblweather.TabIndex = 5;
            this.lblweather.Text = "天气：";
            // 
            // frmWeather
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 424);
            this.Controls.Add(this.lblweather);
            this.Controls.Add(this.btninsert);
            this.Controls.Add(this.btnselect);
            this.Controls.Add(this.txtweather);
            this.Controls.Add(this.dgvimformation);
            this.Name = "frmWeather";
            this.Text = "frmWeather";
            this.Load += new System.EventHandler(this.frmWeather_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvimformation)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dgvimformation;
        private System.Windows.Forms.DataGridViewTextBoxColumn wid;
        private System.Windows.Forms.DataGridViewTextBoxColumn wname;
        private System.Windows.Forms.DataGridViewTextBoxColumn lowtemp;
        private System.Windows.Forms.DataGridViewTextBoxColumn heigtemp;
        private System.Windows.Forms.DataGridViewTextBoxColumn address;
        private System.Windows.Forms.DataGridViewTextBoxColumn wdate;
        private System.Windows.Forms.TextBox txtweather;
        private System.Windows.Forms.Button btnselect;
        private System.Windows.Forms.Button btninsert;
        private System.Windows.Forms.Label lblweather;
    }
}

