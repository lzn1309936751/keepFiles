﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Configuration;
using System.Data.SqlClient;

namespace 天气预报
{
    public partial class frmWeather : Form
    {
        public static frmWeather main;
        public frmWeather()
        {
            InitializeComponent();
            main = this;
        }

        public void frmWeather_Load(object sender, EventArgs e)
        {
            DataLoad();
        }

        private void DataLoad()
        {
            string constr = ConfigurationManager.ConnectionStrings["sql"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(constr))
            {
                try
                {
                    conn.Open();
                    string sql = "select * from Weather";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    SqlDataReader dr = cmd.ExecuteReader();
                    List<Weather> list = new List<Weather>();
                    Weather model = null;
                    while (dr.Read())
                    {
                        model = new Weather();
                        model.Wid = (int)dr["wid"];
                        model.Wname = dr["wname"].ToString();
                        model.Lowtemp = dr["lowtemp"].ToString();
                        model.Heigtemp = dr["heigtemp"].ToString();
                        model.Address = dr["address"].ToString();
                        model.Wdate = (DateTime)dr["wdate"];
                        list.Add(model);
                    }
                    dr.Close();
                    dgvimformation.DataSource = list;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
           
            }
        }

        private void btnselect_Click(object sender, EventArgs e)
        {
            string name = txtweather.Text;
            string constr = ConfigurationManager.ConnectionStrings["sql"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(constr))
            {
                try
                {
                    conn.Open();
                    string sql = "select * from Weather where wname=@wname";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.Add(new SqlParameter("@wname",name));
                    SqlDataReader dr = cmd.ExecuteReader();
                    List<Weather> list = new List<Weather>();
                    Weather model = null;
                    while (dr.Read())
                    {
                        model = new Weather();
                        model.Wid = (int)dr["wid"];
                        model.Wname = dr["wname"].ToString();
                        model.Lowtemp = dr["lowtemp"].ToString();
                        model.Heigtemp = dr["heigtemp"].ToString();
                        model.Address = dr["address"].ToString();
                        model.Wdate = (DateTime)dr["wdate"];
                        list.Add(model);
                    }
                    dr.Close();
                    dgvimformation.DataSource = list;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            frmInsert insert = new frmInsert();
            insert.ShowDialog();
        }
    }
}