﻿namespace 天气预报
{
    partial class frmInsert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblweather = new System.Windows.Forms.Label();
            this.lbllowtemp = new System.Windows.Forms.Label();
            this.lblheigtemp = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lbldate = new System.Windows.Forms.Label();
            this.txtweather = new System.Windows.Forms.TextBox();
            this.txtheigh = new System.Windows.Forms.TextBox();
            this.txtlow = new System.Windows.Forms.TextBox();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.dtetime = new System.Windows.Forms.DateTimePicker();
            this.btnInsert = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblweather
            // 
            this.lblweather.AutoSize = true;
            this.lblweather.Location = new System.Drawing.Point(61, 38);
            this.lblweather.Name = "lblweather";
            this.lblweather.Size = new System.Drawing.Size(41, 12);
            this.lblweather.TabIndex = 0;
            this.lblweather.Text = "天气：";
            // 
            // lbllowtemp
            // 
            this.lbllowtemp.AutoSize = true;
            this.lbllowtemp.Location = new System.Drawing.Point(37, 77);
            this.lbllowtemp.Name = "lbllowtemp";
            this.lbllowtemp.Size = new System.Drawing.Size(65, 12);
            this.lbllowtemp.TabIndex = 1;
            this.lbllowtemp.Text = "最低温度：";
            // 
            // lblheigtemp
            // 
            this.lblheigtemp.AutoSize = true;
            this.lblheigtemp.Location = new System.Drawing.Point(37, 122);
            this.lblheigtemp.Name = "lblheigtemp";
            this.lblheigtemp.Size = new System.Drawing.Size(65, 12);
            this.lblheigtemp.TabIndex = 2;
            this.lblheigtemp.Text = "最高温度：";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Location = new System.Drawing.Point(61, 170);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(41, 12);
            this.lbladdress.TabIndex = 3;
            this.lbladdress.Text = "地区：";
            // 
            // lbldate
            // 
            this.lbldate.AutoSize = true;
            this.lbldate.Location = new System.Drawing.Point(61, 211);
            this.lbldate.Name = "lbldate";
            this.lbldate.Size = new System.Drawing.Size(41, 12);
            this.lbldate.TabIndex = 4;
            this.lbldate.Text = "日期：";
            // 
            // txtweather
            // 
            this.txtweather.Location = new System.Drawing.Point(99, 36);
            this.txtweather.Name = "txtweather";
            this.txtweather.Size = new System.Drawing.Size(167, 21);
            this.txtweather.TabIndex = 5;
            // 
            // txtheigh
            // 
            this.txtheigh.Location = new System.Drawing.Point(99, 119);
            this.txtheigh.Name = "txtheigh";
            this.txtheigh.Size = new System.Drawing.Size(167, 21);
            this.txtheigh.TabIndex = 6;
            // 
            // txtlow
            // 
            this.txtlow.Location = new System.Drawing.Point(99, 76);
            this.txtlow.Name = "txtlow";
            this.txtlow.Size = new System.Drawing.Size(167, 21);
            this.txtlow.TabIndex = 6;
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(99, 165);
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(167, 21);
            this.txtaddress.TabIndex = 7;
            // 
            // dtetime
            // 
            this.dtetime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtetime.Location = new System.Drawing.Point(99, 205);
            this.dtetime.Name = "dtetime";
            this.dtetime.Size = new System.Drawing.Size(167, 21);
            this.dtetime.TabIndex = 8;
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(191, 252);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(75, 23);
            this.btnInsert.TabIndex = 9;
            this.btnInsert.Text = "添加";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // frmInsert
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 312);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.dtetime);
            this.Controls.Add(this.txtaddress);
            this.Controls.Add(this.txtlow);
            this.Controls.Add(this.txtheigh);
            this.Controls.Add(this.txtweather);
            this.Controls.Add(this.lbldate);
            this.Controls.Add(this.lbladdress);
            this.Controls.Add(this.lblheigtemp);
            this.Controls.Add(this.lbllowtemp);
            this.Controls.Add(this.lblweather);
            this.Name = "frmInsert";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "添加数据";
            this.Load += new System.EventHandler(this.frmInsert_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblweather;
        private System.Windows.Forms.Label lbllowtemp;
        private System.Windows.Forms.Label lblheigtemp;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.TextBox txtweather;
        private System.Windows.Forms.TextBox txtheigh;
        private System.Windows.Forms.TextBox txtlow;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.DateTimePicker dtetime;
        private System.Windows.Forms.Button btnInsert;
    }
}