package com.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author lzn
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserEntity {
    Integer userId;
    String userName;
    String userSex;
    String userHobby;
    String addTime;
    Integer deptId;

    String deptFather;

}
