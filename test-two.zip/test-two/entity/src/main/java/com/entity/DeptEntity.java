package com.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author lzn
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeptEntity {
    Integer deptId;
    String deptFather;
    Integer pid;
    String addTime;
    Integer deleted;
}
