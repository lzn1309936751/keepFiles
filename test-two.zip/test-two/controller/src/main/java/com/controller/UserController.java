package com.controller;

import com.entity.DeptEntity;
import com.entity.RequestVo;
import com.entity.UserEntity;
import com.service.DeptService;
import com.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

/**
 * @author lzn
 */
@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private DeptService deptService;
    @Autowired
    private UserService userService;

    @GetMapping("/list")
    public ModelAndView userList(){
        ModelAndView mav=new ModelAndView();
        List<UserEntity> getAll=userService.getAll(1,5);
        List<DeptEntity> getFirst=deptService.getFirst();

        mav.addObject("getAll",getAll);
        mav.addObject("getFirst",getFirst);
        mav.setViewName("/userList");
        return mav;
    }

    @RequestMapping("/getSecond")
    @ResponseBody
    public List<DeptEntity> getSecond(HttpServletRequest req, HttpServletResponse resp){
        Integer firstId=Integer.valueOf(req.getParameter("firstId"));
        List<DeptEntity> second=deptService.getSecond(firstId);
        return second;
    }

    @RequestMapping("/insert")
    @ResponseBody
    public RequestVo userInsert(HttpServletRequest req, HttpServletResponse resp){
        String userName=req.getParameter("userName");
        Integer deptId=Integer.valueOf(req.getParameter("deptId"));
        String sex=req.getParameter("userSex");
        String hobby=req.getParameter("userHobby");
        String time= req.getParameter("time");
        UserEntity userEntity=new UserEntity();
        userEntity.setUserName(userName);
        userEntity.setDeptId(deptId);
        userEntity.setUserSex(sex);
        userEntity.setUserHobby(hobby);
        userEntity.setAddTime(time);

        userService.insert(userEntity);
        return RequestVo.builder().code("200").msg("用户信息添加成功！").data("ok").build();
    }

    @RequestMapping("/edit")
    public ModelAndView userEdit(HttpServletRequest req, HttpServletResponse resp){
        ModelAndView mav=new ModelAndView();
        Integer userId=Integer.valueOf(req.getParameter("userId"));
        UserEntity user=userService.getById(userId);
        DeptEntity dept=deptService.getById(user.getDeptId());
        List<DeptEntity> getFirst=deptService.getFirst();

        mav.addObject("getFirst",getFirst);
        mav.addObject("user",user);
        mav.addObject("dept",dept);
        mav.setViewName("/userEdit");
        return mav;
    }

    @RequestMapping("/getHobby")
    @ResponseBody
    public String[] getHobby(HttpServletRequest req, HttpServletResponse resp){
        Integer userId=Integer.valueOf(req.getParameter("userId"));
        UserEntity user=userService.getById(userId);
        String str=user.getUserHobby();
        String[] arr=str.split(",");

        return arr;
    }

    @RequestMapping("/update")
    @ResponseBody
    public RequestVo userUpdate(HttpServletRequest req, HttpServletResponse resp){
        Integer userId=Integer.valueOf(req.getParameter("userId"));
        String userName=req.getParameter("userName");
        Integer deptId=Integer.valueOf(req.getParameter("deptId"));
        String sex=req.getParameter("userSex");
        String hobby=req.getParameter("userHobby");
        UserEntity userEntity=new UserEntity();
        userEntity.setUserName(userName);
        userEntity.setDeptId(deptId);
        userEntity.setUserSex(sex);
        userEntity.setUserHobby(hobby);

        userService.update(userEntity,userId);
        return RequestVo.builder().code("200").msg("用户信息修改成功！").data("ok").build();

    }

    @RequestMapping("/delete")
    public String deptDelete(HttpServletRequest req, HttpServletResponse resp){
        Integer userId=Integer.valueOf(req.getParameter("userId"));
        userService.delete(userId);
        return "redirect:list";
    }

}
