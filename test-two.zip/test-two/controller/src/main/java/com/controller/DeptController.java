package com.controller;

import com.entity.DeptEntity;
import com.entity.RequestVo;
import com.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @author lzn
 */
@Controller
//@RequestMapping("/dept")
public class DeptController {
    @Autowired
    private DeptService deptService;

    @GetMapping("/list")
    public ModelAndView deptList(){
        ModelAndView mav=new ModelAndView();
        List<DeptEntity> getFirst=deptService.getFirst();

        mav.addObject("getFirst",getFirst);
        mav.setViewName("/deptList");
        return mav;
    }

    @RequestMapping("/getSecond")
    @ResponseBody
    public List<DeptEntity> getSecond(HttpServletRequest req, HttpServletResponse resp){
        Integer deptId=Integer.valueOf(req.getParameter("deptId"));
        List<DeptEntity> second=deptService.getSecond(deptId);
        return second;
    }

    @RequestMapping("/insert")
    @ResponseBody
    public RequestVo deptInsert(HttpServletRequest req, HttpServletResponse resp){
        String deptName=req.getParameter("deptName");
        Integer deptId=Integer.valueOf(req.getParameter("deptId"));
        String time=req.getParameter("time");
        DeptEntity deptEntity=new DeptEntity();
        deptEntity.setDeptFather(deptName);
        deptEntity.setPid(deptId);
        deptEntity.setAddTime(time);

        deptService.insert(deptEntity);
        return RequestVo.builder().code("200").msg("部门信息添加成功！").data("ok").build();
    }

    @RequestMapping("/edit")
    public ModelAndView deptEdit(HttpServletRequest req, HttpServletResponse resp){
        Integer deptId=Integer.valueOf(req.getParameter("deptId"));
        DeptEntity dept=deptService.getById(deptId);
        ModelAndView mav=new ModelAndView();
        mav.addObject("dept",dept);
        mav.setViewName("/deptEdit");
        return mav;
    }

    @RequestMapping("/update")
    public String deptUpdate(HttpServletRequest req, HttpServletResponse resp){
        String deptName=req.getParameter("deptName");
        Integer deptId=Integer.valueOf(req.getParameter("deptId"));
        Integer pid=Integer.valueOf(req.getParameter("pid"));

        deptService.update(deptName,pid,deptId);
        return "redirect:list";
    }

    @RequestMapping("/delete")
    public String deptDelete(HttpServletRequest req, HttpServletResponse resp){
        Integer deptId=Integer.valueOf(req.getParameter("deptId"));
        deptService.delete(deptId);
        return "redirect:list";
    }

}
