package com.service.impl;

import com.dao.DeptDao;
import com.entity.DeptEntity;
import com.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author lzn
 */
@Service
public class DeptServiceImpl implements DeptService {
    @Autowired
    private DeptDao deptDao;

    @Override
    public List<DeptEntity> getFirst() {
        return deptDao.getFirst();
    }

    @Override
    public List<DeptEntity> getSecond(Integer deptId) {
        return deptDao.getSecond(deptId);
    }

    @Override
    public DeptEntity getById(Integer deptId) {
        return deptDao.getById(deptId);
    }

    @Override
    public void insert(DeptEntity deptEntity) {
        deptDao.insert(deptEntity);
    }

    @Override
    public void update(String deptFather, Integer pid,Integer deptId) {
        deptDao.update(deptFather,pid,deptId);
    }

    @Override
    public void delete(Integer deptId) {
        deptDao.delete(deptId);
    }
}
