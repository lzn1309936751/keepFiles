package com.service;

import com.entity.DeptEntity;

import java.util.List;

/**
 * @author lzn
 */
public interface DeptService {
    List<DeptEntity> getFirst();
    List<DeptEntity> getSecond(Integer deptId);

    DeptEntity getById(Integer deptId);

    void insert(DeptEntity deptEntity);

    void update(String deptFather,Integer pid,Integer deptId);

    void delete(Integer deptId);
}
