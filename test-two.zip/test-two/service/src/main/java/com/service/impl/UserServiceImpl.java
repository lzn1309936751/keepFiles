package com.service.impl;

import com.dao.UserDao;
import com.entity.UserEntity;
import com.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author lzn
 */
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;

    @Override
    public List<UserEntity> getAll(Integer pageNum, Integer pageSize) {
        return userDao.getAll(pageNum, pageSize);
    }

    @Override
    public UserEntity getById(Integer userId) {
        return userDao.getById(userId);
    }

    @Override
    public void insert(UserEntity userEntity) {
        userDao.insert(userEntity);
    }

    @Override
    public void update(UserEntity userEntity, Integer userId) {
        userDao.update(userEntity, userId);
    }

    @Override
    public void delete(Integer userId) {
        userDao.delete(userId);
    }
}
