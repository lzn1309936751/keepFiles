package com.service;

import com.entity.UserEntity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author lzn
 */
public interface UserService {
    List<UserEntity> getAll(Integer pageNum,Integer pageSize);

    UserEntity getById(Integer userId);

    void insert(UserEntity userEntity);

    void update(UserEntity userEntity,Integer userId);

    void delete(Integer userId);

}
