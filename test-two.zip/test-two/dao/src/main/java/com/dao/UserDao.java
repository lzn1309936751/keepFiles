package com.dao;

import com.entity.DeptEntity;
import com.entity.UserEntity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author lzn
 */
public interface UserDao {
    List<UserEntity> getAll(@Param("pageNum") Integer pageNum,
                            @Param("pageSize") Integer pageSize);

    UserEntity getById(Integer userId);

    void insert(UserEntity userEntity);

    void update(@Param("user") UserEntity userEntity,@Param("id") Integer userId);

    void delete(Integer userId);
}
