use master
go
if exists (select *from sysdatabases where name ='ProductsDB')
drop database ProductsDB
go
create database ProductsDB
go
use ProductsDB
go
create table products
(
	productId int primary key identity(1,1),
	productName varchar(50) not null
)
go
insert into products values('�����')
insert into products values('�����')
go
select * from products
go