use master
if exists (select * from sysdatabases where name='CategoryDB2')
drop database CategoryDB2
go
create database CategoryDB2
go
use CategoryDB2
go
create table Category(
	cid int primary key identity(001,1),
	cname varchar(50) not null
)
go
insert into Category values('�г���')
insert into Category values('������')
insert into Category values('������')
insert into Category values('��ҵ��')
insert into Category values('Ӫ����')
insert into Category values('������')
insert into Category values('������')
insert into Category values('������')
select * from Category
go

declare @pageNum int
set @pageNum=3
declare @pageSize int
set @pageSize=2
select * from (select ROW_NUMBER() over(order by cid) as rowNo, * from Category)as m where rowNo between (@pageNum-1)*@pageSize+1 and @pageNum*@pageSize
go 
select COUNT(*) from Category
go