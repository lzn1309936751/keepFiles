use master
go
if exists (select *from sysdatabases where name ='LoginDB')
drop database LoginDB
go
create database LoginDB
go
use LoginDB
go
create table Information 
(
	userId int primary key identity(1,1),
	username varchar(20) not null,
	password varchar(20) not null,
	hobby varchar(100) not null,
	sex bit
)
go
insert into Information values('���ٳ�','13454','�˶�,�ĵ�,�Ķ�,����','1')
go
select * from Information
go