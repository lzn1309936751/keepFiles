use master
go
if exits (select * from Sysdatabases where name='GaudyDB')
go
drop database GaudyDB
go
create database GaudyDB
use GaudyDB
go

--�û���¼��
create table userLogin(
	userid int primary key identity(1,1),
	username varchar(50) not null,
	password varchar(50) not null,
	sex bit
)
go
--������Ϣ��
create table storeInformation(
	sid int primary key identity(1,1),
	sname varchar(50) not null,
	sgrade varchar(50) not null,
	sdescribe varchar(50) not null,
	sservice varchar(50) not null,
	slogistics varchar(50) not null
)
go
--����Ա��
create table administrator(
	aid int primary key identity(1,1),
	aname varchar(50) not null,
	apassword varchar(50) not null,
	asex bit,
	amanager varchar(100) not null,
	asalary float not null,
	aphone varchar(11) not null
)
go
--��Ʒ���ͱ�
create table category(
	cid int primary key,
	cname varchar(10)
)
go
--��Ʒ��Ϣ��
create table product(
	pid int primary key,
	pname varchar(10),
	pdesc varchar(100),
	unitprice decimal(10,2),
	pimage varchar(100),
	cid int foreign key(cid) references category(cid),
	sid int foreign key(sid) references storeInformation(sid)
)
go
--���ﳵ��
create table cart(
	oid int primary key identity(1,1),
	otime datetime default(getDate()),
	pid int foreign key(pid) references product(pid)
)
go
--�ղر�
create table collect(
	oid int primary key identity(1,1),
	otime datetime default(getDate()),
	pid int foreign key(pid) references product(pid)
)
go
--������Ϣ��
create table orderInformation(
	oid int primary key identity(1,1),
	otime datetime default(getDate()),
	pid int foreign key(pid) references product(pid)
)
go

--�㼣��
create table footmark(
	oid int primary key identity(1,1),
	otime datetime default(getDate()),
	pid int foreign key(pid) references product(pid)
)
go
--���۱�
create table apprise(
	apid int primary key identity(1,1),
	aptime datetime default(getDate()),
	pid int foreign key(pid) references product(pid),
	userid int foreign key(userid) references userLogin(userid)
)
go





