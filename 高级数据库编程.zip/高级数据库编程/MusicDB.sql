use master
if exists (select * from sysdatabases where name='MusicDB')
drop database MusicDB
go
create database MusicDB
go
use MusicDB
go
create table musicinfo(
	mid int primary key identity(001,1),
	mname varchar(50) not null
)
go
insert into musicinfo values('�Һ��ҵ����')
insert into musicinfo values('�ഺ�껪')
insert into musicinfo values('С����')
insert into musicinfo values('ż����')
insert into musicinfo values('�ʼ�')
insert into musicinfo values('�ҵ�����')
insert into musicinfo values('�ؼ���')
insert into musicinfo values('��Щ���ð�յ���')
select * from musicinfo
go

declare @pageNum int
set @pageNum=3
declare @pageSize int
set @pageSize=2
select * from (select ROW_NUMBER() over(order by mid) as rowNo, * from musicinfo)as m where rowNo between (@pageNum-1)*@pageSize+1 and @pageNum*@pageSize
go 
select COUNT(*) from musicinfo
go
