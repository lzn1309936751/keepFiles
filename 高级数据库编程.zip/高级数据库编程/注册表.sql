use master
go
if exists (select *from sysdatabases where name ='LoginUserDB')
drop database LoginUserDB
go
create database LoginUserDB
go
use LoginUserDB
go
create table loginInformation 
(
	userId int primary key identity(1,1),
	username varchar(20) not null,
	password varchar(20) not null
)
go
insert into loginInformation values('lrc','123')
go
select * from loginInformation
go